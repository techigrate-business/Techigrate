# Techigrate — Backend & Website Connection: Changes (V10 → V10.1)

Goal: the website (`index.html` and every other page) saves everything into the **Techigrate Control** Google Sheet through the Apps Script backend, reliably, and tells the visitor the truth about whether their message was saved.

---

## 1. Problems found in the previous version

| # | Problem | Effect |
|---|---------|--------|
| 1 | `parsePayload_` returned `e.parameter` whenever it existed. For JSON posts (`text/plain`) it is an **empty object**, so the JSON body was never read. | **Every analytics event sent from the homepage was rejected** ("Unknown action") and nothing reached the `Events` tab. |
| 2 | `rebuildDashboard_` cleared `A1:B24` but rewrote only `A1:B14`. | Running `setup()` **wiped the Event Mix block** (`A17:B24`). |
| 3 | The contact form used `sendBeacon` and never read a result. | The site showed **"Message delivered" even when nothing was saved** (wrong URL, validation error, backend down). |
| 4 | Analytics + content code existed only as an inline script on `index.html`. | Other pages sent **no page views**; the homepage notification bell was filled only in the first of its two lists. |
| 5 | Lead text was written to the sheet as-is. | A message starting with `=` could run as a **spreadsheet formula** (formula injection). |
| 6 | No duplicate, rate-limit or notification handling; honeypot existed in the backend but not in the form. | Double-clicks saved twice, bots could flood the sheet, new leads went unnoticed. |
| 7 | `lead` was in the Dashboard's Event Mix but never logged; `api_version` stayed `1.0` in the sheet while the code said `2.0`; `Posts.Publish At` was ignored. | Dashboard numbers and settings did not match reality. |
| 8 | Raw error messages (`err.message`) were returned to the public. | Internal details leaked. |

## 2. What changed, file by file

### `Code.gs` — backend v2.1
- **Fixed** payload parsing: JSON body and form fields are merged (events now save).
- **Fixed** dashboard rebuild: Event Mix is rebuilt, a **Leads by Status** block was added, and columns `D:E` are no longer touched.
- **Lead saving**: validation, honeypot (`website`), duplicate protection (same email + message within 2 min is saved once), per-email limit (5/hour), formula-injection guard, a `lead` event is logged, and an **email alert** goes to `notify_email` (reply-to = the visitor). A failed email can never lose a lead.
- **Confirmation**: when the form posts with `transport=frame`, the reply is a tiny page that posts `{ok, id, error, requestId}` to the website, so the site knows for sure.
- **Events**: whitelist kept, visitors cannot forge `lead` events, per-visitor throttle (150 per 10 min), respects `analytics_enabled`.
- **Content endpoint**: 60-second cache, announcements honour `notifications_enabled` and their start/end window, posts honour `Publish At`, only `http(s)` URLs are returned, images only for returned projects, and **private settings (`notify_email`, `lead_notifications`, anything starting `private_`) are never sent to the website**.
- **setup()**: idempotent; applies the timezone to the spreadsheet, formats columns, adds the status dropdown, always updates `api_version`.
- **New helpers**: `selfTest()` (checks tabs, writes + removes a test lead and event, checks privacy of settings) and `installEditTrigger()` (optional: content updates within seconds of editing the sheet).
- Errors returned to the public are generic; details go to the Apps Script log.

### `js/tg-lead-transport.js` — lead transport v3
Native form POST through a hidden iframe (still no CORS issues), now with a **per-request id and a confirmation message**. Result is one of: saved & confirmed · sent but unconfirmed (timeout) · refused with a reason. The endpoint is read from `js/site-config.js` — no URL pasted in this file anymore.

### `js/tg-backend.js` — NEW shared connector (all pages)
- Analytics on **every** page: `page_view`, `cta_click`, `project_view` (home tiles and Work page panels), `search_open`, `announcement_open`; double-click guard; counts bfcache restores.
- Respects **Do-Not-Track / Global Privacy Control** (switch off in `site-config.js`: `respectDoNotTrack:false`).
- Content: renders from a 10-minute session cache instantly, refreshes in the background, 8-second timeout; fills **all** notification lists; the bell dot shows only for announcements not yet opened; project thumbnails replace the built-in artwork only after they load.
- Fails silently — the site never breaks if the backend is down.

### Website files
- `index.html`: the inline integration script was removed (replaced by `js/tg-backend.js`).
- `about / services / work / technology / contact / privacy / terms / 404 .html`: now load `site-config.js` + `tg-backend.js` (`project-recommender.html` is an HTML fragment and was left as is).
- `contact.html`: hidden honeypot field + `tg-lead-transport.js`.
- `js/contact-experience.js`: uses the new transport. A refused or failed send shows an error **with the email address**, and the form stays filled. If the confirmation does not arrive in time, the success screen says to email us if no reply comes.
- `js/contact.js`: its fallback path also tries the backend first, and only then opens a mailto draft.
- `js/site-config.js`: new options `analytics`, `respectDoNotTrack`, `leadTimeoutMs` (the `/exec` URL is unchanged).

### `Techigrate-Control-Fresh.xlsx`
- Dashboard: "Setup state" now describes the live system; new **Leads by Status** block (`A27:B33`); date formats on Last Lead / Last Event.
- Settings: `api_version` → `2.1`; new `notify_email` and `lead_notifications` (private); clearer notes.
- Header rows frozen on every data tab.

### `lead-test.html`
Now has three checks (health, content, send lead) and shows **SAVED ✔ / refused / unconfirmed** instead of "Submitted".

### Docs
`README.md`, `SETUP-FROM-ZERO.md`, `LEAD-CONNECTION.md`, `CHANGELOG.md`, `QA-CHECKLIST.md` updated to match.

---

## 3. What you must do (in order)

1. Import the new `Techigrate-Control-Fresh.xlsx` into Google Sheets (or keep your current sheet — `setup()` adds anything missing).
2. Apps Script: replace the code with the new `Code.gs`, set `SPREADSHEET_ID`, save.
3. Run `setup()` (approve permissions — the new **email** permission appears here), then run `selfTest()` and check that every line says `OK`.
4. **Deploy → Manage deployments → ✏️ Edit → Version: New version → Deploy.** This keeps the same `/exec` URL. (If you create a *New deployment* instead, paste the new URL into `js/site-config.js`.)
5. Open `lead-test.html`, paste the `/exec` URL, run the three checks. Expect **SAVED ✔** and a row in `Leads`.
6. Upload the `Techigrate-V10.1` site. Visit a few pages, then check `Events` for `page_view` rows and `Dashboard` for visitors.

## 4. Things to know

- Everything was verified offline with mocks (backend logic: 17 checks; transport: confirm / refuse / timeout / foreign-message paths; every JS file passes a syntax check). **The live pieces — Google's reply page posting the confirmation, `sendBeacon` to Apps Script, the Sheets formulas — need your step 5–6 check.** If the confirmation does not appear, leads are still saved and the site falls back to the "sent, unconfirmed" message.
- The Dashboard formulas use Google-Sheets-only functions (`FILTER`, `COUNTUNIQUE`, open ranges like `Leads!A2:A`). They compute in Google Sheets, not in desktop Excel.
- The content cache means edits in the sheet appear on the site within ~60 seconds (instantly-ish with `installEditTrigger()`).
- Email alerts use your Apps Script mail quota (about 100 recipients/day on a free Gmail account — plenty for leads).
- Since the site now sets visitor/session identifiers on every page, check that `privacy.html` still describes this accurately (it already mentions event tracking and visitor/session IDs).
