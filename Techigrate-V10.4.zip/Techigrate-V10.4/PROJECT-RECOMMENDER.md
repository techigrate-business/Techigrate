# Project recommender — "What are you trying to build?"

**Live on `index.html`** — between the Process section and Work preview.
Namespaced `tg-pr-` throughout, same discipline as Project Intake's `tg-pi-`.

## What changed to get it live

This shipped with two real bugs, both fixed here:

1. **Packaging mismatch.** `demo.html` and `project-recommender.html`
   referenced `css/project-recommender.css` and `js/project-recommender.js`
   as if they lived in `css/`/`js/` subfolders next to them — but the
   files shipped flat, alongside the HTML. Fixed by actually moving
   `project-recommender.css` → `css/project-recommender.css` and
   `project-recommender.js` → `js/project-recommender.js`, matching how
   `tg-pi.css`/`tg-pi.js` already live in this site's shared folders.
2. **Relative paths assumed a nested location.** Both files were written
   as if they'd live two folders below the site root
   (`upgrades/project-recommender/`). They now live at the root instead
   (`demo.html`, `project-recommender.html` — same pattern as Project
   Intake's `preview.html`/`template.html`), so every `../../` was
   rewritten to a plain root-relative path.

## Files

```
(site root)
├── PROJECT-RECOMMENDER.md   — this file
├── demo.html                — standalone preview, opens directly, no build step
├── project-recommender.html — the fragment now live on index.html (copy also kept here)
├── css/project-recommender.css
└── js/project-recommender.js
```

## No-JS fallback

Steps 2 and 3 are dynamically generated — Step 2's options depend on which
category was picked, Step 3's recommendation depends on both — so unlike
Project Intake, there's no meaningful static content to stack and show
instead. Without JS, Step 1's five buttons would otherwise just sit there
not responding to clicks: not a broken/invisible-content bug, but a dead
end. Fixed the same way as everywhere else on this site: `js/project-
recommender.js` sets `data-tg-pr-js` on the root element the instant it
runs; `css/project-recommender.css` uses that attribute's *absence* to
hide the whole interactive stage and reveal a plain `<noscript>` fallback
instead — two links to the same two places a completed quiz would have
sent someone anyway (`services.html`, `contact.html`).

## Connects to Project Intake — the taxonomy note

Clicking the CTA (in every path except "I want to see what you've built
first," which still goes to `work.html`) now does two things before
navigating, exactly like Project Intake's own "Continue" does when it
hands off to the contact form:

1. Writes one value to `sessionStorage` (key
   `techigrateRecommenderSeed`) — the picked category, mapped to Project
   Intake's own vocabulary.
2. Navigates to `contact.html#tg-pi-root` — a same-page anchor that lands
   directly on the embedded Project Intake widget, not just the top of
   the page.

`js/tg-pi.js` reads that key once on load, pre-selects the matching Step 1
option (never auto-skipping past it — the visitor still sees and confirms
it themselves), and removes the key immediately so it can't reapply on a
later, unrelated visit.

The mapping isn't 1:1 by accident:

| This module's category | → seed value | Project Intake's Step 1 label |
|---|---|---|
| Website | `web` | Websites & digital products |
| Software | `software` | Software & applications |
| AI | `ai` | AI & automation |
| **Automation** | `infrastructure` | **Automation & infrastructure** |
| Not sure | `unsure` | Not sure yet |

"Automation" and "Infrastructure" used to be two different labels for what
turned out to be the same underlying pillar — `services.html` itself
calls it one thing: **"03 / Automation & Infrastructure."** Rather than
force an artificial 1:1 rename, the fix was to make both modules — and the
real contact form's `project-type` select — agree on that same label
(`Automation & infrastructure`) and same value (`infrastructure`). All
three now say the same thing.

## Rollback

- **Full removal:** delete `css/project-recommender.css`,
  `js/project-recommender.js`, `demo.html`, `project-recommender.html`,
  and this file. On `index.html`, remove the one `<link>`, the one
  `<script>` tag, and the fragment block itself (bounded by the `<!--
  Techigrate — "What are you trying to build?" project recommender -->`
  comment through its matching `</section>`). Nothing else references this
  feature.
- **Instant disable without deleting anything:** remove just the
  `<script src="js/project-recommender.js" defer>` tag from `index.html`.
  The no-JS fallback CSS then takes over automatically — visitors see the
  two plain links instead of a non-functional widget, with zero further
  changes needed.

## How the content was grounded

Recommendations map to the actual pillars on `services.html` — "Product
engineering," "Intelligent systems," "Automation & infrastructure" — not
invented service categories. The "Not sure" path deliberately does **not**
force-fit a pillar; its three outcomes stay general (talk to us / look at
our work / just start a conversation) because there's no factual basis to
recommend a specific direction when the visitor themselves doesn't know
yet. One of those three ("I want to see what you've built first") links to
`work.html` instead of `contact.html` for the same reason.

All copy, options, and recommendations live in one `DATA` object at the
top of `js/project-recommender.js` — extending or editing the
questions/answers means editing that object only.

## QA checklist

**Desktop**
- [ ] Section renders below Process, above Work preview, matching container width/gutters of surrounding sections
- [ ] All 5 category options are reachable and visually consistent with the site's card/button language
- [ ] Selecting a category transitions to Step 2 with the correct 3 context options for that category
- [ ] Selecting a context option transitions to Step 3 with the correct direction/why/next copy and correct CTA target
- [ ] "Back" from Step 2 returns to Step 1 with prior selection cleared
- [ ] "Start over" from Step 3 returns cleanly to Step 1
- [ ] Step dots update correctly across all 3 steps
- [ ] "I want to see what you've built first" path's CTA points to `work.html`, not `contact.html` — and does **not** write a recommender seed (there's no intake step to seed on that page)

**The handoff to Project Intake**
- [ ] Complete the quiz picking "Automation," click through — land on `contact.html` scrolled directly to the intake widget (not the top of the page)
- [ ] Confirm Step 1 there already shows "Automation & infrastructure" selected
- [ ] Refresh `contact.html` afterward — confirm the pre-selection does **not** reappear/reset on unrelated visits (the seed is one-time-use)
- [ ] Start the intake quiz manually on `contact.html` first (own progress, no recommender visit) — confirm a later, unrelated arrival at the page doesn't clobber that in-progress answer

**No-JS**
- [ ] Disable JavaScript, reload `index.html` — confirm the interactive widget is hidden and the plain "Browse what we do / tell us directly" links are visible and functional instead
- [ ] Confirm nothing else on the page (Process, Work preview, footer) is affected

**Mobile (≤ 640px, then ≤ 420px)**
- [ ] Option grid collapses to 2 columns, then 1 column, per breakpoint
- [ ] All tap targets ≥ ~48px tall at the narrowest breakpoint
- [ ] No horizontal scroll/overflow at 320px width

**Dark mode**
- [ ] Toggle dark mode (via the real site's theme switch, or `demo.html`'s own) and confirm the glass stage, option cards, result card, and CTA all read correctly with no hardcoded-light leftovers
