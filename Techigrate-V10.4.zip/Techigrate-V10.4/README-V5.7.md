V5.8 update: pricing stage background and V3-style click sparks.

# Techigrate V5.7

This build keeps the accumulated V5.5/V5.6 experience and adds a guided contact flow:

1. Project intake questionnaire
2. Pricing selection
3. Final contact form

Choosing a plan automatically syncs the budget and selected plan badge into the final form. Intake answers are carried into the final form after the user explicitly chooses a plan.

The live build also includes the site-wide click-spark interaction with reduced-motion safeguards. Forms and pricing use layered 3D glass/depth styling while staying scoped to avoid interfering with the site's existing motion systems.
