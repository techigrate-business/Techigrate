# Homepage Hero — Reference + Supplied T SVG

- Retains the reference-inspired hero composition and existing page sections.
- Replaces the CSS-generated hero T/orb core with the supplied `techigrate-glass-t-exact.svg` artwork.
- Uses masking/blending so the artwork integrates into the hero atmosphere instead of reading as a rectangular image.
- Preserves pointer tilt, responsive layout, reduced-motion support, and existing homepage interactions.
