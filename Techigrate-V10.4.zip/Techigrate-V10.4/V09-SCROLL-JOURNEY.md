# Techigrate V09 — Scroll Journey

Base: V07, unchanged (preloader "Hello" sequence, stair handoff, hero typing, navbar, Start a project button,
section-nav, Lenis smooth scroll, reveals, tilt, storytelling motion all kept).

## Added
- `css/scroll-journey.css`, `js/scroll-journey.js` (loaded on index, services, work, technology, about, careers, contact)
- **Every page:** each `main > section` rises out of depth (scale + blur + fade) as it enters and recedes as it leaves.
  Sections with their own background keep the panel fixed and move only the content.
- **Homepage:** hero pins for ~3.5 screens. The planet-T glides to centre, the camera dives into the T while
  IDEAS -> PRODUCTS -> IMPACT swap, then it dissolves into the next section. Below 900px wide / 620px tall the hero
  is not pinned (normal scrolling).
- **Intro:** the planet-T (`assets/techigrate-planet-t.png/.webp`, background removed) flies in from a blur as the
  stairs peel away.
- `prefers-reduced-motion`: journey and depth effects are skipped entirely.

## Changed
- Lenis feel tuned slightly heavier (`lerp .072`, `wheelMultiplier .86`) in `js/global.js`.
- `js/section-nav.js`, `js/storytelling-motion.js`: section selector also matches the pinned hero wrapper.
- Homepage hero image swapped to the planet-T.

## Removed
- Unused SVGs: `techigrate-glass-t-hero.svg`, `techigrate-glass-t-exact.svg`, `techigrate-glass-t-integrated.svg`.
  (Kept: `favicon.svg`, `assets/pricing/*-orbit.svg` — referenced by the pricing widget.)

## Now unreferenced (safe to delete if you want a lighter folder)
`assets/techigrate-glass-t-hero.png`, `techigrate-glass-t-integrated.png`, `techigrate-glass-t-cutout.png`


---
## V09 update 2

### Hero (index.html only)
- **Preloader:** V07's "Hello" sequence and stair handoff are untouched.
- **Centred title:** V08's giant TECHIGRATE (letters rise out of masks after the handoff) is back, with the planet-T in front.
  It is sized by `js/home-scene.js` to fit the screen whatever font loads. The small typed headline stays in the DOM as the
  accessible H1 (visually hidden).
- **Lake backgrounds:** light theme = sunny mountain lake, dark theme = blue moonlight lake
  (`assets/bg/day-lake.*`, `night-lake.*`, both as H.264 mp4 + VP9 webm + poster jpg; seamless loops, no audio).
  Only the visible theme's clip loads first; only the on-screen one plays; none load under reduced-motion, Save-Data or 2G/3G.
- **Theme change:** V07's View-Transition wipe still runs; on top of it the incoming scene pulls into focus and a bloom
  flares around the sun / moon.
- The "Features & pricing" card (position:static in V07) now sits bottom-right as its CSS intended; dark-theme glass fixed.
- Files: `css/home-scene.css`, `js/home-scene.js` (index only).

### Default theme
- White/light is the default on every page, ignoring the visitor's OS dark-mode setting. A choice saved by the toggle
  (`localStorage['techigrate-theme']`) is still respected. `theme-color` meta defaults to white.

### Contact page — pricing lag
- `js/pricing-contact.js`: hover loop no longer writes inherited CSS variables every frame or reads layout in every
  pointermove; the spotlight is a transform-only element; card rect is cached.
- `css/pricing-contact.css`: two per-frame drop-shadow filters on the tier art replaced by a static gradient shadow;
  backdrop blur removed from the (76%-opaque) tier switcher; layers kept promoted.
- `#pricing` excluded from the scroll depth effect, and the blur part of that effect is skipped for tall sections and
  sections with video / forms / 3D widgets.
- Measured (headless Chrome, software rendering, hover over the card): avg frame 96 ms -> 31 ms, worst 250 ms -> 67 ms,
  long tasks 18 -> 0 versus V07.
