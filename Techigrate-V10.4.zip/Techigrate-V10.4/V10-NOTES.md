# Techigrate V10 — V09.9 + new custom cursor

Base = V09.9 in full (nothing else touched: motion, scroll, forms, footer, Terms shell, assets).
Only two files changed, both replaced with the uploaded versions:
- css/v097-motion.css
- js/v097-motion.js

## What changed (cursor only)
- Colour follows the theme AND the surface under the pointer (blue on light areas, soft lilac on dark areas / night lake).
- Replaces the white difference-blend ring with a precise dot + softly lagging ring (halo keeps it visible on any background).
- Buttons, nav items and chips: a rounded frame locks onto the element and matches its corner radius (targets up to 360x96 px).
  Larger targets get the ring-grow fallback instead.
- Cards: brand-gradient disc with the "View" label (label is now white).
- Click pulse ring; press states; pointercancel/dragend release; re-checks the target under the pointer while scrolling.
- Text fields keep the native I-beam. Touch/coarse pointer and reduced-motion behaviour unchanged.

## Note
js/click-spark.js (sparks + ring on click) still runs alongside the new click pulse, so a mouse click shows both.
To use only the new pulse, remove css/click-spark.css and js/click-spark.js tags from the pages.
