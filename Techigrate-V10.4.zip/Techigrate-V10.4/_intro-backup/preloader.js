/* ========================================================================== 
   TECHIGRATE V5.5 — ROLLING GREETING PRELOADER + AUTO STAIR HANDOFF
   Homepage only. The white greeting stage is preserved; the former
   Tap-to-Continue gate is gone. The stair handoff now runs automatically.
   ========================================================================== */
(function () {
  'use strict';

  var loader = document.querySelector('.tg-preloader');
  var word = loader && loader.querySelector('[data-loader-word]');
  if (!loader || !word) return;

  /* Once the homepage intro has completed in this browser tab, don't replay
     the full greeting/stair sequence every time the visitor returns home.
     ?intro=1 remains a convenient explicit replay switch for testing. */
  var forceReplay = false;
  try {
    forceReplay = new URLSearchParams(window.location.search).get('intro') === '1';
  } catch (e) {}

  var introSeen = false;
  try {
    introSeen = sessionStorage.getItem('techigrate-home-intro-seen') === '1';
  } catch (e) {}

  if (introSeen && !forceReplay) {
    document.body.classList.remove('tg-preloading');
    document.body.classList.add('tg-loaded');
    loader.remove();
    return;
  }

  var reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var greetings = [
    'Hello',
    'नमस्ते',
    'Hola',
    'Bonjour',
    'Ciao',
    'Olá',
    'Hallo',
    'こんにちは',
    '안녕하세요',
    'Hello, Welcome to TECHIGRATE'
  ];

  var stepDelays = [390, 320, 280, 250, 225, 205, 190, 175, 150];
  var wordChangeMs = 170;
  var finalHoldMs = 520;
  var exitMs = 1120;
  var stairReleaseMs = 980;
  var maxWaitMs = 7600;

  var pageReady = document.readyState === 'complete';
  var sequenceComplete = false;
  var finished = false;
  document.body.classList.add('tg-preloading');

  function splitLetters(text) {
    return Array.from(text).map(function (char, i) {
      if (char === ' ') return '<span class="tg-letter tg-letter--space" aria-hidden="true">&nbsp;</span>';
      return '<span class="tg-letter" aria-hidden="true" style="--letter-i:' + i + '">' +
        char.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;') +
        '</span>';
    }).join('');
  }

  function renderWord(text, animate) {
    word.setAttribute('aria-label', text);
    word.innerHTML = '<span class="tg-word-line">' + splitLetters(text) + '</span>';
    if (!animate) return;
    word.classList.remove('is-changing', 'is-entering');
    /* Force a tiny reflow so repeated greetings always retrigger the roll. */
    void word.offsetWidth;
    word.classList.add('is-entering');
  }

  function createStairHandoff() {
    var existing = document.querySelector('.tg-stair-handoff');
    if (existing) return existing;

    var handoff = document.createElement('div');
    handoff.className = 'tg-stair-handoff';
    handoff.setAttribute('aria-hidden', 'true');

    var topSteps = '';
    var bottomSteps = '';
    for (var i = 0; i < 7; i += 1) {
      topSteps += '<span class="tg-stairs__step" style="--i:' + i + '"></span>';
      bottomSteps += '<span class="tg-stairs__step" style="--i:' + i + '"></span>';
    }

    handoff.innerHTML =
      '<div class="tg-stairs tg-stairs--top">' + topSteps + '</div>' +
      '<div class="tg-stairs tg-stairs--bottom">' + bottomSteps + '</div>' +
      '<div class="tg-stair-handoff__label">TECHIGRATE</div>';

    document.body.appendChild(handoff);
    return handoff;
  }

  function releaseThroughStairs() {
    var handoff = createStairHandoff();
    var reduced = reduceMotion;

    document.body.classList.remove('tg-preloading');
    document.body.classList.add('tg-loaded', 'tg-stair-handoff-active');
    handoff.classList.add('is-visible');

    /* The stairs are already on screen underneath the white sheet. A short
       settle lets the two layers meet without a hard cut, then the stairs
       peel apart automatically — no tap gate. */
    window.requestAnimationFrame(function () {
      window.requestAnimationFrame(function () {
        handoff.classList.add('is-releasing');
        document.body.classList.add('tg-site-releasing');
      });
    });

    window.setTimeout(function () {
      handoff.remove();
      document.body.classList.remove('tg-stair-handoff-active', 'tg-site-releasing');
    }, reduced ? 20 : stairReleaseMs + 120);
  }

  function swapWord(nextText, isFinal) {
    word.classList.remove('is-entering');
    word.classList.add('is-changing');

    window.setTimeout(function () {
      renderWord(nextText, true);
      if (isFinal) word.classList.add('is-final');
    }, Math.min(wordChangeMs, 120));
  }

  function runSequence() {
    renderWord(greetings[0], false);

    if (reduceMotion) {
      renderWord(greetings[greetings.length - 1], false);
      sequenceComplete = true;
      maybeFinish();
      return;
    }

    var cursor = 0;
    function next() {
      if (cursor >= greetings.length - 1) {
        window.setTimeout(function () {
          sequenceComplete = true;
          maybeFinish();
        }, finalHoldMs);
        return;
      }

      cursor += 1;
      swapWord(greetings[cursor], cursor === greetings.length - 1);
      window.setTimeout(next, stepDelays[cursor - 1] || 155);
    }

    window.setTimeout(next, stepDelays[0]);
  }

  function revealSite() {
    if (finished) return;
    finished = true;
    try { sessionStorage.setItem('techigrate-home-intro-seen', '1'); } catch (e) {}
    loader.classList.add('is-leaving');

    /* Start the stair handoff at the same time as the upward white lift.
       It is fully automatic now. */
    window.setTimeout(function () {
      releaseThroughStairs();
    }, reduceMotion ? 0 : 180);

    window.setTimeout(function () {
      loader.remove();
    }, reduceMotion ? 20 : exitMs);
  }

  function maybeFinish() {
    if (sequenceComplete && pageReady) revealSite();
  }

  window.addEventListener('load', function () {
    pageReady = true;
    maybeFinish();
  }, { once: true });

  window.setTimeout(function () {
    pageReady = true;
    maybeFinish();
  }, maxWaitMs);

  runSequence();
})();
