# V09.6 aesthetic batch (homepage only)

Files: `css/v096-aesthetic.css` (~13 KB), `js/v096-aesthetic.js` (<1 KB). Linked from `index.html` only.

1. **Refined glass** - `.tg-glass` recipe (translucent fill, top-left sheen, top glow, 1px masked gradient edge via `::before`, `--shadow-soft`). Applied to `.work-tile`, the 4 bento tiles and `.glass`. No `backdrop-filter` on cards over the aurora; `.glass` only gets it under `@supports`. Forced-colors fallback included.
2. **Aurora** - `::before`/`::after` on `#what-we-build`, the work section (matched with `:has(>.work-preview-grid)`) and `.v8-end`. Slow 56 s transform-only drift on one layer; `will-change` and animation only while `.tg-in-view` (IntersectionObserver); paused when the tab is hidden; static under reduced motion.
3. **Grain** - static inline SVG feTurbulence tile in the aurora layers and on `.tg-glass` bento tiles. Not on `.work-tile` or `.glass` (measured cost, see report).
4. **Bento** - 12-col grid (7/5, 5/7), 2 columns tablet, 1 mobile; work grid 1.6fr/1fr with a tall first tile. Small inline SVG motifs per tile (`currentColor`).
5. **Colour shift** - two stacked aurora layers crossfaded by opacity with `animation-timeline: view()` inside `@supports`; static mid-mix otherwise.
6. **Anti-design** - `.v8-end` only: solid `#0a0e1a`, square corners, hard-edged offset-shadow button, monospace email label, oversized tight type, single `#4c8dff` accent.
7. **Editorial type** - `--font-serif`, `.tg-ital` on one word in each of the three headings, larger `.v8-h2` and the work-section `.type-h2`.

Tokens added: `--font-serif`, `--tg-g-fill/sheen/glow/edge/edge-o/edge-hover`, `--tg-motif`, `--tg-focus`, `--tg-noise`, `--tg-ab/av/ac`, `--tg-fade`.

## Remove the whole batch
1. Delete `css/v096-aesthetic.css` and `js/v096-aesthetic.js`.
2. In `index.html` remove their two tags, the Instrument Serif part of the Google Fonts link, the `.tg-ital` spans, the `tg-glass` class and `.v8-motif` SVGs in the four `.v8-row` links (the work heading's pre-split `.tg-word` spans can go back to plain text).
