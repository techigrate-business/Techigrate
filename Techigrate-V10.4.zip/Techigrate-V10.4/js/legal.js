/* TECHIGRATE — legal pages: builds the "On this page" list from the clause headings.
   Does nothing while the document has no <h2> (the rail stays hidden). */
(function () {
  'use strict';
  var wrap = document.querySelector('.tg-legal');
  var doc = wrap && wrap.querySelector('[data-legal-doc]');
  var toc = wrap && wrap.querySelector('[data-legal-toc]');
  if (!doc || !toc) return;
  var heads = [].slice.call(doc.querySelectorAll('h2'));
  if (!heads.length) return;

  var list = toc.querySelector('ol');
  heads.forEach(function (h, i) {
    if (!h.id) h.id = 'clause-' + (i + 1);
    var li = document.createElement('li');
    var a = document.createElement('a');
    a.href = '#' + h.id;
    a.textContent = h.textContent;
    li.appendChild(a);
    list.appendChild(li);
  });
  toc.hidden = false;
  wrap.classList.add('has-toc');

  if (!('IntersectionObserver' in window)) return;
  var links = [].slice.call(list.querySelectorAll('a'));
  var io = new IntersectionObserver(function (es) {
    es.forEach(function (e) {
      if (!e.isIntersecting) return;
      links.forEach(function (l) { l.classList.toggle('is-current', l.getAttribute('href') === '#' + e.target.id); });
    });
  }, { rootMargin: '-20% 0px -70% 0px' });
  heads.forEach(function (h) { io.observe(h); });
})();
