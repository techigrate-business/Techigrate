/* ==========================================================================
   CONTACT — legacy helpers + FAQ/prefill support
   The active submission path is owned by contact-experience.js, which sends
   directly to the Techigrate Apps Script Web App and the Leads sheet.
   The submit handler below is only a safety net (mailto draft) if that file
   is not running.
   ========================================================================== */

(function () {
  'use strict';

  const SITE = window.TECHIGRATE_SITE || {};
  const FALLBACK_EMAIL = SITE.email || 'techigrate.business@gmail.com';

  /* ---- Prefill from Project Intake (if the visitor came from there) ----
     The intake quiz now lives on this same page (contact.html), above this
     form. js/tg-pi.js writes a JSON summary to sessionStorage the moment
     someone clicks its "Continue" button, then fires a
     'techigrate:intake-continue' event on the same page — no navigation,
     no reload. This function runs once on load (a no-op the vast majority
     of the time, and a safety net for any older entry point that still
     writes this key before navigating) AND again on that event, so the
     hand-off is instant while the visitor is still looking at the form. */
  function prefillFromIntake() {
    let raw;
    let selectedPlan = null;
    try {
      const selectedRaw = window.sessionStorage.getItem('techigrateSelectedPlan');
      if (selectedRaw) selectedPlan = JSON.parse(selectedRaw);
    } catch (err) {}
    try {
      raw = window.sessionStorage.getItem('techigrateProjectIntakeSummary');
    } catch (err) {
      return; // storage unavailable (private mode etc.) — nothing to prefill
    }
    if (!raw) return;

    let summary;
    try {
      summary = JSON.parse(raw);
    } catch (err) {
      return; // corrupted/unexpected data — leave the form untouched
    }

    const form = document.querySelector('.contact-form');
    if (!form) return;

    // Same human-readable labels tg-pi.js uses for its own summary screen,
    // duplicated here since these are separate static files with no shared
    // module system to import from.
    const BOTTLENECK_LABELS = {
      legacy: 'Outdated or fragile technology',
      manual: 'Manual, repetitive work',
      scale: 'Can\u2019t scale with demand',
      reliability: 'Breaks or slows under load',
      unsure: 'Not sure — needs diagnosis'
    };
    const INVOLVEMENT_LABELS = {
      advise: 'Advise & review',
      embedded: 'Build alongside your team',
      ownership: 'Own delivery end-to-end',
      unsure: 'Not sure yet'
    };
    const PRIORITY_LABELS = {
      speed: 'Speed',
      reliability: 'Reliability',
      simplicity: 'Simplicity',
      scale: 'Scale',
      automation: 'Automation'
    };

    // improve values (web/software/ai/infrastructure/unsure) match this
    // select's option values exactly — same vocabulary by design.
    const typeSelect = form.querySelector('#project-type');
    if (typeSelect && summary.improve && typeSelect.querySelector('option[value="' + summary.improve + '"]')) {
      typeSelect.value = summary.improve;
    }

    const budgetEl = form.querySelector('#budget');
    if (budgetEl && selectedPlan && selectedPlan.plan && budgetEl.querySelector('option[value="' + selectedPlan.plan + '"]')) {
      budgetEl.value = selectedPlan.plan;
    }

    const planBadge = form.querySelector('[data-selected-plan]');
    if (planBadge && selectedPlan && selectedPlan.plan) {
      const planName = {silver:'Silver',gold:'Gold',platinum:'Platinum',diamond:'Diamond'}[selectedPlan.plan] || selectedPlan.plan;
      planBadge.textContent = planName + ' · ₹' + (selectedPlan.price || '');
      planBadge.dataset.plan = selectedPlan.plan;
    }

    const messageEl = form.querySelector('#message');
    if (messageEl && !messageEl.value) {
      const lines = ['From the project intake quiz:'];
      if (summary.bottleneck && BOTTLENECK_LABELS[summary.bottleneck]) {
        lines.push('- Current bottleneck: ' + BOTTLENECK_LABELS[summary.bottleneck]);
      }
      if (summary.involvement && INVOLVEMENT_LABELS[summary.involvement]) {
        lines.push('- Involvement wanted: ' + INVOLVEMENT_LABELS[summary.involvement]);
      }
      if (summary.priority && PRIORITY_LABELS[summary.priority]) {
        lines.push('- Top priority: ' + PRIORITY_LABELS[summary.priority]);
      }
      if (summary.notes) {
        lines.push('');
        lines.push(summary.notes);
      }
      if (lines.length > 1) messageEl.value = lines.join('\n');
    }

    // A quiet, inline-styled note (no new CSS class/file needed) so the
    // visitor understands why fields already have content, and knows
    // they're free to change any of it before sending. Guarded so that if
    // this fires more than once in a page view (visitor runs the quiz
    // again above), the note doesn't stack up duplicates.
    try {
      if (!form.querySelector('[data-tg-pi-note]')) {
        const note = document.createElement('p');
        note.setAttribute('data-tg-pi-note', '');
        note.style.cssText = 'color:var(--text-tertiary); font-size:0.875rem; line-height:1.5; margin:0 0 var(--sp-2);';
        note.textContent = "We've filled in a few details from your project overview above — take a look and edit anything before sending.";
        form.insertBefore(note, form.firstChild);
      }
    } catch (err) { /* cosmetic only — a missing note doesn't matter */ }

    const nameEl = form.querySelector('#name');
    if (nameEl) {
      try { nameEl.focus({ preventScroll: false }); } catch (err) { nameEl.focus(); }
    }
  }

  document.addEventListener('techigrate:pricing-selected', prefillFromIntake);

  /* ---- Contact form ---- */
  const form = document.querySelector('.contact-form');
  if (form) {
    const status = document.querySelector('.form-status');
    const submitBtn = form.querySelector('.send-btn');
    const btnText = submitBtn ? submitBtn.querySelector('.send-btn-text') : null;

    function setStatus(message, isError) {
      if (!status) return;
      const icon = isError
        ? '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 8v5M12 16h.01"/></svg>'
        : '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg>';
      status.innerHTML = `${icon}<span>${message}</span>`;
      status.classList.toggle('is-error', Boolean(isError));
      status.classList.add('is-visible');
    }

    function fieldsFromForm() {
      const val = (id) => (form.querySelector('#' + id) || {}).value || '';
      const selectLabel = (id) => {
        const el = form.querySelector('#' + id);
        if (!el || !el.value) return ''; // placeholder/unselected — don't send its label text
        return el.selectedOptions[0]?.text || '';
      };
      return {
        name: val('name').trim(),
        email: val('email').trim(),
        company: val('company').trim(),
        projectType: selectLabel('project-type'),
        budget: selectLabel('budget'),
        message: val('message').trim(),
      };
    }

    function sendViaMailto(data) {
      const subject = encodeURIComponent(`New project inquiry from ${data.name || 'website visitor'}`);
      const body = encodeURIComponent(
        [
          `Name: ${data.name}`,
          `Email: ${data.email}`,
          `Company: ${data.company || '—'}`,
          `Project type: ${data.projectType || '—'}`,
          `Budget: ${data.budget || '—'}`,
          '',
          data.message,
        ].join('\n')
      );
      window.location.href = `mailto:${FALLBACK_EMAIL}?subject=${subject}&body=${body}`;
    }

    function launchSendCelebration(button) {
      const reduced = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
      if (reduced) return Promise.resolve();

      return new Promise((resolve) => {
        const icon = button.querySelector('svg');
        const iconRect = (icon || button).getBoundingClientRect();
        const startX = iconRect.left + iconRect.width * 0.52;
        const startY = iconRect.top + iconRect.height * 0.52;

        button.classList.remove('is-complete');
        button.classList.add('is-launching');

        const flight = document.createElement('div');
        flight.className = 'send-flight';
        flight.setAttribute('aria-hidden', 'true');
        flight.innerHTML = `
          <span class="send-flight__trail send-flight__trail--a"></span>
          <span class="send-flight__trail send-flight__trail--b"></span>
          <span class="send-flight__glow"></span>
          <svg viewBox="0 0 24 24"><path fill="currentColor" d="M1.946 9.315c-.522-.174-.527-.455.01-.634l19.087-6.362c.529-.176.832.12.684.638l-5.454 19.086c-.15.529-.455.547-.679.045L12 14l6-8-8 6-8.054-2.685z"/></svg>
        `;
        document.body.appendChild(flight);

        const vw = window.visualViewport ? window.visualViewport.width : window.innerWidth;
        const vh = window.visualViewport ? window.visualViewport.height : window.innerHeight;
        const edge = Math.max(40, Math.min(vw * 0.11, 110));
        const targetX = Math.max(32, Math.min(vw - edge, vw * (vw < 640 ? 0.78 : 0.90)));
        const targetY = Math.max(118, Math.min(vh * (vw < 640 ? 0.28 : 0.22), startY - Math.max(95, vh * 0.12)));
        const travelX = targetX - startX;
        const control1X = startX + Math.max(70, travelX * 0.26);
        const control1Y = startY - Math.min(90, vh * 0.10);
        const control2X = startX + travelX * 0.68;
        const control2Y = Math.max(64, targetY - Math.min(160, vh * 0.24));
        const duration = vw < 640 ? 1180 : 1380;
        const flightSvg = flight.querySelector('svg');
        const trails = [...flight.querySelectorAll('.send-flight__trail')];
        let lastX = startX;
        let lastY = startY;
        let raf = 0;
        const started = performance.now();

        const pointAt = (t) => {
          const u = 1 - t;
          return {
            x: u*u*u*startX + 3*u*u*t*control1X + 3*u*t*t*control2X + t*t*t*targetX,
            y: u*u*u*startY + 3*u*u*t*control1Y + 3*u*t*t*control2Y + t*t*t*targetY
          };
        };
        const put = (x, y) => {
          flight.style.left = `${x - 16}px`;
          flight.style.top = `${y - 16}px`;
        };
        put(startX, startY);

        const tick = (now) => {
          const raw = Math.min(1, (now - started) / duration);
          const eased = 1 - Math.pow(1 - raw, 3);
          const p = pointAt(eased);
          const q = pointAt(Math.min(1, eased + .012));
          const angle = Math.atan2(q.y - p.y, q.x - p.x) * 180 / Math.PI + 18;
          put(p.x, p.y);
          flightSvg.style.transform = `rotate(${angle}deg) scale(${raw < .1 ? .78 + raw * 2.2 : 1})`;

          const speed = Math.min(2.7, Math.hypot(p.x - lastX, p.y - lastY) / 6);
          trails[0].style.transform = `translate(${-12 - speed * 9}px, ${speed * 3}px) rotate(${angle + 155}deg) scaleX(${1 + speed * .2})`;
          trails[1].style.transform = `translate(${-22 - speed * 14}px, ${-speed * 2}px) rotate(${angle + 155}deg) scaleX(${.8 + speed * .16})`;
          trails[0].style.opacity = `${.2 + speed * .22}`;
          trails[1].style.opacity = `${.1 + speed * .13}`;
          lastX = p.x;
          lastY = p.y;

          if (raw < 1) raf = requestAnimationFrame(tick);
        };
        raf = requestAnimationFrame(tick);

        window.setTimeout(() => {
          cancelAnimationFrame(raf);
          put(targetX, targetY);
          flight.classList.add('is-impact');
          createSendBurst(targetX, targetY);
          window.setTimeout(() => {
            flight.remove();
            resolve();
          }, 320);
        }, duration - 55);
      });
    }

    function createSendBurst(x, y) {
      const burst = document.createElement('div');
      burst.className = 'send-burst';
      burst.style.left = `${x}px`;
      burst.style.top = `${y}px`;
      burst.innerHTML = `
        <span class="send-burst__flash"></span>
        <span class="send-burst__ring"></span>
        <span class="send-popper send-popper--left"></span>
        <span class="send-popper send-popper--right"></span>
      `;

      const colors = ['#fff', '#eef3ff', '#9cc7ff', '#8f86ff', '#b895ff', '#71e0ff', '#f5d27f', '#dbe7ff'];
      const count = window.innerWidth < 640 ? 72 : 92;
      for (let i = 0; i < count; i += 1) {
        const p = document.createElement('span');
        const angle = (Math.PI * 2 * i) / count + (Math.random() - .5) * .26;
        const distance = (window.innerWidth < 640 ? 54 : 66) + Math.random() * (window.innerWidth < 640 ? 168 : 224);
        const depth = .68 + Math.random() * .65;
        const shape = Math.random();
        p.className = `send-burst__particle${shape > .82 ? ' is-ribbon' : shape > .54 ? ' is-dot' : ''}`;
        p.style.setProperty('--burst-x', `${Math.cos(angle) * distance}px`);
        p.style.setProperty('--burst-y', `${Math.sin(angle) * distance * depth}px`);
        p.style.setProperty('--burst-rotate', `${Math.round((Math.random() * 2 - 1) * 760)}deg`);
        p.style.setProperty('--burst-delay', `${Math.random() * 90}ms`);
        p.style.setProperty('--burst-duration', `${720 + Math.random() * 520}ms`);
        p.style.setProperty('--burst-color', colors[Math.floor(Math.random() * colors.length)]);
        burst.appendChild(p);
      }
      document.body.appendChild(burst);
      window.setTimeout(() => burst.remove(), 1750);
    }

    form.addEventListener('submit', async (e) => {
      if (window.__TECHIGRATE_CONTACT_EXPERIENCE_ACTIVE) return;
      e.preventDefault();

      if (!form.checkValidity()) {
        form.reportValidity();
        return;
      }

      const data = fieldsFromForm();
      submitBtn.disabled = true;
      submitBtn.setAttribute('aria-busy', 'true');
      if (btnText) btnText.textContent = 'Sending…';
      const celebration = launchSendCelebration(submitBtn);

      // Safety net only (the live path is contact-experience.js): open the visitor's email app with the details filled in,
      // and show the address in plain sight in case no email app is configured.
      let delivered = false;
      try {
        if (window.TGLeadTransport) {
          const result = await window.TGLeadTransport.postLead({
            name: data.name, email: data.email, company: data.company,
            service: data.projectType, budget: data.budget, message: data.message,
            website: (form.querySelector('#tg-website') || {}).value || '',
            source: window.location.href
          });
          delivered = !!(result && result.ok);
        }
      } catch (_) {}

      if (delivered) {
        setStatus('Message received. We\'ll reply within one business day.', false);
      } else {
        sendViaMailto(data);
        setStatus(
          `Opening your email app — if nothing happens, email us directly at <a href="mailto:${FALLBACK_EMAIL}">${FALLBACK_EMAIL}</a>. We'll reply within one business day.`,
          false
        );
      }

      await celebration;
      submitBtn.classList.add('is-complete');
      submitBtn.disabled = false;
      submitBtn.removeAttribute('aria-busy');
      if (btnText) btnText.textContent = 'Sent — message launched';
      window.setTimeout(() => {
        submitBtn.classList.remove('is-complete');
        if (btnText) btnText.textContent = 'Send message';
      }, 1800);
    });
  }

  /* ---- FAQ accordion ---- */
  document.querySelectorAll('.faq-question').forEach((btn) => {
    btn.addEventListener('click', () => {
      const item = btn.closest('.faq-item');
      const isOpen = item.classList.toggle('is-open');
      btn.setAttribute('aria-expanded', String(isOpen));
    });
  });
})();

