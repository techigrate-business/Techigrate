/* V5.2 compatibility entrypoint. The shared controller owns Work + homepage projects. */
