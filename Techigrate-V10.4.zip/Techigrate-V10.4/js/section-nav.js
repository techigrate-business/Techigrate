/* ==========================================================================
   TECHIGRATE — SECTION RAIL  (V09.4)

   Replaces the old pair of floating glass PREV / NEXT panels, which sat on
   the left/right edges and covered text. This is a slim right-edge rail:

   - one dot per top-level <section> under <main> (auto-detected, labels come
     from each section's heading, or <section data-section-name="...">)
   - a gradient line fills continuously with scroll position
   - hover / focus a dot to see its label; click to jump (Lenis-aware)
   - dock-style proximity swell on the dots near the pointer (desktop only)
   - keyboard: J / ] = next section, K / [ = previous (or top of current one)
   - fades out after a moment of inactivity, hides over the live hero scene,
     modals, the mobile menu and the search overlay
   - touch / narrow screens: a 3px segmented progress strip, nothing to tap

   Opt out per page with <body data-no-section-nav>. Skips itself on pages with
   fewer than 2 sections. Real <a href="#id"> links, so it also works without
   JS-driven scrolling. Any failure here is caught and the page is unaffected.
   ========================================================================== */
(function () {
  'use strict';

  try {
    if (document.body.hasAttribute('data-no-section-nav')) return;

    var sections = Array.prototype.slice.call(
      document.querySelectorAll('main > section, main > .sj-track > section')
    );
    var n = sections.length;
    if (n < 2) return;

    var reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    var IDLE_MS = 2600;

    /* ---- labels + ids ---- */
    function slugify(text, fallback) {
      var s = text.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 40);
      return s || fallback;
    }
    function shortLabel(text) {
      text = text.replace(/\s+/g, ' ').trim();
      if (text.length <= 34) return text;
      return text.slice(0, 34).replace(/\s+\S*$/, '') + '…';
    }
    var labels = sections.map(function (sec, i) {
      var h = sec.querySelector('h1, h2, h3');
      if (!sec.id) sec.id = slugify(h ? h.textContent : '', 'section-' + i);
      if (sec.dataset.sectionName) return sec.dataset.sectionName;
      return h ? shortLabel(h.textContent) : 'Section ' + (i + 1);
    });

    /* ---- build ---- */
    var rail = document.createElement('nav');
    rail.className = 'tg-rail is-entering';
    rail.setAttribute('aria-label', 'Page sections');
    rail.setAttribute('aria-keyshortcuts', 'J K');
    rail.style.setProperty('--n', String(n));

    var capsule = document.createElement('div');
    capsule.className = 'tg-rail-capsule';

    var line = document.createElement('span');
    line.className = 'tg-rail-line';
    line.setAttribute('aria-hidden', 'true');
    var fill = document.createElement('span');
    fill.className = 'tg-rail-fill';
    line.appendChild(fill);

    var list = document.createElement('ol');
    list.className = 'tg-rail-list';

    var items = sections.map(function (sec, i) {
      var li = document.createElement('li');
      var a = document.createElement('a');
      a.className = 'tg-rail-item';
      a.href = '#' + sec.id;
      a.setAttribute('data-index', String(i));
      var num = (i < 9 ? '0' : '') + (i + 1);
      var tick = document.createElement('span');
      tick.className = 'tg-rail-tick';
      var chip = document.createElement('span');
      chip.className = 'tg-rail-label';
      var b = document.createElement('b');
      b.textContent = num;
      var t = document.createElement('i');
      t.textContent = labels[i];
      chip.appendChild(b);
      chip.appendChild(t);
      a.appendChild(tick);
      a.appendChild(chip);
      li.appendChild(a);
      list.appendChild(li);
      return { li: li, a: a };
    });

    capsule.appendChild(line);
    capsule.appendChild(list);
    rail.appendChild(capsule);
    document.body.appendChild(rail);

    // let the first paint happen, then fade in
    function reveal() { rail.classList.remove('is-entering'); }
    if (reduced) reveal();
    else {
      requestAnimationFrame(function () { requestAnimationFrame(reveal); });
      window.setTimeout(reveal, 720); // never stay invisible
    }

    /* ---- scrolling ---- */
    var header = document.querySelector('.site-header');
    var headerH = header ? header.offsetHeight : 76;
    var currentIndex = 0;

    function scrollToSection(i) {
      if (i < 0 || i > n - 1) return;
      var y = sections[i].getBoundingClientRect().top + window.scrollY - (headerH + 16);
      y = Math.max(0, y);
      if (window.tgLenis) window.tgLenis.scrollTo(y, { immediate: reduced });
      else window.scrollTo({ top: y, behavior: reduced ? 'auto' : 'smooth' });
      ping(i);
      wake();
    }

    function ping(i) {
      var a = items[i].a;
      a.classList.remove('is-pinged');
      void a.offsetWidth;
      a.classList.add('is-pinged');
    }

    items.forEach(function (it, i) {
      it.a.addEventListener('click', function (e) {
        if (e.metaKey || e.ctrlKey || e.shiftKey || e.altKey || e.button > 0) return;
        e.preventDefault();
        scrollToSection(i);
        // a mouse click shouldn't leave the dot "focused" (it would keep the
        // rail awake and its label open); keyboard activation keeps focus.
        if (e.detail > 0) it.a.blur();
      });
    });

    /* ---- scrollspy + continuous progress ---- */
    var ticking = false;
    function clamp01(v) { return v < 0 ? 0 : v > 1 ? 1 : v; }

    function update() {
      ticking = false;
      var probe = headerH + window.innerHeight * 0.3;
      var idx = 0, i;
      for (i = 0; i < n; i++) {
        if (sections[i].getBoundingClientRect().top <= probe) idx = i;
      }
      var frac = 0;
      if (idx < n - 1) {
        var a = sections[idx].getBoundingClientRect().top;
        var b = sections[idx + 1].getBoundingClientRect().top;
        frac = b - a > 0 ? clamp01((probe - a) / (b - a)) : 0;
      }
      var doc = document.documentElement;
      if (window.scrollY + window.innerHeight >= doc.scrollHeight - 6 && window.scrollY > 0) {
        idx = n - 1;
        frac = 0;
        rail.style.setProperty('--rail-p', '1');
      } else {
        rail.style.setProperty('--rail-p', ((idx + frac) / (n - 1)).toFixed(4));
      }
      if (idx !== currentIndex || !items[idx].a.classList.contains('is-current')) {
        currentIndex = idx;
        items.forEach(function (it, k) {
          it.a.classList.toggle('is-current', k === idx);
          it.a.classList.toggle('is-past', k < idx);
          if (k === idx) it.a.setAttribute('aria-current', 'location');
          else it.a.removeAttribute('aria-current');
        });
      }
    }
    function onScroll() {
      wake();
      if (!ticking) { ticking = true; requestAnimationFrame(update); }
    }
    window.addEventListener('scroll', onScroll, { passive: true });
    window.addEventListener('resize', function () {
      headerH = header ? header.offsetHeight : 76;
      onScroll();
    }, { passive: true });

    /* ---- idle fade ---- */
    var idleTimer = 0;
    function wake() {
      rail.classList.remove('is-idle');
      window.clearTimeout(idleTimer);
      idleTimer = window.setTimeout(function () { rail.classList.add('is-idle'); }, IDLE_MS);
    }
    rail.addEventListener('focusin', wake);

    /* ---- dock-style proximity (fine pointers only) ---- */
    var finePointer = window.matchMedia('(hover: hover) and (pointer: fine)').matches;
    if (finePointer && !reduced) {
      var proxRaf = 0, lastY = 0;
      var applyProx = function () {
        proxRaf = 0;
        items.forEach(function (it) {
          var r = it.a.getBoundingClientRect();
          var d = Math.abs(lastY - (r.top + r.height / 2));
          it.li.style.setProperty('--p', clamp01(1 - d / 44).toFixed(3));
        });
      };
      rail.addEventListener('pointermove', function (e) {
        lastY = e.clientY;
        if (!proxRaf) proxRaf = requestAnimationFrame(applyProx);
      });
      rail.addEventListener('pointerleave', function () {
        if (proxRaf) { cancelAnimationFrame(proxRaf); proxRaf = 0; }
        items.forEach(function (it) { it.li.style.removeProperty('--p'); });
      });
    }

    /* ---- keyboard: J / ] next, K / [ previous (or start of current) ---- */
    function typingTarget(el) {
      if (!el) return false;
      var tag = (el.tagName || '').toLowerCase();
      return tag === 'input' || tag === 'textarea' || tag === 'select' || el.isContentEditable;
    }
    function blocked() {
      var root = document.documentElement;
      if (root.classList.contains('project-modal-open')) return true;
      var panel = document.querySelector('.mobile-panel');
      if (panel && panel.classList.contains('is-open')) return true;
      var search = document.querySelector('[data-nav-search-overlay]');
      if (search && !search.hidden) return true;
      return false;
    }
    document.addEventListener('keydown', function (e) {
      if (e.defaultPrevented || e.ctrlKey || e.metaKey || e.altKey) return;
      if (typingTarget(e.target) || blocked()) return;
      var k = e.key;
      var dir = (k === 'j' || k === 'J' || k === ']') ? 1 : (k === 'k' || k === 'K' || k === '[') ? -1 : 0;
      if (!dir) return;
      e.preventDefault();
      var target = currentIndex + dir;
      if (dir < 0) {
        // mid-section: first press goes to the top of the current section
        var off = sections[currentIndex].getBoundingClientRect().top - (headerH + 16);
        if (off < -80) target = currentIndex;
      }
      scrollToSection(Math.max(0, Math.min(n - 1, target)));
    });

    /* ---- hide behind the mobile menu ---- */
    var panelEl = document.querySelector('.mobile-panel');
    if (panelEl) {
      new MutationObserver(function () {
        rail.classList.toggle('is-suppressed', panelEl.classList.contains('is-open'));
      }).observe(panelEl, { attributes: true, attributeFilter: ['class'] });
    }

    update();
    wake();
  } catch (err) {
    console.error('Techigrate: section rail failed — page is unaffected otherwise', err);
  }
})();
