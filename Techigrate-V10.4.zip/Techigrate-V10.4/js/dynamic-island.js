/* ========================================================================== 
   TECHIGRATE — DYNAMIC ISLAND NAVIGATION / PHYSICS PASS
   - Independent compact composition: no Techigrate wordmark in the island.
   - Preserves the real theme switch + Start a Project controls.
   - Scroll input is sampled once per animation frame to avoid scroll-handler
     thrash and layout churn.
   - Pointer coordinates are captured cheaply; geometry is read at most once
     per frame while the island is interactive.
   ========================================================================== */
(function () {
  'use strict';

  const header = document.querySelector('.site-header');
  if (!header || header.dataset.tgIslandReady === 'true') return;

  const navInner = header.querySelector('.nav-inner');
  if (!navInner) return;

  header.dataset.tgIslandReady = 'true';
  header.classList.add('tg-dynamic-island');

  const pages = [
    ['services', 'Services'],
    ['work', 'Work'],
    ['technology', 'Technology'],
    ['about', 'About'],
    ['contact', 'Contact']
  ];

  const path = (window.location.pathname.split('/').pop() || 'index.html').toLowerCase();
  const pageKey = path.replace(/\.html$/, '') || 'index';
  const pageMeta = pages.find(([key]) => pageKey === key);
  const pageIndex = pageMeta ? pages.findIndex(([key]) => pageKey === key) + 1 : 0;

  const island = document.createElement('div');
  island.className = 'tg-island';
  island.setAttribute('aria-hidden', 'true');
  island.innerHTML = `
    <span class="tg-island__surface" aria-hidden="true">
      <span class="tg-island__sheen"></span>
      <span class="tg-island__spot"></span>
      <span class="tg-island__scan"></span>
    </span>
    <span class="tg-island__status" aria-hidden="true"><i></i></span>
    <span class="tg-island__title-wrap"><span class="tg-island__title"></span></span>
    <span class="tg-island__divider" aria-hidden="true"></span>
    <span class="tg-island__count"></span>
    <span class="tg-island__progress" aria-hidden="true"><span></span></span>
    <span class="tg-island__spark" aria-hidden="true"></span>
    <span class="tg-island__ring" aria-hidden="true"></span>
  `;
  header.appendChild(island);

  const titleEl = island.querySelector('.tg-island__title');
  const countEl = island.querySelector('.tg-island__count');
  const progressEl = island.querySelector('.tg-island__progress > span');
  const reduceQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
  const touchQuery = window.matchMedia('(hover: none)');
  const coarseQuery = window.matchMedia('(pointer: coarse)');

  const updateMotionMode = () => {
    header.classList.toggle('tg-motion-reduced', reduceQuery.matches);
    header.classList.toggle('tg-island-touch', touchQuery.matches || coarseQuery.matches);
  };
  updateMotionMode();
  reduceQuery.addEventListener?.('change', updateMotionMode);
  touchQuery.addEventListener?.('change', updateMotionMode);
  coarseQuery.addEventListener?.('change', updateMotionMode);

  if (pageMeta) {
    titleEl.textContent = pageMeta[1];
    countEl.textContent = `${String(pageIndex).padStart(2, '0')} / 06`;
  } else if (pageKey === 'privacy') {
    titleEl.textContent = 'Privacy';
    countEl.textContent = 'LEGAL';
  } else if (pageKey === 'terms') {
    titleEl.textContent = 'Terms';
    countEl.textContent = 'LEGAL';
  } else if (pageKey === '404') {
    titleEl.textContent = '404';
    countEl.textContent = 'NOT FOUND';
  } else {
    titleEl.textContent = 'Home';
    countEl.textContent = '—';
  }

  const clamp = (value, min, max) => Math.max(min, Math.min(max, value));
  const lerp = (current, target, amount) => current + (target - current) * amount;
  const setVar = (name, value, digits = 4) => {
    const next = typeof value === 'number' ? value.toFixed(digits) : value;
    if (header.style.getPropertyValue(name) !== next) header.style.setProperty(name, next);
  };

  let targetPointerX = 0;
  let targetPointerY = 0;
  let currentPointerX = 0;
  let currentPointerY = 0;
  let pointerVelocityX = 0;
  let pointerVelocityY = 0;
  let lastPointerX = 0;
  let lastPointerY = 0;
  let pointerSeen = false;

  let targetHover = 0;
  let currentHover = 0;
  let targetLift = 0;
  let currentLift = 0;
  let currentEnergy = 0;
  let collapse = 0;
  let scrollProgress = 0;
  let latestScrollY = window.scrollY || 0;
  let previousScrollY = latestScrollY;
  let scrollVelocity = 0;
  let scrollEnergy = 0;
  let lastRenderedProgress = -1;
  let maxScroll = Math.max(1, document.documentElement.scrollHeight - window.innerHeight);
  let metricsDirty = false;
  let frameId = 0;
  let hoverTimer = 0;
  let rect = null;
  let lastRectFrame = -1;
  let frameCount = 0;

  const refreshScrollMetrics = () => {
    maxScroll = Math.max(1, document.documentElement.scrollHeight - window.innerHeight);
    metricsDirty = false;
  };

  const onScroll = () => {
    latestScrollY = window.scrollY || window.pageYOffset || 0;
  };

  const refreshRect = () => {
    if (!pointerSeen || !header.classList.contains('is-island-active')) return;
    if (lastRectFrame === frameCount) return;
    rect = island.getBoundingClientRect();
    lastRectFrame = frameCount;
  };

  const setPointer = (event) => {
    if (event.pointerType && event.pointerType !== 'mouse') return;

    pointerSeen = true;

    refreshRect();
    if (!rect || !rect.width || !rect.height) return;

    const nx = clamp(((event.clientX - rect.left) / rect.width - 0.5) * 2, -1, 1);
    const ny = clamp(((event.clientY - rect.top) / rect.height - 0.5) * 2, -1, 1);
    const dx = nx - lastPointerX;
    const dy = ny - lastPointerY;

    pointerVelocityX = dx;
    pointerVelocityY = dy;
    lastPointerX = nx;
    lastPointerY = ny;
    targetPointerX = nx;
    targetPointerY = ny;
  };

  const pulse = (type) => {
    if (reduceQuery.matches) return;
    island.classList.remove('is-pulsing', 'is-snap');
    void island.offsetWidth;
    island.classList.add(type === 'snap' ? 'is-snap' : 'is-pulsing');
    window.clearTimeout(island._pulseTimer);
    island._pulseTimer = window.setTimeout(() => {
      island.classList.remove('is-pulsing', 'is-snap');
    }, type === 'snap' ? 520 : 660);
  };

  const expand = () => {
    if (touchQuery.matches || coarseQuery.matches || reduceQuery.matches || collapse < 0.1) return;
    window.clearTimeout(hoverTimer);
    targetHover = 1;
    targetLift = 1;
    header.classList.add('is-island-hovered');
  };

  const collapseIsland = () => {
    window.clearTimeout(hoverTimer);
    hoverTimer = window.setTimeout(() => {
      targetHover = 0;
      targetLift = 0;
      header.classList.remove('is-island-hovered');
    }, 90);
  };

  const onVisibility = () => {
    if (document.hidden) {
      pointerVelocityX = pointerVelocityY = 0;
      scrollEnergy = 0;
      targetHover = targetLift = 0;
      header.classList.remove('is-island-hovered');
    }
  };

  const updateState = () => {
    const y = latestScrollY;
    const delta = clamp(y - previousScrollY, -48, 48);
    previousScrollY = y;

    scrollVelocity = delta;
    scrollEnergy = lerp(scrollEnergy, clamp(Math.abs(delta) / 24, 0, 1), 0.24);
    collapse = clamp((y - 12) / 158, 0, 1);
    scrollProgress = clamp(y / maxScroll, 0, 1);

    setVar('--tg-collapse', collapse);
    setVar('--tg-scroll-energy', scrollEnergy);
    setVar('--tg-scroll-velocity', scrollVelocity, 2);

    const islandActive = collapse > 0.07 && !touchQuery.matches && !coarseQuery.matches;
    header.classList.toggle('is-island-active', islandActive);

    if (!islandActive) {
      targetHover = 0;
      targetLift = 0;
      header.classList.remove('is-island-hovered');
    }

    if (Math.abs(scrollProgress - lastRenderedProgress) > 0.003 || scrollProgress === 0 || scrollProgress === 1) {
      lastRenderedProgress = scrollProgress;
      progressEl.style.transform = `scaleX(${scrollProgress.toFixed(4)})`;
    }
  };

  const render = () => {
    frameId = requestAnimationFrame(render);
    frameCount += 1;

    if (document.hidden) return;

    if (metricsDirty) refreshScrollMetrics();
    updateState();

    const reduced = reduceQuery.matches;
    const motionScale = reduced ? 0 : 1;

    currentPointerX = lerp(currentPointerX, targetPointerX, reduced ? 1 : 0.12);
    currentPointerY = lerp(currentPointerY, targetPointerY, reduced ? 1 : 0.12);
    currentHover = lerp(currentHover, targetHover, reduced ? 1 : 0.16);
    currentLift = lerp(currentLift, targetLift, reduced ? 1 : 0.15);
    currentEnergy = lerp(currentEnergy, clamp(Math.abs(pointerVelocityX) + Math.abs(pointerVelocityY) + scrollEnergy * 0.28, 0, 1), reduced ? 0 : 0.09);

    const dampedVelocityX = pointerVelocityX * 18 * motionScale + scrollVelocity * 0.06;
    const dampedVelocityY = pointerVelocityY * 12 * motionScale;
    const rotateX = -currentPointerY * (1.4 + currentHover * 4.3) * motionScale + dampedVelocityY;
    const rotateY = currentPointerX * (3.4 + currentHover * 8.2) * motionScale + dampedVelocityX;
    const rotateZ = clamp(pointerVelocityX * 2.6 - pointerVelocityY * 1.6, -3.4, 3.4) * motionScale;

    setVar('--tg-mx', currentPointerX);
    setVar('--tg-my', currentPointerY);
    setVar('--tg-rx', `${rotateX.toFixed(2)}deg`, 2);
    setVar('--tg-ry', `${rotateY.toFixed(2)}deg`, 2);
    setVar('--tg-rz', `${rotateZ.toFixed(2)}deg`, 2);
    setVar('--tg-hover', currentHover);
    setVar('--tg-lift', currentLift);
    setVar('--tg-energy', currentEnergy);

    pointerVelocityX *= reduced ? 0 : 0.82;
    pointerVelocityY *= reduced ? 0 : 0.82;
  };

  island.addEventListener('pointerenter', () => {
    expand();
    pulse('hover');
  }, { passive: true });
  island.addEventListener('pointermove', setPointer, { passive: true });
  island.addEventListener('pointerleave', collapseIsland, { passive: true });

  /* The expanded navbar owns its own hover area. This replaces the old
     pointermove + getBoundingClientRect loop that caused unnecessary layout
     reads whenever the cursor moved across the expanded header. */
  navInner.addEventListener('pointerenter', () => {
    if (collapse > 0.1) {
      window.clearTimeout(hoverTimer);
      targetHover = 1;
      targetLift = 1;
    }
  }, { passive: true });
  navInner.addEventListener('pointerleave', collapseIsland, { passive: true });
  navInner.addEventListener('pointermove', setPointer, { passive: true });

  window.addEventListener('scroll', onScroll, { passive: true });
  window.addEventListener('resize', () => { metricsDirty = true; }, { passive: true });
  window.addEventListener('orientationchange', () => { metricsDirty = true; }, { passive: true });
  window.addEventListener('blur', () => {
    targetPointerX = targetPointerY = 0;
    pointerVelocityX = pointerVelocityY = 0;
    targetHover = targetLift = 0;
    header.classList.remove('is-island-hovered');
  }, { passive: true });
  document.addEventListener('visibilitychange', onVisibility, { passive: true });

  if ('ResizeObserver' in window) {
    const resizeObserver = new ResizeObserver(() => {
      metricsDirty = true;
    });
    resizeObserver.observe(document.documentElement);
  }

  refreshScrollMetrics();
  header.classList.add('tg-island-ready');
  render();
})();
