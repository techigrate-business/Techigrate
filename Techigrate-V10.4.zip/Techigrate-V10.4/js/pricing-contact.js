(function(){
  'use strict';

  var root = document.querySelector('[data-tg-pricing]');
  if(!root) return;

  var card = root.querySelector('[data-tg-pricing-card]');
  var nameEl = root.querySelector('[data-tg-name]');
  var kickerEl = root.querySelector('[data-tg-kicker]');
  var badgeEl = root.querySelector('[data-tg-badge]');
  var priceEl = root.querySelector('[data-tg-price]');
  var noteEl = root.querySelector('[data-tg-note]');
  var timelineEl = root.querySelector('[data-tg-scope]');
  var bestEl = root.querySelector('[data-tg-best]');
  var deliverablesEl = root.querySelector('[data-tg-deliverables]');
  var featuresEl = root.querySelector('[data-tg-features]');
  var cta = root.querySelector('[data-tg-price-cta]');
  var artEl = root.querySelector('[data-tg-art]');
  var artCaptionEl = root.querySelector('[data-tg-art-caption]');
  var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var fine = window.matchMedia('(pointer:fine)').matches;

  var sparkLayer = document.createElement('div');
  sparkLayer.className = 'tg-pricing-click-layer';
  sparkLayer.setAttribute('aria-hidden','true');
  document.body.appendChild(sparkLayer);

  var icons = [
    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="5" width="18" height="13" rx="2"/><path d="M8 21h8M12 18v3"/></svg>',
    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="7" y="2.8" width="10" height="18.4" rx="2"/><path d="M10 5h4M11 18.2h2"/></svg>',
    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m5 8 7-4 7 4-7 4-7-4Z"/><path d="m5 12 7 4 7-4M5 16l7 4 7-4"/></svg>',
    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m6 4 14 8-7 2-3 6-4-16Z"/></svg>',
    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M13 2 4 14h6l-1 8 9-12h-6l1-8Z"/></svg>',
    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M13 3h7v7M11 13 20 4M20 14v5a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h5"/></svg>'
  ];

  var plans = {
    silver:{
      kicker:'ENTRY BUILD',
      name:'Silver',
      badge:'FOUNDATION',
      price:'500–2,000',
      note:'A polished starting point for focused websites, landing pages and simple business needs.',
      timeline:'1–2 weeks',
      bestFor:'Startups / Small Businesses',
      deliverables:'Design + Development + Support',
      art:'assets/pricing/silver-orbit.svg',
      artAlt:'Silver metallic sphere with luminous orbit rings',
      artCaption:'Start simple',
      features:[
        ['Focused landing page / small site','included'],
        ['Responsive mobile + desktop','included'],
        ['Clean sections + navigation','included'],
        ['Essential CTA / contact flow','included'],
        ['Basic motion & micro-interactions','included'],
        ['Advanced integrations','custom']
      ]
    },
    gold:{
      kicker:'GROWTH BUILD',
      name:'Gold',
      badge:'MOST POPULAR',
      price:'2,000–5,000',
      note:'Everything needed to launch a professional, high-performing site for a growing business.',
      timeline:'2–4 weeks',
      bestFor:'Growing Businesses',
      deliverables:'Design + Development + Basic Integrations',
      art:'assets/pricing/gold-orbit.svg',
      artAlt:'Gold metallic sphere with luminous orbit rings',
      artCaption:'Build bigger',
      features:[
        ['Custom multi-page website','included'],
        ['Responsive mobile + desktop','included'],
        ['Advanced UI / UX design','included'],
        ['Contact forms & CTA flows','included'],
        ['Animations & interactions','included'],
        ['Basic integrations (Analytics, CRM, etc.)','included']
      ]
    },
    platinum:{
      kicker:'PREMIUM BUILD',
      name:'Platinum',
      badge:'MOST CHOSEN',
      price:'5,000–10,000',
      note:'More power, more possibilities — for ambitious brands that need a distinctive visual and motion system.',
      timeline:'3–6 weeks',
      bestFor:'Startups & Growing Businesses',
      deliverables:'Full Website + Integrations',
      art:'assets/pricing/platinum-orbit.svg',
      artAlt:'Platinum violet metallic sphere with glowing orbital trails',
      artCaption:'Scale faster',
      features:[
        ['Everything in Gold','included'],
        ['Custom UI / UX design system','included'],
        ['Advanced animations & interactions','included'],
        ['CMS / easy content management','included'],
        ['SEO & performance optimization','included'],
        ['Priority support & revisions','included']
      ]
    },
    diamond:{
      kicker:'BESPOKE BUILD',
      name:'Diamond',
      badge:'PREMIUM',
      price:'10,000+',
      note:'No limits. Just impact. A fully custom, high-performance solution tailored to your goals and built to scale.',
      timeline:'4–12+ weeks',
      bestFor:'Established Businesses / Enterprises',
      deliverables:'Fully Custom Solution',
      art:'assets/pricing/diamond-orbit.svg',
      artAlt:'Faceted diamond with cyan and blue luminous orbit trails',
      artCaption:'Limitless possibilities',
      features:[
        ['Everything in Platinum','included'],
        ['Custom features & functionality','included'],
        ['Advanced integrations (APIs, CRM, etc.)','included'],
        ['Scalability & enterprise-ready setup','included'],
        ['Dedicated project manager','included'],
        ['Extended support & maintenance','included']
      ]
    }
  };

  var swapEls = [];
  function setText(el,text){
    if(!el) return;
    el.textContent=text;
    if(!reduce) swapEls.push(el);
  }

  function renderFeatures(items){
    var frag=document.createDocumentFragment();
    items.forEach(function(item,i){
      var row=document.createElement('div');
      row.className='tg-feature';
      row.style.animationDelay=(35+i*35)+'ms';

      var icon=document.createElement('span');
      icon.className='tg-feature-icon'+(item[1]==='custom'?' custom':'');
      icon.innerHTML=icons[i % icons.length];

      var copy=document.createElement('div');
      copy.className='tg-feature-copy';
      copy.appendChild(document.createTextNode(item[0]));
      copy.appendChild(document.createElement('br'));

      var tag=document.createElement('span');
      tag.className='tg-feature-tag '+item[1];
      tag.textContent=item[1]==='included'?'Included':'Custom';
      copy.appendChild(tag);

      row.append(icon,copy);
      frag.appendChild(row);
    });
    featuresEl.replaceChildren(frag);
  }

  // Warm the four lightweight SVG materials once; later tier switches stay image-cache hot.
  Object.keys(plans).forEach(function(key){
    var preloader=new Image();
    preloader.decoding='async';
    preloader.src=plans[key].art;
  });

  function syncForm(key,scroll){
    var form=document.querySelector('.contact-form');
    if(!form) return;
    var budget=form.querySelector('#budget');
    if(budget){
      budget.value=key;
      budget.dispatchEvent(new Event('change',{bubbles:true}));
    }
    var summaryBadge=form.querySelector('[data-selected-plan]');
    if(summaryBadge){
      summaryBadge.textContent=plans[key].name+' · ₹'+plans[key].price;
      summaryBadge.dataset.plan=key;
    }
    try{
      window.sessionStorage.setItem('techigrateSelectedPlan',JSON.stringify({
        plan:key,budget:key,price:plans[key].price,selectedAt:new Date().toISOString()
      }));
    }catch(e){}

    document.dispatchEvent(new CustomEvent('techigrate:pricing-selected',{detail:{plan:key,price:plans[key].price}}));

    if(scroll){
      var formAnchor=document.getElementById('contact-form');
      if(formAnchor){
        setTimeout(function(){
          if(window.tgLenis){
            window.tgLenis.scrollTo(formAnchor,{immediate:reduce,offset:-24});
          }else{
            formAnchor.scrollIntoView({behavior:reduce?'auto':'smooth',block:'start'});
          }
          var first=formAnchor.querySelector('input,select,textarea');
          if(first){setTimeout(function(){try{first.focus({preventScroll:true});}catch(e){first.focus();}},reduce?0:420);}
        },reduce?0:120);
      }
    }
  }

  function render(key){
    var p=plans[key];
    if(!p) return;

    root.dataset.plan=key;
    root.setAttribute('aria-describedby','tg-pricing-title');

    swapEls.length=0;
    setText(nameEl,p.name);
    setText(kickerEl,p.kicker);
    setText(badgeEl,p.badge);
    setText(priceEl,p.price);
    setText(noteEl,p.note);
    setText(timelineEl,p.timeline);
    setText(bestEl,p.bestFor);
    setText(deliverablesEl,p.deliverables);
    setText(artCaptionEl,p.artCaption);

    if(artEl){
      artEl.src=p.art;
      artEl.alt=p.artAlt;
    }

    renderFeatures(p.features);
    cta.dataset.plan=key;
    cta.innerHTML='Continue with '+p.name+' <span aria-hidden="true">→</span>';
    if(!reduce && swapEls.length){
      swapEls.forEach(function(el){el.classList.remove('tg-text-swap');});
      requestAnimationFrame(function(){
        swapEls.forEach(function(el){el.classList.add('tg-text-swap');});
      });
    }
    syncForm(key,false);
  }

  root.querySelectorAll('input[name="tg-plan"]').forEach(function(input){
    input.addEventListener('change',function(){render(input.value);});
  });

  cta.addEventListener('click',function(){
    var key=cta.getAttribute('data-plan') || 'silver';
    syncForm(key,true);
  });

  if(!reduce && fine){
    /* Perf (V09): the old loop wrote --tg-mx/--tg-my on the card every frame (custom properties inherit, so every
       descendant was restyled and the ::after gradient repainted) and read getBoundingClientRect() in every
       pointermove while styles were dirty (forced layout). Now: the card rect is cached, the spotlight is a real
       element moved with transform only, and nothing is written when a frame has no change. */
    var active=false, raf=0, rect=null, stale=true;
    var targetRX=0, targetRY=0, currentRX=0, currentRY=0, targetX=0, targetY=0, currentX=0, currentY=0;
    var pointerPX=.5, pointerPY=.5, lastT='', lastS='';
    var spotWrap=document.createElement('span');
    spotWrap.className='tg-spot-wrap'; spotWrap.setAttribute('aria-hidden','true');
    var spot=document.createElement('span'); spot.className='tg-spot';
    spotWrap.appendChild(spot); card.appendChild(spotWrap);

    function measure(){ rect=card.getBoundingClientRect(); stale=false; }
    addEventListener('scroll',function(){stale=true},{passive:true});
    addEventListener('resize',function(){stale=true},{passive:true});

    function tick(){
      currentRX+=(targetRX-currentRX)*.18;
      currentRY+=(targetRY-currentRY)*.18;
      currentX+=(targetX-currentX)*.20;
      currentY+=(targetY-currentY)*.20;
      var t='perspective(1500px) rotateX('+currentRY.toFixed(3)+'deg) rotateY('+currentRX.toFixed(3)+'deg) translate3d('+currentX.toFixed(3)+'px,'+currentY.toFixed(3)+'px,0)';
      if(t!==lastT){ card.style.transform=t; lastT=t; }
      var w=card.offsetWidth, sz=w*.78;
      var st='translate3d('+(pointerPX*w-sz/2).toFixed(1)+'px,'+(pointerPY*card.offsetHeight-sz/2).toFixed(1)+'px,0)';
      if(st!==lastS){ spot.style.width=spot.style.height=sz.toFixed(0)+'px'; spot.style.transform=st; lastS=st; }
      var settled=Math.abs(targetRX-currentRX)+Math.abs(targetRY-currentRY)+Math.abs(targetX-currentX)+Math.abs(targetY-currentY)<.018;
      if(active||!settled) raf=requestAnimationFrame(tick); else { raf=0; }
    }
    function schedule(){if(!raf) raf=requestAnimationFrame(tick)}
    card.addEventListener('pointerenter',function(){active=true;stale=true;card.classList.add('is-hovered');schedule()});
    card.addEventListener('pointermove',function(e){
      if(stale||!rect) measure();
      pointerPX=Math.max(0,Math.min(1,(e.clientX-rect.left)/rect.width));
      pointerPY=Math.max(0,Math.min(1,(e.clientY-rect.top)/rect.height));
      targetRX=(pointerPX-.5)*3.8;
      targetRY=(.5-pointerPY)*3.0;
      targetX=(pointerPX-.5)*1.0;
      targetY=(pointerPY-.5)*.8;
      schedule();
    });
    card.addEventListener('pointerleave',function(){
      active=false;
      card.classList.remove('is-hovered');
      targetRX=targetRY=targetX=targetY=0;
      schedule();
    });
  }

  root.addEventListener('click',function(e){
    if(reduce) return;
    var target=e.target.closest('label,button');
    if(!target) return;
    var rect=root.getBoundingClientRect();
    if(e.clientX<rect.left||e.clientX>rect.right||e.clientY<rect.top||e.clientY>rect.bottom) return;

    var frag=document.createDocumentFragment();
    for(var i=0;i<6;i++){
      var s=document.createElement('span');
      s.className='tg-spark';
      var angle=(Math.PI*2*i/6)+(Math.random()-.5)*.22;
      var distance=18+Math.random()*16;
      var size=4.5+Math.random()*2.2;
      s.style.left=e.clientX+'px';
      s.style.top=e.clientY+'px';
      s.style.width=size+'px';
      s.style.height=size+'px';
      s.style.setProperty('--sx',Math.cos(angle)*distance+'px');
      s.style.setProperty('--sy',Math.sin(angle)*distance+'px');
      s.style.setProperty('--spark-rgb',getComputedStyle(root).getPropertyValue('--tg-rgb').trim());
      frag.appendChild(s);
      s.addEventListener('animationend',function(){this.remove();},{once:true});
      window.setTimeout(function(){if(s.isConnected)s.remove();},720);
    }
    sparkLayer.appendChild(frag);
  });

  // Keeps the existing form/sessionStorage behavior while making the initial
  // visible plan the same plan that the radio group has selected.
  var initial=root.querySelector('input[name="tg-plan"]:checked');
  render(initial?initial.value:'silver');
})();
