(function(){
  'use strict';
  var reduce=window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var fine=window.matchMedia('(pointer:fine)').matches;
  if(reduce) return;
  var blocked=function(){
    return document.body && (document.body.classList.contains('tg-preloading') || document.body.classList.contains('tg-stair-handoff-active') || document.body.classList.contains('project-modal-body-locked'));
  };
  var layer=document.createElement('div'); layer.className='tg-click-spark-layer'; layer.setAttribute('aria-hidden','true'); document.body.appendChild(layer);
  function burst(x,y){
    if(blocked()) return;
    var count=fine?7:5;
    for(var i=0;i<count;i++){
      var s=document.createElement('span'); s.className='tg-click-spark';
      var angle=(Math.PI*2/count)*i + (Math.random()-.5)*.28;
      var dist=(fine?18:14)+Math.random()*(fine?14:9);
      var size=2+Math.random()*2.2;
      s.style.left=x+'px'; s.style.top=y+'px'; s.style.width=size+'px'; s.style.height=size+'px';
      s.style.setProperty('--sx',Math.cos(angle)*dist+'px'); s.style.setProperty('--sy',Math.sin(angle)*dist+'px');
      layer.appendChild(s); s.addEventListener('animationend',function(){this.remove();},{once:true});
    }
    var ring=document.createElement('span'); ring.className='tg-click-spark-ring'; ring.style.left=x+'px'; ring.style.top=y+'px'; layer.appendChild(ring); ring.addEventListener('animationend',function(){this.remove();},{once:true});
  }
  window.addEventListener('pointerdown',function(e){ if(e.pointerType==='mouse' || e.pointerType==='pen') burst(e.clientX,e.clientY); },{passive:true});
})();
