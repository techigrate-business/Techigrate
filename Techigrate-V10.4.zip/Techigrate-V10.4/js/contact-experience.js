/* ========================================================================== 
   CONTACT EXPERIENCE v6.1
   Stateful form UX layered on top of the existing contact page.
   - inline validation
   - session draft
   - completion/readiness rail
   - success state
   - premium send-flight celebration
   - subtle field + card interactions
   ========================================================================== */
(function () {
  'use strict';

  const SITE = window.TECHIGRATE_SITE || {};            // js/site-config.js — the one place these live
  const APPS_SCRIPT_URL = SITE.appsScriptUrl || '';
  const FALLBACK_EMAIL = SITE.email || '';
  const DRAFT_KEY = 'techigrate-contact-draft-v6';
  const form = document.querySelector('.contact-form');
  if (!form) return;
  window.__TECHIGRATE_CONTACT_EXPERIENCE_ACTIVE = true;

  const submitBtn = form.querySelector('.send-btn');
  const btnText = submitBtn?.querySelector('.send-btn-text');
  const status = form.querySelector('.form-status');
  const successPanel = form.querySelector('[data-contact-success]');
  const successKicker = form.querySelector('[data-contact-success-kicker]');
  const successTitle = form.querySelector('[data-contact-success-title]');
  const successCopy = form.querySelector('[data-contact-success-copy]');
  const sendAnother = form.querySelector('[data-contact-send-another]');
  const completionFill = form.querySelector('[data-form-completion-fill]');
  const completionValue = form.querySelector('[data-form-completion-value]');
  const draftStatus = form.querySelector('[data-form-draft-status]');
  const fields = ['name', 'email', 'company', 'project-type', 'budget', 'message'];
  const coreFields = ['name', 'email', 'project-type', 'message'];
  const requiredFields = ['name', 'email', 'message'];

  let draftTimer = 0;
  let draftButton = null;
  let isSubmitting = false;

  const reducedMotion = () => !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);

  function escapeText(value) {
    return String(value ?? '').replace(/[&<>'"]/g, (c) => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', "'":'&#39;', '"':'&quot;' }[c]));
  }

  function valueOf(id) {
    return form.querySelector('#' + id)?.value?.trim() || '';
  }

  function labelFor(id) {
    const el = form.querySelector('#' + id);
    return el?.value ? (el.selectedOptions?.[0]?.text || el.value) : '';
  }

  function validateField(id, { show = false } = {}) {
    const el = form.querySelector('#' + id);
    if (!el) return true;
    const field = el.closest('.field');
    if (!field) return true;

    let message = '';
    const value = el.value.trim();

    if (id === 'name') {
      if (!value) message = 'Tell us who we should reply to.';
      else if (value.length < 2) message = 'Please enter at least 2 characters.';
    } else if (id === 'email') {
      if (!value) message = 'We need an email so we can reply.';
      else if (!el.validity?.valid || !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(value)) message = 'That email address looks incomplete.';
    } else if (id === 'message') {
      if (!value) message = 'Give us at least a little context about the project.';
      else if (value.length < 20) message = 'A little more context helps us understand the build.';
      else if (value.length > 1800) message = 'Please keep the project brief under 1,800 characters.';
    }

    const invalid = Boolean(message);
    field.classList.toggle('is-error', invalid && show);
    field.classList.toggle('is-valid', !invalid && value.length > 0);
    el.setAttribute('aria-invalid', String(invalid));

    const note = field.querySelector('.contact-field-message > span');
    if (note) note.textContent = message;
    const ok = field.querySelector('.contact-field-ok');
    if (ok) ok.hidden = invalid || !value;

    return !invalid;
  }

  function setupField(el) {
    const field = el.closest('.field');
    if (!field) return;

    field.dataset.field = el.id;
    if (el.tagName.toLowerCase() === 'textarea') {
      field.classList.add('is-textarea');
      el.maxLength = 1800;
    }

    // Wrap controls once so the validation/check affordances never alter layout unpredictably.
    if (!el.parentElement?.classList.contains('field-control-wrap')) {
      const wrap = document.createElement('div');
      wrap.className = 'field-control-wrap';
      el.parentNode.insertBefore(wrap, el);
      wrap.appendChild(el);
      const ok = document.createElement('span');
      ok.className = 'contact-field-ok';
      ok.setAttribute('aria-hidden', 'true');
      ok.innerHTML = '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="2"><path d="m3 8 3 3 7-7"/></svg>';
      wrap.appendChild(ok);
    }

    if (!field.querySelector('.contact-field-message')) {
      const note = document.createElement('div');
      note.className = 'contact-field-message';
      note.id = `${el.id}-error`;
      note.setAttribute('aria-live', 'polite');
      el.setAttribute('aria-describedby', note.id);
      note.innerHTML = '<span></span>';
      field.appendChild(note);
    }

    if (el.id === 'message' && !field.querySelector('.field-footer')) {
      const footer = document.createElement('div');
      footer.className = 'field-footer';
      const count = document.createElement('span');
      count.className = 'field-count';
      count.dataset.fieldCount = 'message';
      footer.appendChild(count);
      field.appendChild(footer);
      updateCounter(el);
    }

    const onInput = () => {
      validateField(el.id, { show: false });
      field.classList.remove('is-error');
      updateCompletion();
      scheduleDraftSave();
      if (el.id === 'message') updateCounter(el);
      updateReadyState();
    };
    const onBlur = () => {
      validateField(el.id, { show: true });
      updateCompletion();
      updateReadyState();
      saveDraftNow();
    };
    const onFocus = () => field.classList.add('is-focused');
    const onFocusOut = () => field.classList.remove('is-focused');

    el.addEventListener('input', onInput);
    el.addEventListener('change', onInput);
    el.addEventListener('blur', onBlur);
    el.addEventListener('focus', onFocus);
    el.addEventListener('focusout', onFocusOut);

    field.addEventListener('pointermove', (event) => {
      if (event.pointerType === 'touch') return;
      const rect = field.getBoundingClientRect();
      field.style.setProperty('--field-x', `${Math.max(0, Math.min(100, ((event.clientX - rect.left) / rect.width) * 100))}%`);
    });
  }

  function updateCounter(el) {
    const count = form.querySelector('[data-field-count="message"]');
    if (!count) return;
    const length = el.value.length;
    const max = 1800;
    count.textContent = `${length.toLocaleString()} / ${max.toLocaleString()}`;
    count.classList.toggle('is-near-limit', length > 1550 && length <= max);
    count.classList.toggle('is-limit', length > max);
  }

  function fieldLooksComplete(id) {
    const el = form.querySelector('#' + id);
    if (!el || !el.value.trim()) return false;
    return validateField(id, { show: false });
  }

  function updateCompletion() {
    const complete = coreFields.filter(fieldLooksComplete).length;
    const percent = Math.round((complete / coreFields.length) * 100);
    if (completionFill) completionFill.style.width = `${percent}%`;
    if (completionValue) {
      completionValue.textContent = `${percent}%`;
      completionValue.classList.toggle('is-ready', requiredFields.every(fieldLooksComplete));
    }
  }

  function updateReadyState() {
    const ready = requiredFields.every(fieldLooksComplete);
    submitBtn?.classList.toggle('is-ready', ready);
  }

  function setDraftText(text, mode = '') {
    if (!draftStatus) return;
    draftStatus.textContent = '';
    draftStatus.className = `form-draft-status${mode ? ` is-${mode}` : ''}`;
    const textSpan = document.createElement('span');
    textSpan.textContent = text;
    draftStatus.appendChild(textSpan);
    if (draftButton) draftButton.remove();
    draftButton = null;
    if (mode === 'restored') {
      draftButton = document.createElement('button');
      draftButton.type = 'button';
      draftButton.className = 'form-draft-clear';
      draftButton.textContent = 'Clear';
      draftButton.addEventListener('click', clearDraft);
      draftStatus.appendChild(draftButton);
    }
  }

  function draftPayload() {
    const data = {};
    fields.forEach((id) => {
      const el = form.querySelector('#' + id);
      if (el) data[id] = el.value || '';
    });
    return data;
  }

  function saveDraftNow() {
    if (isSubmitting) return;
    try {
      const payload = draftPayload();
      const hasContent = Object.values(payload).some(Boolean);
      if (!hasContent) {
        sessionStorage.removeItem(DRAFT_KEY);
        setDraftText('Draft stays in this tab');
        return;
      }
      sessionStorage.setItem(DRAFT_KEY, JSON.stringify({ ...payload, savedAt: Date.now() }));
      setDraftText('Draft saved in this tab', 'saved');
    } catch (_) {}
  }

  function scheduleDraftSave() {
    clearTimeout(draftTimer);
    draftTimer = window.setTimeout(saveDraftNow, 260);
  }

  function clearDraft() {
    try { sessionStorage.removeItem(DRAFT_KEY); } catch (_) {}
    form.reset();
    form.querySelectorAll('.field').forEach((field) => field.classList.remove('is-error', 'is-valid', 'is-focused'));
    form.querySelectorAll('[aria-invalid]').forEach((el) => el.setAttribute('aria-invalid', 'false'));
    form.querySelectorAll('.contact-field-ok').forEach((ok) => { ok.hidden = true; });
    updateCounter(form.querySelector('#message'));
    updateCompletion();
    updateReadyState();
    setDraftText('Draft cleared');
  }

  function restoreDraft() {
    let raw = null;
    try { raw = sessionStorage.getItem(DRAFT_KEY); } catch (_) {}
    if (!raw) return;
    try {
      const saved = JSON.parse(raw);
      Object.entries(saved).forEach(([id, value]) => {
        const el = form.querySelector('#' + id);
        if (el && typeof value === 'string') el.value = value;
      });
      setDraftText('Draft restored from this tab', 'restored');
      updateCounter(form.querySelector('#message'));
      updateCompletion();
      updateReadyState();
    } catch (_) {}
  }

  function setStatus(message, type = '') {
    if (!status) return;
    status.innerHTML = message;
    status.className = `form-status is-visible${type ? ` is-${type}` : ''}`;
  }

  function clearStatus() {
    if (!status) return;
    status.className = 'form-status';
    status.innerHTML = '';
  }

  async function sendViaAppsScript(data) {
    // js/tg-lead-transport.js posts through a hidden iframe and waits for the backend's
    // "saved" confirmation, so a failure is shown as a failure instead of a fake success.
    if (!window.TGLeadTransport) {
      throw new Error('The delivery service did not load. Please refresh the page.');
    }

    let result;
    try {
      result = await window.TGLeadTransport.postLead({
        name: data.name,
        email: data.email,
        phone: data.phone || '',
        company: data.company || '',
        service: data.projectType || '',
        budget: data.budget || '',
        message: data.message,
        website: valueOf('tg-website'),          // honeypot — must stay empty for real visitors
        source: window.location.href
      });
    } catch (error) {
      const err = new Error(error && error.message ? error.message : 'We could not reach the Techigrate delivery service.');
      err.code = 'config';
      throw err;
    }

    if (!result.ok) {
      const err = new Error(result.error || 'We could not save your message.');
      err.code = 'rejected';
      throw err;
    }

    return { ok: true, kind: 'delivered', id: result.id || '', confirmed: !!result.confirmed };
  }

  function sendViaMailto(data) {
    const subject = encodeURIComponent(`New project inquiry from ${data.name || 'website visitor'}`);
    const body = encodeURIComponent([
      `Name: ${data.name}`,
      `Email: ${data.email}`,
      `Company: ${data.company || '—'}`,
      `Project type: ${data.projectType || '—'}`,
      `Budget: ${data.budget || '—'}`,
      '',
      data.message,
    ].join('\n'));
    window.location.href = `mailto:${FALLBACK_EMAIL}?subject=${subject}&body=${body}`;
  }

  function fieldsFromForm() {
    return {
      name: valueOf('name'),
      email: valueOf('email'),
      company: valueOf('company'),
      projectType: labelFor('project-type'),
      budget: labelFor('budget'),
      message: valueOf('message'),
    };
  }

  function launchSendCelebration(button) {
    if (reducedMotion()) return Promise.resolve();
    return new Promise((resolve) => {
      const icon = button.querySelector('svg');
      const rect = (icon || button).getBoundingClientRect();
      const startX = rect.left + rect.width * .52;
      const startY = rect.top + rect.height * .52;
      button.classList.add('is-launching');

      const flight = document.createElement('div');
      flight.className = 'send-flight';
      flight.setAttribute('aria-hidden', 'true');
      flight.innerHTML = `
        <span class="send-flight__trail send-flight__trail--a"></span>
        <span class="send-flight__trail send-flight__trail--b"></span>
        <span class="send-flight__glow"></span>
        <span class="send-flight__label">LAUNCHED</span>
        <svg viewBox="0 0 24 24"><path fill="currentColor" d="M1.946 9.315c-.522-.174-.527-.455.01-.634l19.087-6.362c.529-.176.832.12.684.638l-5.454 19.086c-.15.529-.455.547-.679.045L12 14l6-8-8 6-8.054-2.685z"/></svg>`;
      document.body.appendChild(flight);

      const vw = window.visualViewport?.width || window.innerWidth;
      const vh = window.visualViewport?.height || window.innerHeight;
      const mobile = vw < 640;
      const targetX = Math.max(44, Math.min(vw - 54, vw * (mobile ? .79 : .90)));
      const targetY = Math.max(96, Math.min(vh * (mobile ? .25 : .21), startY - Math.max(100, vh * .12)));
      const dx = targetX - startX;
      const c1 = { x: startX + Math.max(80, dx * .24), y: startY - Math.min(110, vh * .13) };
      const c2 = { x: startX + dx * .68, y: Math.max(55, targetY - Math.min(170, vh * .25)) };
      const duration = mobile ? 1220 : 1420;
      const svg = flight.querySelector('svg');
      const trails = flight.querySelectorAll('.send-flight__trail');
      let last = { x: startX, y: startY };
      const started = performance.now();

      const point = (t) => {
        const u = 1 - t;
        return {
          x: u*u*u*startX + 3*u*u*t*c1.x + 3*u*t*t*c2.x + t*t*t*targetX,
          y: u*u*u*startY + 3*u*u*t*c1.y + 3*u*t*t*c2.y + t*t*t*targetY
        };
      };
      const place = (x, y) => { flight.style.left = `${x - 27}px`; flight.style.top = `${y - 27}px`; };
      place(startX, startY);

      let raf = 0;
      const tick = (now) => {
        const raw = Math.min(1, (now - started) / duration);
        const eased = 1 - Math.pow(1 - raw, 3);
        const p = point(eased);
        const q = point(Math.min(1, eased + .014));
        const angle = Math.atan2(q.y - p.y, q.x - p.x) * 180 / Math.PI + 18;
        place(p.x, p.y);
        const scale = raw < .09 ? .78 + raw * 2.45 : 1;
        svg.style.transform = `rotate(${angle}deg) scale(${scale})`;
        const speed = Math.min(3.5, Math.hypot(p.x-last.x, p.y-last.y) / 5.5);
        trails[0].style.transform = `translate(${-18-speed*9}px, ${speed*2}px) rotate(${angle+155}deg) scaleX(${1+speed*.24})`;
        trails[1].style.transform = `translate(${-32-speed*14}px, ${-speed*2}px) rotate(${angle+155}deg) scaleX(${.9+speed*.18})`;
        trails[0].style.opacity = `${.26 + speed*.25}`;
        trails[1].style.opacity = `${.12 + speed*.16}`;
        last = p;
        if (raw < 1) raf = requestAnimationFrame(tick);
      };
      raf = requestAnimationFrame(tick);

      window.setTimeout(() => {
        cancelAnimationFrame(raf);
        place(targetX, targetY);
        flight.classList.add('is-impact');
        createSendBurst(targetX, targetY);
        window.setTimeout(() => { flight.remove(); resolve(); }, 420);
      }, duration - 45);
    });
  }

  function createSendBurst(x, y) {
    const burst = document.createElement('div');
    burst.className = 'send-burst';
    burst.style.left = `${x}px`;
    burst.style.top = `${y}px`;
    burst.innerHTML = `
      <span class="send-burst__flash"></span>
      <span class="send-burst__ring"></span>
      <span class="send-popper send-popper--left"></span>
      <span class="send-popper send-popper--right"></span>`;

    const colors = ['#ffffff','#e8f0ff','#83a9ff','#9e83ff','#75e9ff','#ffd66e','#ff9bc9','#b6a5ff'];
    const mobile = window.innerWidth < 640;
    const count = mobile ? 82 : 110;
    for (let i = 0; i < count; i += 1) {
      const p = document.createElement('span');
      const angle = (Math.PI * 2 * i) / count + (Math.random() - .5) * .3;
      const distance = (mobile ? 64 : 74) + Math.random() * (mobile ? 185 : 245);
      const depth = .66 + Math.random() * .72;
      const kind = Math.random();
      p.className = `send-burst__particle${kind > .78 ? ' is-ribbon' : kind > .5 ? ' is-dot' : ''}`;
      p.style.setProperty('--burst-x', `${Math.cos(angle) * distance}px`);
      p.style.setProperty('--burst-y', `${Math.sin(angle) * distance * depth}px`);
      p.style.setProperty('--burst-rotate', `${Math.round((Math.random()*2-1)*900)}deg`);
      p.style.setProperty('--burst-delay', `${Math.random()*130}ms`);
      p.style.setProperty('--burst-duration', `${760+Math.random()*620}ms`);
      p.style.setProperty('--burst-color', colors[(Math.random()*colors.length)|0]);
      burst.appendChild(p);
    }
    document.body.appendChild(burst);
    window.setTimeout(() => burst.remove(), 1950);
  }

  function prepareSuccess(mode, firstName, confirmed = true) {
    form.classList.add('is-success');
    successPanel.hidden = false;
    successPanel.classList.add('is-visible');
    if (mode === 'delivered') {
      successKicker.textContent = 'Message delivered';
      successTitle.textContent = `${firstName || 'You'}, officially in motion.`;
      successCopy.textContent = confirmed
        ? 'We received your project context. We’ll review it and reply within one business day.'
        : 'Your message has been sent. We’ll reply within one business day — if you don’t hear from us, email ' + FALLBACK_EMAIL + '.';
    } else {
      successKicker.textContent = 'Email handoff ready';
      successTitle.textContent = 'Your message is ready to launch.';
      successCopy.textContent = 'Your email app should open with the project details filled in. If it doesn’t, you can email us directly at ' + FALLBACK_EMAIL + '.';
    }
    if (mode === 'delivered') {
      try { sessionStorage.removeItem(DRAFT_KEY); } catch (_) {}
      setDraftText('Draft cleared after delivery');
    }
  }

  function resetSuccess() {
    form.classList.remove('is-success');
    successPanel.classList.remove('is-visible');
    successPanel.hidden = true;
    clearStatus();
    form.reset();
    form.querySelectorAll('.field').forEach((field) => field.classList.remove('is-error', 'is-valid', 'is-focused'));
    form.querySelectorAll('[aria-invalid]').forEach((el) => el.setAttribute('aria-invalid', 'false'));
    form.querySelectorAll('.contact-field-ok').forEach((ok) => { ok.hidden = true; });
    updateCounter(form.querySelector('#message'));
    updateCompletion();
    updateReadyState();
    setDraftText('Draft stays in this tab');
    const name = form.querySelector('#name');
    name?.focus({ preventScroll: true });
  }

  function validateAll() {
    let firstInvalid = null;
    requiredFields.forEach((id) => {
      const valid = validateField(id, { show: true });
      if (!valid && !firstInvalid) firstInvalid = form.querySelector('#' + id);
    });

    // Let the browser's native constraints participate as a second safety net.
    // This catches cases such as malformed email values that a custom rule might miss.
    const nativeInvalid = [...form.querySelectorAll('input, select, textarea')].find((el) => !el.checkValidity());
    if (!firstInvalid && nativeInvalid) {
      firstInvalid = nativeInvalid;
      const fieldId = nativeInvalid.id;
      if (fieldId) validateField(fieldId, { show: true });
    }

    updateCompletion();
    updateReadyState();
    if (firstInvalid) {
      try { firstInvalid.focus({ preventScroll: false }); } catch (_) { firstInvalid.focus(); }
      setStatus('<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 8v5M12 16h.01"/></svg><span>One or more details need a quick check before launch.</span>', 'error');
      return false;
    }
    return true;
  }

  // Wrap fields / attach interactions.
  fields.forEach((id) => {
    const el = form.querySelector('#' + id);
    if (el) setupField(el);
  });

  restoreDraft();
  updateCompletion();
  updateReadyState();

  // Intake/pricing can prefill fields after this script has initialized.
  document.addEventListener('techigrate:pricing-selected', () => {
    window.setTimeout(() => {
      updateCompletion();
      updateReadyState();
      updateCounter(form.querySelector('#message'));
    }, 0);
  });

  // The enhanced capture listener intentionally supersedes the older handler
  // in contact.js without changing that legacy file.
  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    event.stopImmediatePropagation();
    if (isSubmitting) return;
    if (!validateAll()) return;

    isSubmitting = true;
    submitBtn.disabled = true;
    submitBtn.setAttribute('aria-busy', 'true');
    submitBtn.classList.add('is-submitting');
    if (btnText) btnText.textContent = 'Sending';
    setStatus('<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 3v4M12 17v4M3 12h4M17 12h4"/></svg><span>Preparing your message for launch…</span>', 'pending');

    const data = fieldsFromForm();
    const mode = 'delivered';
    let confirmed = true;

    try {
      const delivery = await sendViaAppsScript(data);
      confirmed = delivery.confirmed !== false;
      if (!delivery.ok) throw new Error('The message was not confirmed as saved.');
      setStatus('<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg><span>Message received. Launching the handoff animation…</span>');
    } catch (error) {
      // IMPORTANT: do not celebrate, open mailto, or show a success screen when
      // the real delivery service reports an error or we cannot confirm delivery.
      const detail = error?.message || 'We could not confirm delivery.';
      setStatus(`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 8v5M12 16h.01"/></svg><span>${escapeText(detail)} Try again — your form is still here — or email us at <a href="mailto:${FALLBACK_EMAIL}">${FALLBACK_EMAIL}</a>.</span>`, 'error');
      if (btnText) btnText.textContent = 'Try again';
      submitBtn.disabled = false;
      submitBtn.removeAttribute('aria-busy');
      submitBtn.classList.remove('is-launching', 'is-submitting', 'is-complete');
      isSubmitting = false;
      saveDraftNow();
      return;
    }

    if (btnText) btnText.textContent = 'Launching';
    await launchSendCelebration(submitBtn);

    submitBtn.classList.remove('is-launching', 'is-submitting');
    submitBtn.classList.add('is-complete');
    submitBtn.disabled = false;
    submitBtn.removeAttribute('aria-busy');
    if (btnText) btnText.textContent = mode === 'delivered' ? 'Message delivered' : 'Email handoff ready';
    prepareSuccess(mode, data.name.split(' ')[0], confirmed);
    isSubmitting = false;

  }, true);

  sendAnother?.addEventListener('click', resetSuccess);

  // Gentle 3D response on the form itself, only for a real pointer.
  if (!reducedMotion() && window.matchMedia?.('(pointer:fine)').matches) {
    const card = form;
    card.addEventListener('pointermove', (event) => {
      if (isSubmitting || form.classList.contains('is-success')) return;
      const rect = card.getBoundingClientRect();
      const px = (event.clientX - rect.left) / rect.width;
      const py = (event.clientY - rect.top) / rect.height;
      card.style.setProperty('--tilt-x', `${(0.5-py) * 1.15}deg`);
      card.style.setProperty('--tilt-y', `${(px-0.5) * 1.45}deg`);
      card.classList.add('is-tilting');
    });
    card.addEventListener('pointerleave', () => {
      card.style.setProperty('--tilt-x', '0deg');
      card.style.setProperty('--tilt-y', '0deg');
      card.classList.remove('is-tilting');
    });
  }

  // Copy-to-clipboard micro interaction.
  document.querySelectorAll('[data-copy-email]').forEach((button) => {
    button.addEventListener('click', async () => {
      const email = button.getAttribute('data-copy-email') || FALLBACK_EMAIL;
      try {
        await navigator.clipboard.writeText(email);
        button.textContent = 'Copied';
        button.classList.add('is-copied');
      } catch (_) {
        window.location.href = `mailto:${email}`;
        button.textContent = 'Email';
      }
      window.setTimeout(() => {
        button.textContent = 'Copy email';
        button.classList.remove('is-copied');
      }, 1800);
    });
  });
})();
