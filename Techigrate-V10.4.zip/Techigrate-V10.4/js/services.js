/* ==========================================================================
   SERVICES — light pointer-tilt on each diagram panel. Purely decorative,
   skipped on touch devices and when reduced motion is requested.
   ========================================================================== */

(function () {
  'use strict';

  const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const isTouch = window.matchMedia('(hover: none)').matches;
  if (prefersReducedMotion || isTouch) return;

  document.querySelectorAll('.service-art').forEach((panel) => {
    panel.addEventListener('pointermove', (e) => {
      const rect = panel.getBoundingClientRect();
      const px = (e.clientX - rect.left) / rect.width - 0.5;
      const py = (e.clientY - rect.top) / rect.height - 0.5;
      panel.style.transform = `perspective(900px) rotateX(${(-py * 6).toFixed(2)}deg) rotateY(${(px * 6).toFixed(2)}deg)`;
    });
    panel.addEventListener('pointerleave', () => {
      panel.style.transform = 'perspective(900px) rotateX(0) rotateY(0)';
    });
  });
})();
