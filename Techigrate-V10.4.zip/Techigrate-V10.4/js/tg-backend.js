/* ==========================================================================
   TECHIGRATE — SITE BACKEND CONNECTOR V2.1
   One shared script, loaded on every page, that connects the website to the
   Google Apps Script backend (which saves everything in the Techigrate Control sheet):

   1. Analytics  — page_view, cta_click, project_view, search_open, announcement_open
   2. Content    — announcements (notification bell) and showcase projects from the sheet
   3. Leads      — handled by js/tg-lead-transport.js (contact page)

   Endpoint + options come from js/site-config.js (window.TECHIGRATE_SITE).
   Everything here fails silently: if the backend is down the site looks and works as normal.
   ========================================================================== */
(function () {
  'use strict';

  var SITE = window.TECHIGRATE_SITE || {};
  var API_URL = SITE.appsScriptUrl || '';
  if (!/^https:\/\/script\.google(usercontent)?\.com\/.*\/exec(\?.*)?$/.test(API_URL)) return;
  if (window.TGBackend) return; // never run twice

  var VISITOR_KEY = 'tg-visitor-id';
  var SESSION_KEY = 'tg-session-id';
  var SEEN_KEY = 'tg-seen-announcements';
  var CACHE_KEY = 'tg-content-cache-v2';
  var CACHE_FRESH_MS = 60 * 1000;      // re-fetch after 1 minute
  var CACHE_MAX_MS = 10 * 60 * 1000;   // never show content older than 10 minutes
  var FETCH_TIMEOUT_MS = 8000;

  /* ---------- privacy: honour Do-Not-Track / Global Privacy Control ---------- */
  var analyticsOn = (function () {
    if (SITE.analytics === false) return false;
    if (SITE.respectDoNotTrack === false) return true;
    var dnt = navigator.doNotTrack === '1' || window.doNotTrack === '1';
    return !(dnt || navigator.globalPrivacyControl === true);
  })();

  /* ---------- tiny helpers ---------- */
  function uid(prefix) {
    try { if (window.crypto && crypto.randomUUID) return prefix + '_' + crypto.randomUUID(); } catch (_) {}
    return prefix + '_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 10);
  }

  function stored(storage, key, prefix) {
    try {
      var value = storage.getItem(key);
      if (!value) { value = uid(prefix); storage.setItem(key, value); }
      return value;
    } catch (_) { return uid(prefix); }
  }

  function esc(value) {
    return String(value == null ? '' : value)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  function safeHref(url) {
    var s = String(url || '').trim();
    return /^(https?:\/\/|\/|\.\/|[a-z0-9_-]+\.html)/i.test(s) ? s : '';
  }

  function isExternal(url) {
    try { return new URL(url, location.href).origin !== location.origin; } catch (_) { return false; }
  }

  var visitorId = stored(window.localStorage || {}, VISITOR_KEY, 'visitor');
  var sessionId = stored(window.sessionStorage || {}, SESSION_KEY, 'session');

  /* ---------- sending (fire-and-forget) ---------- */
  function send(payload) {
    var body = new URLSearchParams();
    Object.keys(payload).forEach(function (k) {
      var v = payload[k];
      body.append(k, v && typeof v === 'object' ? JSON.stringify(v) : (v == null ? '' : String(v)));
    });

    try {
      if (navigator.sendBeacon && navigator.sendBeacon(API_URL, body)) return;
    } catch (_) {}

    try {
      fetch(API_URL, { method: 'POST', mode: 'no-cors', keepalive: true, cache: 'no-store', body: body }).catch(function () {});
    } catch (_) {}
  }

  var lastSent = {};
  function track(eventType, metadata) {
    if (!analyticsOn) return;
    var key = eventType + '|' + JSON.stringify(metadata || {});
    var now = Date.now();
    if (lastSent[key] && now - lastSent[key] < 800) return; // double-click guard
    lastSent[key] = now;

    send({
      action: 'event',
      eventType: eventType,
      page: document.title,
      path: location.pathname + location.search,
      visitorId: visitorId,
      sessionId: sessionId,
      metadata: metadata || {},
      source: 'website'
    });
  }

  /* ---------- announcements ---------- */
  function readSeen() {
    try { return JSON.parse(localStorage.getItem(SEEN_KEY) || '[]'); } catch (_) { return []; }
  }
  function writeSeen(ids) {
    try { localStorage.setItem(SEEN_KEY, JSON.stringify(ids.slice(-50))); } catch (_) {}
  }

  var currentAnnouncementIds = [];

  function hydrateAnnouncements(items) {
    var lists = document.querySelectorAll('[data-nav-notification-list]');
    var dots = document.querySelectorAll('.tg-nav-notification__dot');
    if (!lists.length) return;

    items = items || [];
    currentAnnouncementIds = items.map(function (i) { return String(i.id); });

    var seen = readSeen();
    var hasUnseen = currentAnnouncementIds.some(function (id) { return seen.indexOf(id) === -1; });
    Array.prototype.forEach.call(dots, function (dot) { dot.hidden = !hasUnseen; });

    var html;
    if (!items.length) {
      html = '<div class="tg-nav-notification-empty">No new announcements.</div>';
    } else {
      html = items.map(function (item) {
        var href = safeHref(item.linkUrl);
        var tag = Number(item.priority) <= 1 ? 'IMPORTANT' : 'UPDATE';
        var target = href && isExternal(href) ? ' target="_blank" rel="noopener noreferrer"' : '';
        return '<div class="tg-nav-notification-item">' +
          '<div class="tg-nav-notification-item__top"><span class="tg-nav-notification-item__tag">' + tag + '</span></div>' +
          '<strong>' + esc(item.title) + '</strong>' +
          '<p>' + esc(item.message) + '</p>' +
          (href ? '<a href="' + esc(href) + '"' + target + ' data-tg-announcement="' + esc(item.id) + '">Open announcement ↗</a>' : '') +
          '</div>';
      }).join('');
    }
    Array.prototype.forEach.call(lists, function (list) { list.innerHTML = html; });
  }

  /* ---------- showcase projects ---------- */
  function hydrateProjects(items) {
    if (!items || !items.length) return;
    var tiles = document.querySelectorAll('.work-tile[data-project]');
    if (!tiles.length) return;

    var bySlug = {};
    items.forEach(function (p) { if (p && p.slug) bySlug[String(p.slug)] = p; });

    Array.prototype.forEach.call(tiles, function (tile) {
      var project = bySlug[tile.getAttribute('data-project')];
      if (!project) return;

      var tag = tile.querySelector('.work-tile-tag');
      var title = tile.querySelector('h3');
      if (tag && project.category) tag.textContent = project.category;
      if (title && project.title) title.textContent = project.title;

      var art = tile.querySelector('.work-tile-art');
      if (art && project.thumbnailUrl && !art.querySelector('img[data-tg-thumb]')) {
        var img = new Image();
        img.onload = function () {
          // Only replace the built-in artwork once the real image has actually loaded.
          art.innerHTML = '';
          img.setAttribute('data-tg-thumb', '1');
          img.style.cssText = 'width:100%;height:100%;object-fit:cover';
          art.appendChild(img);
        };
        img.alt = project.title || 'Techigrate project';
        img.decoding = 'async';
        img.src = project.thumbnailUrl;
      }
      tile.setAttribute('data-project-id', project.id || '');
    });
  }

  /* ---------- content loading: cache first, then revalidate ---------- */
  function readCache() {
    try {
      var c = JSON.parse(sessionStorage.getItem(CACHE_KEY) || 'null');
      return c && c.data && Date.now() - c.t < CACHE_MAX_MS ? c : null;
    } catch (_) { return null; }
  }

  function applyContent(data) {
    if (!data || !data.ok) return;
    if (data.settings && data.settings.analytics_enabled === false) analyticsOn = false;
    hydrateAnnouncements(data.announcements || []);
    hydrateProjects(data.projects || []);
  }

  function loadContent() {
    var cached = readCache();
    if (cached) applyContent(cached.data);
    if (cached && Date.now() - cached.t < CACHE_FRESH_MS) return;

    var controller = window.AbortController ? new AbortController() : null;
    var timer = controller ? window.setTimeout(function () { controller.abort(); }, FETCH_TIMEOUT_MS) : 0;

    fetch(API_URL + '?action=content', { method: 'GET', mode: 'cors', cache: 'no-store', signal: controller ? controller.signal : undefined })
      .then(function (r) { return r.ok ? r.json() : null; })
      .then(function (data) {
        window.clearTimeout(timer);
        if (!data || !data.ok) return;
        try { sessionStorage.setItem(CACHE_KEY, JSON.stringify({ t: Date.now(), data: data })); } catch (_) {}
        applyContent(data);
      })
      .catch(function () { window.clearTimeout(timer); });
  }

  /* ---------- click tracking (one delegated listener) ---------- */
  var CTA_SELECTOR = '.project-btn, .tg-hero-secondary, .bottom-nav-center, [data-tg-track]';

  document.addEventListener('click', function (event) {
    var t = event.target;
    if (!t || !t.closest) return;

    var cta = t.closest(CTA_SELECTOR);
    if (cta) {
      track('cta_click', {
        text: (cta.getAttribute('data-tg-track') || cta.getAttribute('aria-label') || cta.textContent || '').trim().slice(0, 120),
        href: (cta.getAttribute('href') || '').slice(0, 200)
      });
    }

    var project = t.closest('.work-tile[data-project], .project-panel[data-project]');
    if (project) {
      track('project_view', { slug: project.getAttribute('data-project'), id: project.getAttribute('data-project-id') || '' });
    }

    var announcement = t.closest('[data-tg-announcement]');
    if (announcement) track('announcement_open', { id: announcement.getAttribute('data-tg-announcement') || '' });

    if (t.closest('[data-nav-search]')) track('search_open', {});

    if (t.closest('[data-nav-notification]')) {
      // Opening the bell marks the current announcements as seen and clears the dot.
      var seen = readSeen();
      currentAnnouncementIds.forEach(function (id) { if (seen.indexOf(id) === -1) seen.push(id); });
      writeSeen(seen);
      Array.prototype.forEach.call(document.querySelectorAll('.tg-nav-notification__dot'), function (d) { d.hidden = true; });
    }
  }, { passive: true });

  /* ---------- start ---------- */
  var pageViewSent = false;
  function start() {
    if (!pageViewSent) { pageViewSent = true; track('page_view'); }
    loadContent();
  }

  // Back/forward cache restores count as a fresh view.
  window.addEventListener('pageshow', function (e) {
    if (e.persisted) { pageViewSent = false; start(); }
  });

  window.TGBackend = { track: track, loadContent: loadContent, visitorId: visitorId, sessionId: sessionId };

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start, { once: true });
  else start();
})();
