/* ========================================================================== 
   TECHIGRATE V5.2 — shared project showcase controller
   - Opens projects from the Work rail AND homepage project cards.
   - Locks both native scrolling and Lenis while the case-study modal is open.
   - Keeps the modal itself independently scrollable on smaller screens.
   ========================================================================== */
(function () {
  'use strict';

  const triggers = Array.from(document.querySelectorAll('[data-project]'));
  const modal = document.querySelector('[data-project-modal]');
  if (!triggers.length || !modal) return;

  const title = modal.querySelector('[data-project-title]');
  const tag = modal.querySelector('[data-project-tag]');
  const subtitle = modal.querySelector('[data-project-subtitle]');
  const desc = modal.querySelector('[data-project-description]');
  const count = modal.querySelector('[data-project-count]');
  const metrics = modal.querySelector('[data-project-metrics]');
  const art = modal.querySelector('[data-project-art]');
  const visitBtn = modal.querySelector('[data-project-visit]');
  const nextBtn = modal.querySelector('[data-project-next]');
  const closeEls = modal.querySelectorAll('[data-project-close]');

  const projects = {
    koras: { index: '01', tag: 'Restaurant · Website', title: 'Koras Cafe — The Healthy Momos Wala', subtitle: 'A street-food counter, turned into a warm, fast website.', description: 'Koras is an all-vegetarian street-food counter in Karawal Nagar, Delhi. We gave it a dark, appetising hero with a steaming momo and a floating signature-dish card, then built everything a hungry visitor needs: a searchable menu split into six categories (Momos, Burgers, Chinese, Pizza, Shakes, Combos) with Veg and Popular tags, a signature-picks showcase, an embedded map with opening hours, and one-tap ordering through Zomato, Swiggy or a direct call.', visit: 'https://techigrate-project-koras.netlify.app/', metrics: [['6','Menu categories'],['100%','Vegetarian menu'],['3','Ways to order']], bg: 'linear-gradient(140deg,#1a1210,#5a2a12 55%,#e4491b)', shots: [['assets/work/koras-hero.jpg','Home'],['assets/work/koras-menu.jpg','Menu'],['assets/work/koras-picks.jpg','Signature picks']] },
    cafe: { index: '02', tag: 'Cafe · Concept', title: 'The Cafe — a scroll-driven menu experience', subtitle: 'A burger that comes apart as you scroll.', description: 'The Cafe is a self-initiated concept for a modern café. Its centrepiece is a scroll-driven section where a burger floats apart layer by layer — bun, sauce, lettuce, tomato, onion, cheese, patty — with labels appearing as you go. Around it sits a working ordering flow: a 31-item menu with search, sort and filters (Coffee, Cold drinks, Burgers, Sandwiches, Desserts, Veg, Vegan, Spicy), add-to-order buttons, and a slide-in cart with quantity controls, a live subtotal and checkout.', visit: 'https://techigrate-project-cafe.netlify.app/', metrics: [['31','Menu items'],['8','Smart filters'],['Live','Order cart']], bg: 'linear-gradient(140deg,#2a1810,#8a4a22 55%,#e8cfae)', shots: [['assets/work/cafe-layers.jpg','Scroll story'],['assets/work/cafe-menu.jpg','Menu & filters'],['assets/work/cafe-cart.jpg','Order cart'],['assets/work/cafe-signature.jpg','Signature items']] },
    madav: { index: '03', tag: 'Education · Prototype', title: 'Madav Tutorials — coaching institute website', subtitle: 'Clear, calm and built for the parents who decide.', description: 'Madav Tutorials is an offline coaching institute in Yamuna Vihar, Delhi, teaching CBSE and ICSE for Classes 8–12 (Arts stream in 11–12) in small batches with one dedicated teacher. The prototype leads with a confident headline and a weekly-timetable visual, then walks through About, Courses, Faculty, Results, Testimonials and an FAQ accordion written for parents — with an Enquire Now button always within reach.', visit: 'https://ctofficer.github.io/MD-Proto-2.1/index.html', metrics: [['8–12','Classes covered'],['2','Boards'],['7','Page sections']], bg: 'linear-gradient(140deg,#1f1f45,#4a47c9 55%,#6a63ff)', shots: [['assets/work/madav-hero.jpg','Home'],['assets/work/madav-faq.jpg','FAQ for parents'],['assets/work/madav-cta.jpg','Enquiry']] }
  };

  let slideTimer = null;
  function buildSlides(project) {
    clearInterval(slideTimer);
    const shots = project.shots || [];
    art.innerHTML = '<div class="pm-slides">' + shots.map((sh, i) =>
      `<div class="pm-slide${i === 0 ? ' is-on' : ''}"><img src="${sh[0]}" alt="${project.title} — ${sh[1]}" loading="lazy"><span class="pm-cap">${sh[1]}</span></div>`).join('') +
      '</div><div class="pm-dots">' + shots.map((_, i) => `<button type="button" aria-label="Show screen ${i + 1}" class="${i === 0 ? 'is-on' : ''}"></button>`).join('') + '</div>';
    const slides = Array.from(art.querySelectorAll('.pm-slide'));
    const dots = Array.from(art.querySelectorAll('.pm-dots button'));
    let n = 0;
    const go = (k) => { n = k; slides.forEach((el, i) => el.classList.toggle('is-on', i === n)); dots.forEach((el, i) => el.classList.toggle('is-on', i === n)); };
    dots.forEach((d, i) => d.addEventListener('click', () => { go(i); }));
    if (slides.length > 1 && !(window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches)) {
      slideTimer = setInterval(() => go((n + 1) % slides.length), 3200);
    }
  }

  let activeKey = triggers[0]?.dataset.project || 'koras';
  let lockedScrollY = 0;
  let bodyStyle = null;

  function setModalProject(key, animate = true) {
    const project = projects[key];
    if (!project) return;
    activeKey = key;

    title.textContent = project.title;
    tag.textContent = project.tag;
    subtitle.textContent = project.subtitle;
    desc.textContent = project.description;
    count.textContent = project.index + ' / 03';
    art.style.setProperty('--modal-art-bg', project.bg);
    buildSlides(project);
    if (visitBtn) visitBtn.hidden = !project.visit;
    metrics.innerHTML = project.metrics.map(([value, label]) => `
      <div><div class="stat-value">${value}</div><div class="stat-label">${label}</div></div>
    `).join('');

    triggers.forEach(trigger => trigger.classList.toggle('is-hovered', trigger.dataset.project === key));

    if (animate) {
      modal.querySelector('.project-modal-copy')?.animate([
        { opacity: .48, transform: 'translateY(10px)' },
        { opacity: 1, transform: 'translateY(0)' }
      ], { duration: 360, easing: 'cubic-bezier(.22,1,.36,1)' });
      art.animate([
        { opacity: .72, transform: 'scale(1.025)' },
        { opacity: 1, transform: 'scale(1)' }
      ], { duration: 460, easing: 'cubic-bezier(.22,1,.36,1)' });
    }
  }

  function lockPageScroll() {
    lockedScrollY = window.scrollY || document.documentElement.scrollTop || 0;
    bodyStyle = {
      position: document.body.style.position,
      top: document.body.style.top,
      width: document.body.style.width,
      overflow: document.body.style.overflow,
      paddingRight: document.body.style.paddingRight
    };

    const scrollbarCompensation = Math.max(0, window.innerWidth - document.documentElement.clientWidth);
    document.documentElement.classList.add('project-modal-open');
    document.body.classList.add('project-modal-body-locked');
    document.body.style.position = 'fixed';
    document.body.style.top = `-${lockedScrollY}px`;
    document.body.style.width = '100%';
    document.body.style.overflow = 'hidden';
    if (scrollbarCompensation) document.body.style.paddingRight = `${scrollbarCompensation}px`;

    if (window.tgLenis && typeof window.tgLenis.stop === 'function') {
      window.tgLenis.stop();
    }
  }

  function unlockPageScroll() {
    document.documentElement.classList.remove('project-modal-open');
    document.body.classList.remove('project-modal-body-locked');

    if (bodyStyle) {
      document.body.style.position = bodyStyle.position;
      document.body.style.top = bodyStyle.top;
      document.body.style.width = bodyStyle.width;
      document.body.style.overflow = bodyStyle.overflow;
      document.body.style.paddingRight = bodyStyle.paddingRight;
    } else {
      document.body.style.position = '';
      document.body.style.top = '';
      document.body.style.width = '';
      document.body.style.overflow = '';
      document.body.style.paddingRight = '';
    }

    window.scrollTo(0, lockedScrollY);
    if (window.tgLenis) {
      if (typeof window.tgLenis.scrollTo === 'function') {
        window.tgLenis.scrollTo(lockedScrollY, { immediate: true });
      }
      if (typeof window.tgLenis.start === 'function') window.tgLenis.start();
    }
  }

  function openModal(key) {
    setModalProject(key, false);
    lockPageScroll();
    modal.classList.add('is-open');
    modal.setAttribute('aria-hidden', 'false');
    modal.querySelector('.project-modal-panel')?.scrollTo({ top: 0, behavior: 'auto' });
    window.setTimeout(() => modal.querySelector('.project-modal-close')?.focus(), 40);
  }

  function closeModal() {
    modal.classList.remove('is-open');
    modal.setAttribute('aria-hidden', 'true');
    clearInterval(slideTimer);
    unlockPageScroll();
    triggers.forEach(trigger => trigger.classList.remove('is-hovered'));
  }

  triggers.forEach(trigger => {
    trigger.addEventListener('mouseenter', () => {
      triggers.forEach(t => t.classList.remove('is-hovered'));
      trigger.classList.add('is-hovered');
    });
    trigger.addEventListener('focus', () => {
      triggers.forEach(t => t.classList.remove('is-hovered'));
      trigger.classList.add('is-hovered');
    });
    trigger.addEventListener('click', (event) => {
      if (trigger.matches('a')) event.preventDefault();
      openModal(trigger.dataset.project);
    });
  });

  const chips = Array.from(document.querySelectorAll('.filter-chip'));
  chips.forEach(chip => chip.addEventListener('click', () => {
    chips.forEach(c => {
      c.classList.remove('is-active');
      c.setAttribute('aria-selected', 'false');
    });
    chip.classList.add('is-active');
    chip.setAttribute('aria-selected', 'true');
    const filter = chip.dataset.filter;
    triggers.filter(t => t.classList.contains('project-panel')).forEach(panel => {
      const match = filter === 'all' || panel.dataset.category === filter;
      panel.classList.toggle('is-hidden', !match);
    });
  }));

  closeEls.forEach(el => el.addEventListener('click', closeModal));

  function nextProject(direction) {
    const eligible = triggers.filter(t => !t.classList.contains('is-hidden')).map(t => t.dataset.project);
    if (!eligible.length) return;
    let idx = eligible.indexOf(activeKey);
    if (idx < 0) idx = 0;
    idx = (idx + direction + eligible.length) % eligible.length;
    setModalProject(eligible[idx]);
  }

  visitBtn?.addEventListener('click', () => {
    const url = projects[activeKey]?.visit;
    if (url) window.open(url, '_blank', 'noopener,noreferrer');
  });

  nextBtn?.addEventListener('click', () => nextProject(1));

  document.addEventListener('keydown', (event) => {
    if (!modal.classList.contains('is-open')) return;
    if (event.key === 'Escape') closeModal();
    if (event.key === 'ArrowRight') nextProject(1);
    if (event.key === 'ArrowLeft') nextProject(-1);
  });

  // Prevent wheel/touch gestures from escaping the modal on browsers where a
  // fixed body is not enough. The scrollable panel remains the gesture target.
  modal.addEventListener('wheel', (event) => {
    if (event.target.closest('.project-modal-panel')) return;
    event.preventDefault();
  }, { passive: false });
})();
