/* ==========================================================================
   TECHIGRATE V09 — SCROLL JOURNEY
   1) Every page: main > section travel in from depth and recede on exit.
   2) Homepage: hero pins; the planet-T glides to centre, then the camera
      dives into the T while IDEAS → PRODUCTS → IMPACT swap on screen.
   Driven by Lenis' native scroll (window.scrollY), no extra library.
   Skipped entirely under prefers-reduced-motion.
   ========================================================================== */
(function () {
  'use strict';
  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;

  var page = (location.pathname.split('/').pop() || 'index.html');
  if (/^(privacy|terms|404|demo|preview|template)\.html$/i.test(page)) return;

  var doc = document;
  var clamp = function (v, a, b) { return Math.min(b === undefined ? 1 : b, Math.max(a === undefined ? 0 : a, v)); };
  var lerp = function (a, b, t) { return a + (b - a) * t; };
  var ease = function (t) { return t < .5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2; };
  var smooth = function (t) { return t * t * (3 - 2 * t); };

  /* ------------------------------------------------------------------ */
  /* Homepage hero journey                                               */
  /* ------------------------------------------------------------------ */
  var J = null;
  function initJourney() {
    var hero = doc.querySelector('.tg-home-hero');
    if (!hero) return;
    var orb = hero.querySelector('.hero-orb-stage');
    var copy = hero.querySelector('.hero-copy');
    if (!orb || !copy) return;

    var track = doc.createElement('div');
    track.className = 'sj-track';
    hero.parentNode.insertBefore(track, hero);
    track.appendChild(hero);

    var words = [['01', 'Ideas'], ['02', 'Products'], ['03', 'Impact']];
    hero.insertAdjacentHTML('beforeend',
      '<div class="sj-veil" aria-hidden="true"></div>' +
      '<div class="sj-caps" aria-hidden="true">' + words.map(function (w) {
        return '<div class="sj-cap"><small>' + w[0] + ' / 03</small><b>' + w[1] + '</b></div>';
      }).join('') + '</div>' +
      '<div class="sj-hint" aria-hidden="true"><i></i><span>Scroll</span></div>');

    J = {
      hero: hero, track: track, orb: orb, copy: copy,
      veil: hero.querySelector('.sj-veil'),
      caps: [].slice.call(hero.querySelectorAll('.sj-cap')),
      hint: hero.querySelector('.sj-hint'),
      fade: [].slice.call(hero.querySelectorAll('.hero-feature-card,.hero-edge-note')),
      mega: hero.querySelector('.tg-mega'),
      stage: hero.querySelector('.tg-scene__stage'),
      on: false, dx: 0, dy: 0, smax: 6, measured: false
    };
    // the T sits just above/left of the image centre
    J.ox = .495; J.oy = .45;
    orb.style.transformOrigin = (J.ox * 100) + '% ' + (J.oy * 100) + '%';
    evaluate();
  }

  function pinnable() { return window.innerWidth > 900 && window.innerHeight >= 620; }

  function clearJourney() {
    if (!J) return;
    ['translate', 'scale', 'rotate', 'opacity'].forEach(function (p) { J.orb.style[p] = ''; });
    [J.copy].concat(J.fade).forEach(function (el) { el.style.filter = ''; el.style.translate = ''; el.style.visibility = ''; });
    J.veil.style.opacity = 0;
    if (J.mega) ['translate', 'scale', 'filter', 'visibility'].forEach(function (p) { J.mega.style[p] = ''; });
    if (J.stage) { J.stage.style.scale = ''; J.stage.style.translate = ''; }
    J.caps.forEach(function (c) { c.style.opacity = 0; });
    J.hint.style.opacity = '';
  }

  function evaluate() {
    if (!J) return;
    var want = pinnable();
    if (want !== J.on) {
      J.on = want;
      J.track.classList.toggle('sj-on', want);
      J.track.style.setProperty('--sj-len', window.innerWidth < 1100 ? '3' : '3.5');
      if (!want) clearJourney();
      J.measured = false;
    }
  }

  function measure() {
    if (!J || !J.on) return;
    var o = J.orb;
    var keep = [o.style.translate, o.style.scale, o.style.rotate];
    o.style.translate = ''; o.style.scale = ''; o.style.rotate = '';
    var r = o.getBoundingClientRect();
    var h = J.hero.getBoundingClientRect();
    var W = J.hero.clientWidth, H = J.hero.clientHeight;
    var cx = r.left - h.left + r.width * J.ox;
    var cy = r.top - h.top + r.height * J.oy;
    J.dx = W / 2 - cx;
    J.dy = H * .5 - cy;
    // planet body ≈ 58% of the image width; end when it overfills the screen
    J.smax = clamp((2.5 * Math.max(W, H)) / (.58 * r.width), 3, 14);
    o.style.translate = keep[0]; o.style.scale = keep[1]; o.style.rotate = keep[2];
    J.measured = true;
  }

  function updateJourney() {
    if (!J || !J.on) return;
    if (!J.measured) measure();
    var tr = J.track.getBoundingClientRect();
    var total = tr.height - window.innerHeight;
    var p = total > 0 ? clamp(-tr.top / total) : 0;

    // 0 → .30 travel to centre · .30 → 1 dive
    var t1 = clamp(p / .30), e1 = ease(t1);
    var t2 = clamp((p - .30) / .70);
    var s1 = 1.28;
    var scale = p < .30 ? lerp(1, s1, e1) : s1 * Math.pow(J.smax / s1, ease(t2));
    J.orb.style.translate = (J.dx * e1).toFixed(1) + 'px ' + (J.dy * e1).toFixed(1) + 'px';
    J.orb.style.scale = scale.toFixed(4);
    J.orb.style.rotate = (-6 * e1 - 5 * t2).toFixed(2) + 'deg';
    // last stretch: dissolve into deep space so the next section arrives on a clean edge
    J.orb.style.opacity = (1 - smooth(clamp((p - .86) / .13))).toFixed(3);

    // copy + side notes blur out and lift away
    var f = smooth(clamp(p / .24));
    var op = (1 - f).toFixed(3);
    var fx = 'blur(' + (f * 14).toFixed(1) + 'px) opacity(' + op + ')';
    var ty = (-f * 70).toFixed(1) + 'px';
    J.copy.style.filter = fx; J.copy.style.translate = '0 ' + ty;
    J.copy.style.visibility = f > .98 ? 'hidden' : '';
    J.fade.forEach(function (el) { el.style.filter = fx; el.style.visibility = f > .98 ? 'hidden' : ''; });
    J.hint.style.opacity = clamp(1 - p * 9);

    // giant title lifts away, blurs and softly grows; the lake scene slowly pushes in as we dive
    if (J.mega) {
      var mf = smooth(clamp(p / .26));
      J.mega.style.translate = '0 ' + (-mf * 110).toFixed(1) + 'px';
      J.mega.style.scale = (1 + mf * .10).toFixed(4);
      J.mega.style.filter = 'blur(' + (mf * 16).toFixed(1) + 'px) opacity(' + (1 - mf).toFixed(3) + ')';
      J.mega.style.visibility = mf > .985 ? 'hidden' : '';
    }
    if (J.stage) {
      J.stage.style.scale = (1 + smooth(clamp(p / .7)) * .16).toFixed(4);
      J.stage.style.translate = '0 ' + (-p * 46).toFixed(1) + 'px';
    }

    // space veil
    J.veil.style.opacity = smooth(clamp((p - .16) / .32)).toFixed(3);

    // captions: enter (blur→sharp, rise) · hold · exit (lift, blur)
    J.caps.forEach(function (c, i) {
      var a = .34 + i * .19, b = a + .19;
      var u = clamp((p - a) / (b - a));
      var inn = smooth(clamp(u / .32)), out = smooth(clamp((u - .72) / .28));
      var o = inn * (1 - out);
      c.style.opacity = o.toFixed(3);
      c.style.translate = '0 ' + ((1 - inn) * 70 - out * 70).toFixed(1) + 'px';
      c.style.filter = 'blur(' + (((1 - inn) + out) * 12).toFixed(1) + 'px)';
      c.style.visibility = o < .005 ? 'hidden' : '';
    });
  }

  /* ------------------------------------------------------------------ */
  /* Depth transitions for every section                                 */
  /* ------------------------------------------------------------------ */
  var secs = [];
  function hasBg(el) {
    var cs = getComputedStyle(el);
    var m = /rgba?\(([^)]+)\)/.exec(cs.backgroundColor);
    var a = 1;
    if (m) { var parts = m[1].split(','); a = parts.length > 3 ? parseFloat(parts[3]) : 1; } else { a = 0; }
    return cs.backgroundImage !== 'none' || a > .02;
  }
  function collect() {
    var list = [].slice.call(doc.querySelectorAll('main > section'))
      .filter(function (s) {
        return !s.hidden && !s.matches('[role="dialog"],.project-modal-panel,.nav-search__dialog,[data-sj="off"]');
      });
    secs = list.map(function (el, i) {
      el.classList.add('sj-sec');
      var bg = hasBg(el);
      el.classList.toggle('sj-bg', bg);
      // blur is the costly part of the effect: skip it on very tall sections and on sections with media / form / 3D widgets
      el.classList.toggle('sj-lite', el.offsetHeight > window.innerHeight * 1.5 || !!el.querySelector('video,canvas,iframe,form,[data-tg-pricing]'));
      return { el: el, active: false, last: i === list.length - 1 };
    });
  }

  function updateSections() {
    var vh = window.innerHeight;
    var maxY = Math.max(0, doc.documentElement.scrollHeight - vh);
    var atEnd = (window.scrollY || window.pageYOffset || 0) >= maxY - 2;   // nothing further to scroll: everything visible is "arrived"
    for (var i = 0; i < secs.length; i++) {
      var o = secs[i];
      var r = o.el.getBoundingClientRect();
      if (r.bottom < -vh * .4 || r.top > vh * 1.6) { if (o.active) { o.el.classList.remove('sj-active'); o.active = false; } continue; }
      // short sections travel a shorter distance, so they still finish their entrance
      var dist = Math.min(vh * .62, r.height * .9 + vh * .12);
      var inn = atEnd && r.top < vh ? 1 : ease(clamp((vh - r.top) / dist));
      var out = o.last ? 0 : smooth(clamp((vh * .5 - r.bottom) / (vh * .5)));
      if (inn > .998 && out < .002) {
        if (o.active) { o.el.classList.remove('sj-active'); o.active = false; }
        continue;
      }
      o.el.style.setProperty('--sj-in', inn.toFixed(3));
      o.el.style.setProperty('--sj-out', out.toFixed(3));
      if (!o.active) { o.el.classList.add('sj-active'); o.active = true; }
    }
  }

  /* ------------------------------------------------------------------ */
  var raf = 0;
  function frame() { raf = 0; updateJourney(); updateSections(); }
  function request() { if (!raf) raf = requestAnimationFrame(frame); }

  function boot() {
    initJourney();
    collect();
    window.addEventListener('scroll', request, { passive: true });
    window.addEventListener('resize', function () { evaluate(); if (J) J.measured = false; request(); }, { passive: true });
    window.addEventListener('load', function () { if (J) J.measured = false; request(); });
    // the hero column finishes its own fade-in a moment after load — re-measure once it settles
    setTimeout(function () { if (J) J.measured = false; request(); }, 2600);
    request();
  }
  if (doc.readyState === 'loading') doc.addEventListener('DOMContentLoaded', boot); else boot();
})();
