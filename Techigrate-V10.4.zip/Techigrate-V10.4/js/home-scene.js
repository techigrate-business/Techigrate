/* ==========================================================================
   TECHIGRATE V09 — HOME SCENE (index.html only)
   Day video for the light theme, night video for the dark theme. Only the
   visible theme's video is fetched first and only the on-screen one plays.
   Theme changes (V07's View-Transition wipe stays in charge of the page) add a
   focus-pull of the incoming scene plus a sun / moon bloom.
   No video is loaded under reduced-motion, Save-Data or 2G/3G — the poster
   frame is shown instead.
   ========================================================================== */
(function () {
  'use strict';
  var scene = document.querySelector('[data-scene]');
  if (!scene) return;

  var root = document.documentElement;
  var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var conn = navigator.connection || {};
  var lite = reduce || conn.saveData === true || /(^|-)(2g|3g)$/.test(conn.effectiveType || '');

  var layers = { light: scene.querySelector('.tg-scene__layer--day'), dark: scene.querySelector('.tg-scene__layer--night') };
  var vids = { light: layers.light.querySelector('video'), dark: layers.dark.querySelector('video') };
  var bloom = scene.querySelector('.tg-scene__bloom');
  var stage = scene.querySelector('.tg-scene__stage');
  var cur = theme();
  var visible = true, introDone = document.body.classList.contains('tg-loaded');

  function theme() { return root.getAttribute('data-theme') === 'dark' ? 'dark' : 'light'; }
  function other(t) { return t === 'dark' ? 'light' : 'dark'; }

  function attach(v) {
    if (lite || !v || v.dataset.ready) return;
    v.dataset.ready = '1';
    // H.264 where the browser has it (hardware decoded almost everywhere), VP9 WebM otherwise
    var h264 = v.canPlayType('video/mp4; codecs="avc1.42E01E"');
    v.src = (h264 || !v.dataset.srcWebm) ? v.dataset.src : v.dataset.srcWebm;
    v.load();
  }
  function play(v) { if (!v || lite || !v.src) return; var p = v.play(); if (p && p.catch) p.catch(function () {}); }
  function pause(v) { if (v && !v.paused) v.pause(); }

  function sync() {
    // only the visible theme's video plays, and only while the hero is on screen
    var t = theme();
    if (visible && introDone) play(vids[t]); else pause(vids[t]);
    if (!scene.classList.contains('is-swapping')) pause(vids[other(t)]);
  }

  /* Where the sun (day clip) and the moon (night clip) sit inside the cover-cropped frame */
  var BODY = { light: [0.84, 0.10], dark: [0.71, 0.205] };
  function bodyPos(t) {
    var W = scene.clientWidth, H = scene.clientHeight;
    var s = Math.max(W / 1280, H / 720);
    var dw = 1280 * s, dh = 720 * s;
    var ox = (dw - W) * 0.62, oy = (dh - H) * 0.5;
    return [BODY[t][0] * dw - ox, BODY[t][1] * dh - oy];
  }

  function swap(from, to) {
    attach(vids[to]);
    if (reduce) { sync(); return; }
    var inL = layers[to], outL = layers[from];
    scene.classList.add('is-swapping');
    outL.classList.add('is-leaving');
    inL.classList.remove('is-arriving'); void inL.offsetWidth; inL.classList.add('is-arriving');
    var p = bodyPos(to);
    bloom.style.left = p[0] + 'px'; bloom.style.top = p[1] + 'px';
    bloom.dataset.to = to;
    bloom.classList.remove('go'); void bloom.offsetWidth; bloom.classList.add('go');
    play(vids[to]);
    setTimeout(function () {
      outL.classList.remove('is-leaving'); inL.classList.remove('is-arriving'); bloom.classList.remove('go');
      scene.classList.remove('is-swapping'); sync();
    }, 1900);
  }

  new MutationObserver(function () {
    var t = theme();
    if (t === cur) return;
    var from = cur; cur = t; swap(from, t);
  }).observe(root, { attributes: true, attributeFilter: ['data-theme'] });

  if ('IntersectionObserver' in window) {
    new IntersectionObserver(function (es) { visible = es[0].isIntersecting; sync(); }, { threshold: 0.02 }).observe(scene);
  }
  document.addEventListener('visibilitychange', function () { if (document.hidden) { pause(vids.light); pause(vids.dark); } else sync(); });

  /* Fit the giant title to the screen whatever font actually loads (fallback fonts are much wider than Space Grotesk) */
  var mega = document.querySelector('.tg-mega');
  function fit() {
    if (!mega) return;
    var lis = [].slice.call(mega.querySelectorAll('.tg-mega__layer--front li:not(.brk)'));
    mega.style.fontSize = '100px';
    var w = lis.map(function (li) { return li.getBoundingClientRect().width; });
    var sum = function (a) { return a.reduce(function (x, y) { return x + y; }, 0); };
    var mobile = window.matchMedia('(max-width: 860px)').matches;
    var total = mobile ? Math.max(sum(w.slice(0, 5)), sum(w.slice(5))) : sum(w);
    if (!total) return;
    var size = 100 * (window.innerWidth * (mobile ? 0.8 : 0.88)) / total;
    mega.style.fontSize = Math.max(40, Math.min(size, mobile ? Math.min(170, window.innerHeight * 0.13) : 300)).toFixed(1) + 'px'; /* phones: also cap by height so short/landscape screens never overlap the copy (desktop branch unchanged) */
  }
  fit();
  if (document.fonts && document.fonts.ready) document.fonts.ready.then(fit);
  window.addEventListener('load', fit);
  var rz; window.addEventListener('resize', function () { clearTimeout(rz); rz = setTimeout(fit, 120); });

  // 1) fetch the visible theme's clip straight away, 2) start it after the Hello intro, 3) warm the other one when idle
  attach(vids[cur]);
  var idle = window.requestIdleCallback || function (f) { return setTimeout(f, 1500); };
  function afterIntro() { introDone = true; sync(); idle(function () { attach(vids[other(cur)]); }); }
  if (introDone) afterIntro();
  else {
    var mo = new MutationObserver(function () {
      if (document.body.classList.contains('tg-loaded')) { mo.disconnect(); afterIntro(); }
    });
    mo.observe(document.body, { attributes: true, attributeFilter: ['class'] });
    setTimeout(function () { mo.disconnect(); afterIntro(); }, 9000);
  }


  /* ======================================================================
     V09.1 — everything below reacts to where we are on the page
     ====================================================================== */
  var body = document.body;
  var reduceM = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var finePtr = window.matchMedia('(pointer: fine)').matches;
  var track = document.querySelector('.sj-track') || document.querySelector('.tg-home-hero');

  /* ---- 1) Navbar: flat bar over the scenery -> floating pill (V07) on scroll ---- */
  var header = document.querySelector('.site-header.tg-luxury-nav');
  var navMark = header && header.querySelector('.tg-nav-mark');
  var navLinks = header && header.querySelector('.nav-links');
  var navActions = header && header.querySelector('.nav-actions');
  var flipEls = [navMark, navLinks, navActions].filter(Boolean);
  var navNormal = body.classList.contains('tg-nav-normal');
  var navReady = false, handoffTimer = 0;

  function snap() { return flipEls.map(function (el) { var r = el.getBoundingClientRect(); return [r.left, r.top]; }); }
  function setNavNormal(on) {
    if (on === navNormal) return;
    var first = navReady && !reduceM ? snap() : null;
    navNormal = on;
    body.classList.toggle('tg-nav-normal', on);
    body.classList.add('tg-nav-handoff');
    clearTimeout(handoffTimer);
    handoffTimer = setTimeout(function () { body.classList.remove('tg-nav-handoff'); }, 950);
    if (!first || !flipEls[0].animate) return;
    var last = snap();
    flipEls.forEach(function (el, i) {
      var dx = first[i][0] - last[i][0], dy = first[i][1] - last[i][1];
      if (Math.abs(dx) + Math.abs(dy) < 1) return;
      el.animate([{ translate: dx + 'px ' + dy + 'px' }, { translate: '0px 0px' }], { duration: 850, easing: 'cubic-bezier(.16,1,.3,1)' });
    });
  }

  /* ---- 2) "in scene" flag: hides the floating buttons while the live background is on screen ---- */
  function checkScene() {
    var y = window.scrollY || window.pageYOffset || 0;
    if (navNormal && y > 56) setNavNormal(false);
    else if (!navNormal && y < 24) setNavNormal(true);
    var r = track.getBoundingClientRect();
    body.classList.toggle('tg-in-scene', r.bottom > window.innerHeight * 0.55 && r.top < window.innerHeight * 0.5);
  }
  var sceneRaf = 0;
  window.addEventListener('scroll', function () { if (!sceneRaf) sceneRaf = requestAnimationFrame(function () { sceneRaf = 0; checkScene(); }); }, { passive: true });
  window.addEventListener('resize', checkScene, { passive: true });
  // initial state without animation (page may open already scrolled)
  (function () {
    var y = window.scrollY || 0;
    if (y > 56) { navNormal = true; setNavNormal(false); }
    checkScene();
    requestAnimationFrame(function () { navReady = true; });
  })();

  /* ---- 3) Interactive 3D title + planet ---- */
  var mega = document.querySelector('.tg-mega');
  var stack = mega && mega.querySelector('.tg-mega__stack');
  var front = stack && stack.querySelector('.tg-mega__layer--front');
  var tilt = document.querySelector('[data-planet-tilt]');
  var orb = document.querySelector('[data-hero-orb]');
  var glareI = tilt && tilt.querySelector('.tg-planet-glare i');
  if (!stack || !front) return;

  if (!reduceM) {
    var N = 8, STEP = 9;                       // 8 depth layers, 9px apart => 72px of extrusion
    for (var i = 1; i <= N; i++) {
      var c = front.cloneNode(true);
      c.className = 'tg-mega__layer tg-mega__layer--back';
      c.setAttribute('aria-hidden', 'true');
      c.style.setProperty('--z', i * STEP);
      c.style.setProperty('--k', (i / N).toFixed(3));
      stack.insertBefore(c, front);
    }
  }
  // once the letters have risen, drop the reveal masks so they can lift out of their boxes
  function goLive() { setTimeout(function () { mega.classList.add('is-live'); }, 2700); }
  if (body.classList.contains('tg-loaded')) goLive();
  else {
    var lv = new MutationObserver(function () { if (body.classList.contains('tg-loaded')) { lv.disconnect(); goLive(); } });
    lv.observe(body, { attributes: true, attributeFilter: ['class'] });
  }

  if (reduceM || !finePtr) return;             // touch / reduced motion: CSS sway only, no pointer loop

  var lis = [].slice.call(front.querySelectorAll('li:not(.brk)'));
  var lift = lis.map(function () { return 0; });
  var P = { x: -1e4, y: -1e4, has: false };
  var S = { rx: 0, ry: 0, tx: 0, ty: 0, px: 0, py: 0, gx: 0, gy: 0 };
  var raf = 0, hot = false;

  function loop() {
    raf = 0;
    var vw = window.innerWidth, vh = window.innerHeight;
    var live = visible && introDone && P.has;
    var tx = live ? (P.x / vw - 0.5) * 2 : 0, ty = live ? (P.y / vh - 0.5) * 2 : 0;
    S.rx += (tx - S.rx) * 0.09; S.ry += (ty - S.ry) * 0.09;

    // title stack tilts as one slab
    var a = Math.min(1, Math.hypot(S.rx, S.ry)) * 9;
    stack.style.rotate = (-S.ry).toFixed(3) + ' ' + S.rx.toFixed(3) + ' 0 ' + a.toFixed(2) + 'deg';

    // per-letter lift toward the viewer (front layer only, so the extrusion "opens" behind it)
    var still = Math.abs(S.rx - tx) + Math.abs(S.ry - ty) < 0.002;
    if (mega.classList.contains('is-live')) {
      var mr = mega.getBoundingClientRect(), k = mega.offsetWidth ? mr.width / mega.offsetWidth : 1;
      for (var n = 0; n < lis.length; n++) {
        var li = lis[n];
        var cx = mr.left + (li.offsetLeft + li.offsetWidth / 2) * k;
        var cy = mr.top + (li.offsetTop + li.offsetHeight / 2) * k;
        var d = Math.hypot(P.x - cx, (P.y - cy) * 0.7) / (li.offsetWidth * k * 1.7);
        var target = live ? Math.pow(Math.max(0, 1 - d), 2) : 0;
        lift[n] += (target - lift[n]) * 0.16;
        if (Math.abs(target - lift[n]) > 0.002) still = false;
        li.style.transform = lift[n] < 0.003 ? '' : 'translate3d(0,' + (-lift[n] * 16).toFixed(1) + 'px,' + (lift[n] * 95).toFixed(1) + 'px) scale(' + (1 + lift[n] * 0.05).toFixed(3) + ')';
      }
    }

    // planet: 3D tilt toward the cursor + sphere glare
    if (tilt && orb) {
      var or = orb.getBoundingClientRect();
      var ocx = or.left + or.width / 2, ocy = or.top + or.height / 2;
      var div = Math.max(or.width * 0.7, vw * 0.22);
      var nx = live ? Math.max(-1, Math.min(1, (P.x - ocx) / div)) : 0, ny = live ? Math.max(-1, Math.min(1, (P.y - ocy) / div)) : 0;
      S.px += (nx - S.px) * 0.1; S.py += (ny - S.py) * 0.1;
      var pa = Math.min(1, Math.hypot(S.px, S.py)) * 14;
      tilt.style.rotate = (-S.py).toFixed(3) + ' ' + S.px.toFixed(3) + ' 0 ' + pa.toFixed(2) + 'deg';
      if (glareI) glareI.style.translate = (S.px * 32).toFixed(1) + '% ' + (S.py * 32).toFixed(1) + '%';
      var near = live && Math.hypot(P.x - ocx, P.y - ocy) < or.width * 0.55;
      if (near !== hot) { hot = near; tilt.classList.toggle('is-hot', near); }
      if (Math.abs(S.px - nx) + Math.abs(S.py - ny) > 0.002) still = false;
    }
    if (!still || live) raf = requestAnimationFrame(loop);
  }
  function wake() { if (!raf) raf = requestAnimationFrame(loop); }
  window.addEventListener('pointermove', function (e) { P.x = e.clientX; P.y = e.clientY; P.has = true; wake(); }, { passive: true });
  document.documentElement.addEventListener('pointerleave', function () { P.has = false; wake(); });

  // click / tap the planet: one playful turn
  window.addEventListener('pointerdown', function (e) {
    if (!tilt || !orb || !visible) return;
    var or = orb.getBoundingClientRect();
    if (Math.hypot(e.clientX - (or.left + or.width / 2), e.clientY - (or.top + or.height / 2)) > or.width * 0.36) return;
    tilt.classList.remove('is-spin'); void tilt.offsetWidth; tilt.classList.add('is-spin');
    setTimeout(function () { tilt.classList.remove('is-spin'); }, 1250);
  });

})();
