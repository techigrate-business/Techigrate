/* ==========================================================================
   TECHIGRATE V09.7 — MOTION BATCH (behaviour)
   Pairs with css/v097-motion.css. Every feature is wrapped so one failure can
   never stop the others, and each one bails out early under
   prefers-reduced-motion or when its markup is not on the page.

   A  Line-by-line text reveals          F  Magnetic buttons + custom cursor
   B  Image wipes + parallax hooks       G  SVG line drawing
   C  Stacking project cards             H  Card tilt + glare
   D  Pinned horizontal scroll           I  Arrow icon injection (morph is CSS)
   E  Velocity marquee                   J  Play-on-enter video
   (Odometer counters live in js/stat-motion.js; the day/night moment is in
    js/global.js + css/global.css; page transitions are CSS + a head snippet.)
   ========================================================================== */
(function () {
  'use strict';

  var doc = document, root = doc.documentElement;
  var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var fine = window.matchMedia('(hover: hover) and (pointer: fine)').matches;
  var clamp = function (v, a, b) { return Math.min(b, Math.max(a, v)); };
  var lerp = function (a, b, t) { return a + (b - a) * t; };
  var hasIO = 'IntersectionObserver' in window;

  function safe(name, fn) {
    try { fn(); } catch (err) { if (window.console) console.warn('Techigrate V09.7: ' + name + ' skipped —', err); }
  }
  function debounce(fn, ms) { var t; return function () { clearTimeout(t); t = setTimeout(fn, ms); }; }
  function scrollToY(y, opts) {
    if (window.tgLenis && typeof window.tgLenis.scrollTo === 'function') window.tgLenis.scrollTo(y, opts || { duration: 1.1 });
    else window.scrollTo({ top: y, behavior: reduce ? 'auto' : 'smooth' });
  }

  /* One shared "enter view" observer: adds .is-in once, then stops watching. */
  var inViewIO = hasIO ? new IntersectionObserver(function (entries) {
    entries.forEach(function (e) {
      if (!e.isIntersecting) return;
      e.target.classList.add('is-in');
      inViewIO.unobserve(e.target);
    });
  }, { threshold: 0.28, rootMargin: '0px 0px -6% 0px' }) : null;
  function watchIn(el) { if (inViewIO) inViewIO.observe(el); else el.classList.add('is-in'); }
  /* A clip-path'd element can report zero visibility, so wipes are triggered by their parent instead. */
  var proxyMap = typeof WeakMap === 'function' ? new WeakMap() : null;
  var proxyIO = hasIO ? new IntersectionObserver(function (entries) {
    entries.forEach(function (e) {
      if (!e.isIntersecting) return;
      (proxyMap.get(e.target) || []).forEach(function (el) { el.classList.add('is-in'); });
      proxyIO.unobserve(e.target);
    });
  }, { threshold: 0.3, rootMargin: '0px 0px -6% 0px' }) : null;
  function watchVia(el, host) {
    if (!proxyIO || !host) { el.classList.add('is-in'); return; }
    var list = proxyMap.get(host) || []; list.push(el); proxyMap.set(host, list); proxyIO.observe(host);
  }

  /* ======================================================================
     A  LINE-BY-LINE TEXT REVEAL
     Words sit in overflow masks; each word's delay comes from the line it
     wraps onto, so headlines rise line by line. Re-measured on resize/fonts.
     ====================================================================== */
  safe('text reveals', function () {
    if (reduce) return;
    var seen = [];
    var heads = [].slice.call(doc.querySelectorAll('h2.type-h2, .tg-process__intro h2')).filter(function (h) {
      if (seen.indexOf(h) > -1) return false; seen.push(h);
      return !h.hasAttribute('data-reveal-text') && !h.hasAttribute('data-project-title') &&
        !h.querySelector('.tg-word, .v8-mask') &&
        !h.closest('.project-modal-panel, .nav-search__dialog, [data-no-lines]');
    });
    if (!heads.length) return;

    function split(node) {
      [].slice.call(node.childNodes).forEach(function (ch) {
        if (ch.nodeType === 3) {
          var frag = doc.createDocumentFragment();
          ch.nodeValue.split(/(\s+)/).forEach(function (part) {
            if (!part) return;
            if (/^\s+$/.test(part)) { frag.appendChild(doc.createTextNode(' ')); return; }
            var w = doc.createElement('span'); w.className = 'tg97-w' + (/^[.,;:!?)\u2019\u201d]+$/.test(part) ? ' tg97-w--punct' : ''); w.setAttribute('aria-hidden', 'true');
            var i = doc.createElement('span'); i.className = 'tg97-wi'; i.textContent = part;
            w.appendChild(i); frag.appendChild(w);
          });
          ch.parentNode.replaceChild(frag, ch);
        } else if (ch.nodeType === 1 && ch.tagName !== 'BR') split(ch);
      });
    }
    function measure(h) {
      var line = -1, last = -1e9, wi = 0;
      [].forEach.call(h.querySelectorAll('.tg97-w'), function (w) {
        var top = w.getBoundingClientRect().top;
        if (Math.abs(top - last) > 6) { line++; wi = 0; last = top; }
        w.style.setProperty('--li', line); w.style.setProperty('--wi', wi++);
      });
    }
    heads.forEach(function (h) {
      if (!h.getAttribute('aria-label')) h.setAttribute('aria-label', h.textContent.replace(/\s+/g, ' ').trim());
      split(h); h.classList.add('tg97-lines');
    });
    var run = function () { heads.forEach(measure); };
    run();
    if (doc.fonts && doc.fonts.ready) doc.fonts.ready.then(run);
    window.addEventListener('load', run);
    window.addEventListener('resize', debounce(run, 150));
    heads.forEach(watchIn);
  });

  /* ======================================================================
     B  IMAGE WIPES + PARALLAX HOOKS (the animation itself is CSS, native
        animation-timeline where supported, IntersectionObserver otherwise)
     ====================================================================== */
  safe('wipes + parallax', function () {
    if (reduce) return;
    [].forEach.call(doc.querySelectorAll('.work-tile-art, .stack-scene, .story-grid figure'), function (el) {
      el.classList.add('tg97-wipe'); watchVia(el, el.parentElement);
    });
    [].forEach.call(doc.querySelectorAll('.service-art'), function (el) {
      el.classList.add('tg97-wipe', 'tg97-wipe--io'); watchVia(el, el.closest('.service-block') || el.parentElement);   // horizontal track: observer only
    });
    [].forEach.call(doc.querySelectorAll('.work-tile-art > svg, .story-grid figure img, [data-parallax]'), function (el) {
      el.classList.add('tg97-par'); if (el.parentNode) el.parentNode.classList.add('tg97-par-wrap');
    });
  });

  /* ======================================================================
     C  STACKING PROJECT CARDS (homepage work preview)
     ====================================================================== */
  safe('stacking cards', function () {
    if (reduce) return;
    var grid = doc.querySelector('.work-preview-grid');
    if (!grid) return;
    var tiles = [].filter.call(grid.children, function (c) { return c.classList.contains('work-tile'); });
    if (tiles.length < 2) return;
    grid.classList.add('tg97-stack');
    tiles.forEach(function (t, i) {
      t.style.setProperty('--si', i);
      t.insertAdjacentHTML('beforeend', '<span class="tg97-shade" aria-hidden="true"></span>');
      var art = t.querySelector('.work-tile-art');
      if (art) art.insertAdjacentHTML('beforeend', '<span class="tg97-idx" aria-hidden="true">0' + (i + 1) + ' / 0' + tiles.length + '</span>');
    });
    var stick = [], ticking = false, visible = true;
    function readStick() { stick = tiles.map(function (t) { return parseFloat(getComputedStyle(t).top) || 0; }); }
    function update() {
      ticking = false;
      if (!visible) return;
      for (var i = 0; i < tiles.length - 1; i++) {
        var t = tiles[i], h = t.offsetHeight || 1;
        var d = tiles[i + 1].getBoundingClientRect().top - stick[i];
        var p = clamp(1 - d / (h * 0.92), 0, 1);
        t.style.setProperty('--ss', (1 - p * 0.055).toFixed(4));
        t.style.setProperty('--sd', (p * 0.42).toFixed(3));
      }
    }
    function req() { if (!ticking) { ticking = true; requestAnimationFrame(update); } }
    readStick(); update();
    window.addEventListener('scroll', req, { passive: true });
    window.addEventListener('resize', debounce(function () { readStick(); req(); }, 120));
    if (hasIO) new IntersectionObserver(function (es) { visible = es[0].isIntersecting; if (visible) req(); }, { rootMargin: '200px 0px' }).observe(grid);
  });

  /* ======================================================================
     D  PINNED HORIZONTAL SCROLL
     Services pillars (wrapped here) + homepage "how we work" (markup in HTML).
     The section is made tall; a sticky pin holds a track that slides sideways
     with scroll. Below 900x560 or under reduced motion the sections stay
     ordinary vertical content.
     ====================================================================== */
  safe('horizontal scroll', function () {
    var sections = [].slice.call(doc.querySelectorAll('[data-hscroll]'));
    if (!sections.length) return;

    var hs = sections.map(function (sec) {
      var pin = sec.querySelector('.tg-hs__pin'), track = sec.querySelector('.tg-hs__track');
      if (!pin || !track) {                                    // services: wrap the existing blocks
        var blocks = [].slice.call(sec.querySelectorAll(':scope > .service-block'));
        if (blocks.length < 2) return null;
        pin = doc.createElement('div'); pin.className = 'tg-hs__pin';
        track = doc.createElement('div'); track.className = 'tg-hs__track';
        blocks.forEach(function (b) { b.classList.add('tg-hs__panel'); b.removeAttribute('data-reveal'); track.appendChild(b); });
        pin.appendChild(track); sec.appendChild(pin);
        sec.classList.add('tg-hs', 'tg-hs--services');
      } else sec.classList.add('tg-hs');
      var stops = [].slice.call(track.querySelectorAll('.service-block, .tg-step'));
      var hud = doc.createElement('div'); hud.className = 'tg-hs__hud'; hud.setAttribute('aria-hidden', 'true');
      hud.innerHTML = '<span class="tg-hs__count"><b>01</b> / 0' + stops.length + '</span><span class="tg-hs__bar"><i></i></span><span class="tg-hs__hint">Keep scrolling</span>';
      pin.appendChild(hud);
      return { sec: sec, pin: pin, track: track, stops: stops, count: hud.querySelector('b'), travel: 0, on: false, active: -1, centers: [] };
    }).filter(Boolean);
    if (!hs.length) return;

    function contentW(h) {
      var last = h.track.lastElementChild, cs = getComputedStyle(h.track);
      return Math.ceil(last.offsetLeft + last.offsetWidth + (parseFloat(cs.paddingRight) || 0));
    }
    function buildPath(h) {
      var steps = h.stops.filter(function (s) { return s.classList.contains('tg-step'); });
      if (!steps.length) return;
      var W = contentW(h), H = h.track.offsetHeight, NS = 'http://www.w3.org/2000/svg';
      var svg = h.svg;
      if (!svg) {
        svg = doc.createElementNS(NS, 'svg'); svg.setAttribute('class', 'tg-hs__path'); svg.setAttribute('aria-hidden', 'true');
        svg.setAttribute('preserveAspectRatio', 'none');
        svg.innerHTML = '<defs><linearGradient id="tg97-grad" x1="0" x2="1" y1="0" y2="0"><stop offset="0" stop-color="#4c8dff"/><stop offset="1" stop-color="#b58cff"/></linearGradient></defs>' +
          '<path class="tg-path-base"/><path class="tg-path-glow" pathLength="1"/><path class="tg-path-live" pathLength="1"/>';
        h.track.insertBefore(svg, h.track.firstChild); h.svg = svg;
      }
      svg.setAttribute('viewBox', '0 0 ' + W + ' ' + H); svg.style.width = W + 'px'; svg.style.height = H + 'px';
      var pts = steps.map(function (s) {
        var sy = parseFloat(getComputedStyle(s).getPropertyValue('--sy')) || 0;
        return [s.offsetLeft + s.offsetWidth / 2, s.offsetTop + sy];
      });
      var intro = h.track.querySelector('.tg-process__intro'), outro = h.track.querySelector('.tg-process__outro');
      var midY = H / 2;
      var start = [intro ? intro.offsetLeft + intro.offsetWidth * 0.55 : 0, midY];
      var end = [outro ? outro.offsetLeft + 40 : W, midY];
      var all = [start].concat(pts, [end]);
      var d = 'M' + all[0][0].toFixed(1) + ' ' + all[0][1].toFixed(1);
      for (var i = 1; i < all.length; i++) {
        var a = all[i - 1], b = all[i], mx = (a[0] + b[0]) / 2;
        d += ' C' + mx.toFixed(1) + ' ' + a[1].toFixed(1) + ' ' + mx.toFixed(1) + ' ' + b[1].toFixed(1) + ' ' + b[0].toFixed(1) + ' ' + b[1].toFixed(1);
      }
      [].forEach.call(svg.querySelectorAll('path'), function (p) { p.setAttribute('d', d); });
      h.pathX = [start[0], end[0]];
    }

    function measure(h) {
      var on = !reduce && window.innerWidth >= 900 && window.innerHeight >= 560;
      h.sec.classList.toggle('is-hs', on);
      h.on = on;
      if (!on) { h.sec.style.height = ''; h.track.style.transform = ''; return; }
      h.track.style.transform = '';
      var vw = h.pin.clientWidth;
      h.travel = Math.max(0, contentW(h) - vw);
      h.sec.style.height = Math.round(window.innerHeight + h.travel + window.innerHeight * 0.3) + 'px';
      h.centers = h.stops.map(function (s) { return s.offsetLeft + s.offsetWidth / 2; });
      if (h.sec.querySelector('.tg-step')) buildPath(h);
      update(h);
    }

    function update(h) {
      if (!h.on) return;
      var top = h.sec.getBoundingClientRect().top;
      var p = h.travel ? clamp(-top / h.travel, 0, 1) : 0;
      h.track.style.transform = 'translate3d(' + (-h.travel * p).toFixed(1) + 'px,0,0)';
      h.sec.style.setProperty('--hs-p', p.toFixed(4));
      var mid = h.pin.clientWidth / 2 + h.travel * p;
      if (h.pathX) h.sec.style.setProperty('--hs-draw', clamp((mid - h.pathX[0]) / (h.pathX[1] - h.pathX[0]), 0, 1).toFixed(4));
      var best = 0, bd = 1e9;
      h.centers.forEach(function (c, i) { var d = Math.abs(c - mid); if (d < bd) { bd = d; best = i; } });
      if (best !== h.active) {
        h.active = best;
        h.stops.forEach(function (s, i) { s.classList.toggle('is-active', i === best); });
        h.count.textContent = '0' + (best + 1);
      }
    }

    function scrollToStop(h, stop, instant) {
      var secTop = h.sec.getBoundingClientRect().top + window.scrollY;
      var want = clamp(stop.offsetLeft + stop.offsetWidth / 2 - h.pin.clientWidth / 2, 0, h.travel);
      scrollToY(secTop + want, instant ? { immediate: true } : { duration: 1.2 });
    }
    function hsFor(el) {
      for (var i = 0; i < hs.length; i++) if (hs[i].on && hs[i].track.contains(el)) return hs[i];
      return null;
    }

    var ticking = false;
    function onScroll() { if (!ticking) { ticking = true; requestAnimationFrame(function () { ticking = false; hs.forEach(update); }); } }
    var measureAll = function () { hs.forEach(measure); };
    measureAll();
    window.addEventListener('scroll', onScroll, { passive: true });
    window.addEventListener('resize', debounce(measureAll, 150));
    window.addEventListener('load', measureAll);
    if (doc.fonts && doc.fonts.ready) doc.fonts.ready.then(measureAll);
    if ('ResizeObserver' in window) hs.forEach(function (h) { new ResizeObserver(debounce(function () { measure(h); }, 120)).observe(h.track); });

    // a pin that is overflow:hidden must never scroll sideways on its own (focus, find-in-page)
    hs.forEach(function (h) { h.pin.addEventListener('scroll', function () { h.pin.scrollLeft = 0; }); });

    // keyboard focus inside an off-screen panel brings that panel into view
    doc.addEventListener('focusin', function (e) {
      var h = hsFor(e.target); if (!h) return;
      var stop = h.stops.filter(function (s) { return s.contains(e.target); })[0]; if (!stop) return;
      var r = stop.getBoundingClientRect();
      if (r.left < 0 || r.right > window.innerWidth) scrollToStop(h, stop, true);
    });

    // #hash links that point at a panel (nav, footer, direct URL) scroll to the right slide
    function hashTarget(href) {
      var i = href.indexOf('#'); if (i < 0) return null;
      var id = decodeURIComponent(href.slice(i + 1)); if (!id) return null;
      var a = doc.createElement('a'); a.href = href;
      if (a.pathname.replace(/^\//, '') !== location.pathname.replace(/^\//, '') && a.pathname !== location.pathname) return null;
      return doc.getElementById(id);
    }
    window.addEventListener('click', function (e) {
      var a = e.target.closest && e.target.closest('a[href*="#"]'); if (!a) return;
      var t = hashTarget(a.getAttribute('href')); if (!t) return;
      var h = hsFor(t); if (!h) return;
      var stop = h.stops.filter(function (s) { return s === t || s.contains(t); })[0]; if (!stop) return;
      e.preventDefault(); e.stopImmediatePropagation();
      scrollToStop(h, stop);
    }, true);
    function fromHash() {
      if (!location.hash) return;
      var t = doc.getElementById(decodeURIComponent(location.hash.slice(1))); if (!t) return;
      var h = hsFor(t); if (!h) return;
      var stop = h.stops.filter(function (s) { return s === t || s.contains(t); })[0];
      if (stop) setTimeout(function () { scrollToStop(h, stop, true); }, 250);
    }
    window.addEventListener('load', fromHash);
    window.addEventListener('hashchange', fromHash);
  });

  /* ======================================================================
     E  VELOCITY MARQUEE — drifts on its own, speeds up (and reverses) with
        scroll velocity, leans into the motion.
     ====================================================================== */
  safe('velocity marquee', function () {
    var box = doc.querySelector('[data-tg97-marquee]');
    if (!box || reduce) return;
    var rows = [].map.call(box.querySelectorAll('.tg97-marquee__row'), function (row) {
      var set = row.querySelector('.tg97-marquee__set');
      return { row: row, set: set, w: 0, x: 0, dir: parseFloat(row.getAttribute('data-dir')) || -1 };
    });
    function fill() {
      rows.forEach(function (r) {
        [].slice.call(r.row.querySelectorAll('.tg97-marquee__set')).slice(1).forEach(function (c) { c.remove(); });
        r.w = r.set.getBoundingClientRect().width || 1;
        var copies = Math.ceil((window.innerWidth * 2) / r.w) + 1;
        for (var i = 0; i < copies; i++) {
          var c = r.set.cloneNode(true); c.setAttribute('aria-hidden', 'true'); r.row.appendChild(c);
        }
        if (r.dir > 0 && r.x === 0) r.x = -r.w;
      });
    }
    fill();
    if (doc.fonts && doc.fonts.ready) doc.fonts.ready.then(fill);
    window.addEventListener('resize', debounce(fill, 200));

    var vel = 0, lastY = window.scrollY, last = performance.now(), running = false, raf = 0;
    function frame(now) {
      if (!running) return;
      var dt = Math.min(0.05, (now - last) / 1000) || 0.016; last = now;
      var y = window.scrollY, raw = (y - lastY) / Math.max(dt, 0.001); lastY = y;
      vel += (raw - vel) * Math.min(1, dt * 7);
      var skew = clamp(-vel * 0.0035, -9, 9);
      rows.forEach(function (r) {
        r.x += r.dir * (70 + vel * 0.5) * dt;
        if (r.x <= -r.w) r.x += r.w; else if (r.x > 0) r.x -= r.w;
        r.row.style.transform = 'translate3d(' + r.x.toFixed(2) + 'px,0,0) skewX(' + skew.toFixed(2) + 'deg)';
      });
      raf = requestAnimationFrame(frame);
    }
    function start() { if (running) return; running = true; last = performance.now(); lastY = window.scrollY; raf = requestAnimationFrame(frame); }
    function stop() { running = false; cancelAnimationFrame(raf); }
    if (hasIO) new IntersectionObserver(function (es) { es[0].isIntersecting && !doc.hidden ? start() : stop(); }, { rootMargin: '120px 0px' }).observe(box);
    else start();
    doc.addEventListener('visibilitychange', function () { if (doc.hidden) stop(); });
  });

  /* ======================================================================
     F  CUSTOM CURSOR + MAGNETIC BUTTONS (mouse / trackpad only)
     ====================================================================== */
  safe('cursor + magnetic', function () {
    if (!fine) return;
    var ring = doc.createElement('div'), dot = doc.createElement('div'), label = doc.createElement('div'), fbox = doc.createElement('div');
    ring.className = 'tg97-cur-ring'; dot.className = 'tg97-cur-dot'; label.className = 'tg97-cur-label'; fbox.className = 'tg97-cur-frame';
    [ring, dot, fbox, label].forEach(function (n) { n.setAttribute('aria-hidden', 'true'); doc.body.appendChild(n); });

    var mx = -100, my = -100, rx = -100, ry = -100, live = false, raf = 0, last = performance.now(), lastTarget = null;
    var snapEl = null, fx = 0, fy = 0, fw = 34, fh = 34, fr = 17, dirty = false;
    var CARD = '[data-cursor], .work-tile, .project-panel, .v8-row';
    var LINK = 'a[href], button, [role="button"], summary, label[for], .filter-chip, .theme-toggle';
    var TEXT = 'input, textarea, select, [contenteditable="true"]';
    var SNAP_MAX_W = 360, SNAP_MAX_H = 96, PAD = 6;

    /* is the surface under the pointer dark? (nearest opaque background, else the theme) */
    function isDark(t) {
      for (var n = t; n && n.nodeType === 1 && n !== root; n = n.parentElement) {
        var m = getComputedStyle(n).backgroundColor.match(/rgba?\(([^)]+)\)/);
        if (!m) continue;
        var p = m[1].split(',').map(parseFloat), a = p.length > 3 ? p[3] : 1;
        if (a > 0.5) return (0.2126 * p[0] + 0.7152 * p[1] + 0.0722 * p[2]) / 255 < 0.45;
      }
      return root.getAttribute('data-theme') === 'dark';
    }
    function radiusOf(el, r) {
      var v = parseFloat(getComputedStyle(el).borderTopLeftRadius) || 0;
      return Math.min(v + PAD, (Math.min(r.width, r.height) + PAD * 2) / 2);
    }
    function setState(t) {
      var c = root.classList;
      c.remove('tg97-cur-link', 'tg97-cur-card', 'tg97-cur-text', 'tg97-cur-snap');
      label.classList.remove('has-text');
      snapEl = null;
      if (!t || !t.closest) return;
      c.toggle('tg97-cur-dark', isDark(t));
      if (t.closest(TEXT)) { c.add('tg97-cur-text'); return; }
      var card = t.closest(CARD);
      if (card) {
        c.add('tg97-cur-card');
        label.textContent = card.getAttribute('data-cursor') || (card.matches('.work-tile, .project-panel') ? 'View' : 'Open');
        label.classList.add('has-text'); return;
      }
      var el = t.closest(LINK);
      if (!el) return;
      var r = el.getBoundingClientRect();
      if (r.width > 0 && r.width <= SNAP_MAX_W && r.height <= SNAP_MAX_H) {
        if (!c.contains('tg97-cur-snap') && !fbox.style.width) { fx = rx; fy = ry; fw = 34; fh = 34; fr = 17; }
        snapEl = el; c.add('tg97-cur-snap');
      } else c.add('tg97-cur-link');
    }
    function frame_(k) {
      var tx = mx, ty = my, tw = 34, th = 34, tr = 17;
      if (snapEl) {
        if (!snapEl.isConnected) { setState(null); return; }
        var r = snapEl.getBoundingClientRect();
        tx = r.left + r.width / 2; ty = r.top + r.height / 2;
        tw = r.width + PAD * 2; th = r.height + PAD * 2; tr = radiusOf(snapEl, r);
      } else if (!root.classList.contains('tg97-cur-snap')) return;
      var s = Math.min(1, k * 1.5);
      fx = lerp(fx, tx, s); fy = lerp(fy, ty, s); fw = lerp(fw, tw, s); fh = lerp(fh, th, s); fr = lerp(fr, tr, s);
      fbox.style.width = fw.toFixed(1) + 'px'; fbox.style.height = fh.toFixed(1) + 'px'; fbox.style.borderRadius = fr.toFixed(1) + 'px';
      fbox.style.transform = 'translate3d(' + fx.toFixed(1) + 'px,' + fy.toFixed(1) + 'px,0) translate(-50%,-50%)';
    }
    function frame(now) {
      var dt = Math.min(0.05, (now - last) / 1000) || 0.016; last = now;
      var k = 1 - Math.exp(-dt * 16);
      rx = lerp(rx, mx, k); ry = lerp(ry, my, k);
      ring.style.transform = 'translate3d(' + rx.toFixed(1) + 'px,' + ry.toFixed(1) + 'px,0)';
      dot.style.transform = 'translate3d(' + mx + 'px,' + my + 'px,0)' + (root.classList.contains('tg97-cur-snap') ? ' scale(.8)' : root.classList.contains('tg97-cur-down') ? ' scale(.7)' : '');
      label.style.transform = 'translate3d(' + rx.toFixed(1) + 'px,' + ry.toFixed(1) + 'px,0) translate(-50%,-50%)';
      if (dirty) { dirty = false; var u = doc.elementFromPoint(mx, my); if (u && u !== lastTarget) { lastTarget = u; setState(u); } }
      frame_(k);
      raf = requestAnimationFrame(frame);
    }
    function pulse() {
      if (reduce || root.classList.contains('tg97-cur-text')) return;
      var p = doc.createElement('div'); p.className = 'tg97-cur-pulse'; p.setAttribute('aria-hidden', 'true');
      p.style.transform = 'translate3d(' + mx + 'px,' + my + 'px,0)';
      p.addEventListener('animationend', function () { p.remove(); });
      doc.body.appendChild(p);
    }
    doc.addEventListener('pointermove', function (e) {
      if (e.pointerType && e.pointerType !== 'mouse' && e.pointerType !== 'pen') return;
      mx = e.clientX; my = e.clientY;
      if (e.target !== lastTarget) { lastTarget = e.target; setState(e.target); }
      if (!live) {
        live = true; rx = mx; ry = my;
        root.classList.add('tg97-cursor-on', 'tg97-cursor-live');
        last = performance.now(); raf = requestAnimationFrame(frame);
      }
    }, { passive: true });
    window.addEventListener('scroll', function () { dirty = true; }, { passive: true });
    doc.addEventListener('pointerdown', function () { root.classList.add('tg97-cur-down'); pulse(); }, { passive: true });
    ['pointerup', 'pointercancel', 'dragend'].forEach(function (ev) { doc.addEventListener(ev, function () { root.classList.remove('tg97-cur-down'); }, { passive: true }); });
    doc.documentElement.addEventListener('mouseleave', function () { root.classList.remove('tg97-cursor-live'); });
    doc.documentElement.addEventListener('mouseenter', function () { if (live) root.classList.add('tg97-cursor-live'); });
    window.addEventListener('blur', function () { root.classList.remove('tg97-cursor-live', 'tg97-cur-down'); });

    /* magnetic pull on buttons */
    var MAG = '.btn, .btn-ghost, [data-magnetic]';
    var cur = null, cx = 0, cy = 0, ox = 0, oy = 0;
    function release(el) { if (!el) return; el.classList.remove('is-pulling'); el.style.translate = ''; }
    doc.addEventListener('pointermove', function (e) {
      if (e.pointerType !== 'mouse') return;
      var t = e.target.closest ? e.target.closest(MAG) : null;
      if (t && (t.disabled || t.closest('.tg-pi, .project-modal-panel'))) t = null;
      if (cur && cur !== t) { release(cur); cur = null; }
      if (!t) return;
      if (t !== cur) {
        cur = t; t.setAttribute('data-magnetic-on', '');
        var r = t.getBoundingClientRect(), tr = (t.style.translate || '0px 0px').split(' ');
        ox = parseFloat(tr[0]) || 0; oy = parseFloat(tr[1]) || 0;
        cx = r.left + r.width / 2 - ox; cy = r.top + r.height / 2 - oy;
      }
      t.classList.add('is-pulling');
      var dx = clamp((e.clientX - cx) * 0.3, -14, 14), dy = clamp((e.clientY - cy) * 0.42, -10, 10);
      t.style.translate = dx.toFixed(1) + 'px ' + dy.toFixed(1) + 'px';
    }, { passive: true });
    doc.addEventListener('pointerleave', function () { release(cur); cur = null; }, true);
  });

  /* ======================================================================
     G  SVG LINE DRAWING — strokes in service / work art draw themselves
        (the process path is driven by scroll in section D)
     ====================================================================== */
  safe('line drawing', function () {
    if (reduce) return;
    [].forEach.call(doc.querySelectorAll('.service-art svg, .work-tile-art svg'), function (svg) {
      var n = 0;
      [].forEach.call(svg.querySelectorAll('path, line, polyline, polygon, rect, circle, ellipse'), function (s) {
        if (s.closest('defs')) return;
        var cs = getComputedStyle(s);
        if (!cs.stroke || cs.stroke === 'none') return;
        if (cs.strokeDasharray && cs.strokeDasharray !== 'none') return;
        s.setAttribute('pathLength', '1'); s.classList.add('tg97-draw'); s.style.setProperty('--di', n++);
      });
    });
  });

  /* ======================================================================
     H  CARD TILT + GLARE
     ====================================================================== */
  safe('tilt', function () {
    if (!fine || reduce) return;
    var SEL = '.work-tile, .model-card, .v8-row, .values-grid > *, .team-grid > *, .benefits-grid > *, .toolkit-grid > *, [data-tilt-card]';
    [].forEach.call(doc.querySelectorAll(SEL), function (el) {
      if (el.closest('.tg-pi, .project-modal-panel')) return;
      if (getComputedStyle(el).position === 'static') el.style.position = 'relative';
      var g = doc.createElement('span'); g.className = 'tg97-glare'; g.setAttribute('aria-hidden', 'true'); el.appendChild(g);
      el.classList.add('tg97-tilt');
      var rect = null, max = 6, raf = 0, ev = null, leaveT = 0;
      function paint() {
        raf = 0; if (!ev || !rect) return;
        var px = clamp((ev.clientX - rect.left) / rect.width, 0, 1), py = clamp((ev.clientY - rect.top) / rect.height, 0, 1);
        el.style.setProperty('--ry', ((px - 0.5) * 2 * max).toFixed(2) + 'deg');
        el.style.setProperty('--rx', ((0.5 - py) * 2 * max).toFixed(2) + 'deg');
        el.style.setProperty('--gx', (px * 100).toFixed(1) + '%'); el.style.setProperty('--gy', (py * 100).toFixed(1) + '%');
      }
      el.addEventListener('pointerenter', function (e) {
        if (e.pointerType !== 'mouse') return;
        clearTimeout(leaveT); el.classList.remove('is-leaving');
        rect = el.getBoundingClientRect(); max = rect.width > 700 ? 2.6 : 6;
        el.classList.add('is-tilting');
      });
      el.addEventListener('pointermove', function (e) {
        if (e.pointerType !== 'mouse') return;
        ev = e; if (!raf) raf = requestAnimationFrame(paint);
      }, { passive: true });
      el.addEventListener('pointerleave', function () {
        el.classList.remove('is-tilting'); el.classList.add('is-leaving');
        el.style.setProperty('--rx', '0deg'); el.style.setProperty('--ry', '0deg');
        leaveT = setTimeout(function () { el.classList.remove('is-leaving'); }, 720);
      });
    });
  });

  /* ======================================================================
     I  ARROW ICON on content links/buttons (the shape morph is CSS `d`)
     ====================================================================== */
  safe('arrow icons', function () {
    [].forEach.call(doc.querySelectorAll('main a.btn, main a.btn-ghost, .cta-banner a.btn'), function (a) {
      if (a.querySelector('svg') || a.matches('.role-apply, .tg-pi-back, .tg-pi-next, .tg-pi-continue, .tg-pi-restart') || a.closest('.tg-pi')) return;
      a.insertAdjacentHTML('beforeend',
        '<svg class="tg97-arrow" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path class="a-shaft" d="M4 12L20 12"/><path class="a-head" d="M13 5L20 12L13 19"/></svg>');
    });
  });

  /* ======================================================================
     J  PLAY-ON-ENTER VIDEO — loads near the viewport, plays only while visible
     ====================================================================== */
  safe('play-on-enter video', function () {
    var vids = [].slice.call(doc.querySelectorAll('video[data-play-on-enter]'));
    if (!vids.length || !hasIO) return;
    var conn = navigator.connection || {};
    if (reduce || conn.saveData || /(^|-)(2g|3g)$/.test(conn.effectiveType || '')) return;     // poster only
    function load(v) {
      if (v.getAttribute('data-loaded')) return;
      v.setAttribute('data-loaded', '1');
      var webm = v.getAttribute('data-src-webm'), mp4 = v.getAttribute('data-src');
      v.src = (webm && v.canPlayType('video/webm; codecs="vp9"')) ? webm : mp4;
      v.load();
    }
    var ioLoad = new IntersectionObserver(function (es) {
      es.forEach(function (e) { if (e.isIntersecting) { load(e.target); ioLoad.unobserve(e.target); } });
    }, { rootMargin: '500px 0px' });
    var ioPlay = new IntersectionObserver(function (es) {
      es.forEach(function (e) {
        var v = e.target;
        if (e.isIntersecting && !doc.hidden) { load(v); var p = v.play(); if (p && p.catch) p.catch(function () {}); }
        else v.pause();
      });
    }, { threshold: 0.15 });
    vids.forEach(function (v) { ioLoad.observe(v); ioPlay.observe(v); });
    doc.addEventListener('visibilitychange', function () { if (doc.hidden) vids.forEach(function (v) { v.pause(); }); });
  });

  window.TGMotion = { version: '09.7' };
})();
