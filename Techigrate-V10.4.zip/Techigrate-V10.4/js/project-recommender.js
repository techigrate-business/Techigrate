/* ==========================================================================
   TECHIGRATE — Project recommender logic
   ==========================================================================
   Self-contained: all questions/options/recommendations live in DATA below.
   Defensive: if #tg-pr-root isn't on the page, this whole file is a no-op —
   no console errors, nothing thrown. Uses one delegated click listener on
   the stage rather than per-button listeners.

   Recommendation content is grounded in this site's actual services.html
   pillars (Product engineering / Intelligent systems / Automation &
   infrastructure) rather than invented claims. Where there's no existing
   fact to point to (the "Not sure" path), the copy stays deliberately
   general instead of inventing a specific service angle.
   ========================================================================== */

(function () {
  'use strict';

  var root = document.querySelector('[data-tg-pr-root]');
  if (!root) return; // host page doesn't have the feature installed — nothing to do

  var stage = root.querySelector('[data-tg-pr-stage]');
  if (!stage) return;

  // Only from here on do we know the widget is genuinely present and
  // about to become interactive — flips the no-JS CSS fallback off (see
  // css/project-recommender.css) in favor of the real, interactive stage.
  root.setAttribute('data-tg-pr-js', '');

  /* ------------------------------- Data model -------------------------------- */
  var DATA = {
    category: {
      website: {
        label: 'Website',
        question: "What's closest to true?",
        options: [
          { id: 'none', label: "We don't have one yet" },
          { id: 'outdated', label: 'Ours feels outdated' },
          { id: 'noconvert', label: "It works, but doesn't get us leads" }
        ]
      },
      software: {
        label: 'Software',
        question: "What's closest to true?",
        options: [
          { id: 'manual', label: "We're doing this by hand right now" },
          { id: 'misfit', label: "We have a tool but it doesn't fit" },
          { id: 'fromscratch', label: 'We need something built from the ground up' }
        ]
      },
      ai: {
        label: 'AI',
        question: "What's closest to true?",
        options: [
          { id: 'startingout', label: "We want to try AI but don't know where to start" },
          { id: 'haveidea', label: 'We have an idea but need it built' },
          { id: 'integrate', label: 'We already use AI tools but want them integrated properly' }
        ]
      },
      automation: {
        label: 'Automation',
        question: "What's closest to true?",
        options: [
          { id: 'repetitive', label: 'Repetitive manual work is eating our time' },
          { id: 'disconnected', label: "Our tools don't talk to each other" },
          { id: 'fewerparts', label: 'We want fewer moving parts, not more' }
        ]
      },
      unsure: {
        label: 'Not sure',
        question: "That's alright — what's closest to true?",
        options: [
          { id: 'something', label: "I know I need something, just not what" },
          { id: 'explore', label: 'I want to see what you\u2019ve built first' },
          { id: 'talk', label: "I'd rather just talk it through" }
        ]
      }
    },

    // Keyed "category:context" — each maps to an existing services.html
    // pillar wherever a real fit exists; the "unsure" branch stays general
    // on purpose rather than forcing a pillar that may not fit.
    recommendations: {
      'website:none': {
        direction: 'Product engineering — built from scratch',
        why: 'Starting clean means the site gets built around what you actually need it to do, not retrofitted onto something old.',
        next: 'A short call to scope pages, must-have features, and a realistic timeline.'
      },
      'website:outdated': {
        direction: 'Product engineering — a rebuild',
        why: 'An outdated site is usually worth rebuilding rather than repainting — old foundations tend to fight you the moment you want to change anything.',
        next: "We'll look at what's there first, then tell you honestly whether it needs a rebuild or just a repair."
      },
      'website:noconvert': {
        direction: 'Product engineering — focused on the funnel',
        why: "Traffic without conversions is usually a structure problem, not a content problem — the fix is in the path someone takes through the site.",
        next: "We'll walk through your current site together and flag exactly where people are dropping off."
      },
      'software:manual': {
        direction: 'Product engineering — a purpose-built tool',
        why: 'A manual process is usually a sign the work has outgrown spreadsheets, not that the team needs to work harder.',
        next: "Tell us the process — we'll scope the smallest tool that actually removes the manual step."
      },
      'software:misfit': {
        direction: 'Product engineering — built around your process',
        why: "Off-the-shelf tools are built for an average business, and yours usually isn't average in the one place that matters.",
        next: 'A short walkthrough of where the current tool breaks down for you.'
      },
      'software:fromscratch': {
        direction: 'Product engineering — from scratch',
        why: 'Custom software makes sense once buying something and bending it to fit costs more than just building it right.',
        next: "We'll scope the smallest version worth shipping first, not the whole system at once."
      },
      'ai:startingout': {
        direction: 'Intelligent systems — a focused starting point',
        why: "The AI projects that work best usually start narrow — one real workflow, not \u201cAI for everything\u201d on day one.",
        next: "A conversation about where judgment calls are actually slowing your team down."
      },
      'ai:haveidea': {
        direction: 'Intelligent systems — built and evaluated properly',
        why: "An idea becomes useful once it's tested against real cases, not just a demo that works once.",
        next: "We'll scope the model, the data it needs, and how we'll know if it's actually working."
      },
      'ai:integrate': {
        direction: 'Intelligent systems — wired into your workflow',
        why: 'Most AI tools sit next to the work instead of inside it — the value shows up once it actually becomes part of the process.',
        next: "Walk us through the tools you're using now and where the handoffs feel clunky."
      },
      'automation:repetitive': {
        direction: 'Automation & infrastructure — remove the manual step',
        why: "If a task is repetitive and rule-based, it's usually automatable — the trick is knowing which one to fix first.",
        next: "Tell us the task — we'll tell you honestly whether it's worth automating yet."
      },
      'automation:disconnected': {
        direction: 'Automation & infrastructure — connect the systems',
        why: "Disconnected tools usually mean someone is manually copying data between them right now — that's the first thing worth removing.",
        next: 'A quick map of your current tools and where the gaps are.'
      },
      'automation:fewerparts': {
        direction: 'Automation & infrastructure — simplify first',
        why: 'Sometimes the right move is removing a tool rather than adding one — infrastructure that runs quietly usually has fewer parts, not more.',
        next: "We'll look at what you're running today before recommending anything new."
      },
      'unsure:something': {
        direction: 'Start with a conversation, not a decision',
        why: 'Most projects get clearer after describing the problem out loud to someone who builds this for a living.',
        next: 'A short call — no pitch, just questions until it\u2019s clear what you actually need.'
      },
      'unsure:explore': {
        direction: 'Look through what we\u2019ve actually built',
        why: 'Seeing real examples usually narrows things down faster than describing what you want in the abstract.',
        next: 'Take a look at our work, then reach out with whatever feels closest.',
        ctaLabel: 'See our work',
        ctaHref: 'work.html'
      },
      'unsure:talk': {
        direction: "Let's just talk it through",
        why: "Sometimes the fastest way to find the right direction is describing the problem to someone who'll ask the right questions back.",
        next: 'Send us a message — tell us as much or as little as you know right now.'
      }
    }
  };

  var DEFAULT_CTA_LABEL = 'Start a project';
  var DEFAULT_CTA_HREF = 'contact.html#tg-pi-root';

  // Maps this module's category ids to Project Intake's "improve" values
  // (see the tg-pi-widget embedded on contact.html / js/tg-pi.js), so a
  // visitor who already picked a category here doesn't get asked the
  // same thing again in Step 1 of the intake quiz. "automation" maps to
  // "infrastructure" deliberately, not by accident — services.html's own
  // pillar naming ("03 / Automation & Infrastructure") treats the two as
  // one pillar; see PROJECT-RECOMMENDER.md for the full reasoning.
  var SEED_MAP = { website: 'web', software: 'software', ai: 'ai', automation: 'infrastructure', unsure: 'unsure' };

  /* ------------------------------- Elements ---------------------------------- */
  var panels = {
    category: root.querySelector('[data-tg-pr-panel="category"]'),
    context: root.querySelector('[data-tg-pr-panel="context"]'),
    result: root.querySelector('[data-tg-pr-panel="result"]')
  };
  var dots = root.querySelectorAll('[data-tg-pr-dot]');
  var contextQuestionEl = root.querySelector('[data-tg-pr-context-question]');
  var categoryQuestionEl = root.querySelector('#tg-pr-q-category');
  var contextOptionsEl = root.querySelector('[data-tg-pr-options="context"]');
  var directionEl = root.querySelector('[data-tg-pr-direction]');
  var whyEl = root.querySelector('[data-tg-pr-why]');
  var nextEl = root.querySelector('[data-tg-pr-next]');
  var ctaEl = root.querySelector('[data-tg-pr-cta]');
  var ctaLabelEl = root.querySelector('[data-tg-pr-cta-label]');
  var pathLabelEls = root.querySelectorAll('[data-tg-pr-path-label]');

  if (!panels.category || !panels.context || !panels.result) return; // markup incomplete — bail quietly

  var state = { category: null, context: null };

  /* -------------------------------- Rendering --------------------------------- */
  function showPanel(name) {
    Object.keys(panels).forEach(function (key) {
      var isTarget = key === name;
      panels[key].classList.toggle('is-active', isTarget);
    });
    var stepNumber = name === 'category' ? 1 : name === 'context' ? 2 : 3;
    dots.forEach(function (dot) {
      var n = Number(dot.getAttribute('data-tg-pr-dot'));
      dot.classList.toggle('is-active', n === stepNumber);
      dot.classList.toggle('is-done', n < stepNumber);
    });
  }

  function focusHeading(el) {
    if (!el) return;
    // rAF so it runs after the panel's own display/animation state has applied
    window.requestAnimationFrame(function () {
      try { el.focus({ preventScroll: true }); } catch (e) { el.focus(); }
    });
  }

  function renderContext(categoryId) {
    var cat = DATA.category[categoryId];
    if (!cat) return;
    contextQuestionEl.textContent = cat.question;
    contextOptionsEl.innerHTML = '';
    cat.options.forEach(function (opt) {
      var btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'tg-pr-option';
      btn.setAttribute('data-tg-pr-value', opt.id);
      btn.textContent = opt.label;
      contextOptionsEl.appendChild(btn);
    });
  }

  function renderResult(categoryId, contextId) {
    var key = categoryId + ':' + contextId;
    var rec = DATA.recommendations[key];
    if (!rec) return; // unknown combination — fail quietly rather than show broken content

    directionEl.textContent = rec.direction;
    whyEl.textContent = rec.why;
    nextEl.textContent = rec.next;

    if (ctaEl) {
      ctaEl.setAttribute('href', rec.ctaHref || DEFAULT_CTA_HREF);
    }
    if (ctaLabelEl) {
      ctaLabelEl.textContent = rec.ctaLabel || DEFAULT_CTA_LABEL;
    }

    if (pathLabelEls.length === 3) {
      pathLabelEls[0].textContent = DATA.category[categoryId].label;
      var contextOpt = DATA.category[categoryId].options.filter(function (o) { return o.id === contextId; })[0];
      pathLabelEls[1].textContent = contextOpt ? truncate(contextOpt.label, 24) : '';
    }
  }

  function truncate(str, max) {
    return str.length > max ? str.slice(0, max - 1) + '\u2026' : str;
  }

  /* ---------------------------------- Flow ------------------------------------ */
  function selectCategory(id) {
    if (!DATA.category[id]) return;
    state.category = id;
    state.context = null;
    renderContext(id);
    showPanel('context');
    focusHeading(contextQuestionEl);
  }

  function selectContext(id) {
    if (!state.category) return;
    state.context = id;
    renderResult(state.category, id);
    showPanel('result');
    focusHeading(directionEl);
  }

  function goBack(target) {
    if (target === 'category' || target === 'start') {
      state.category = null;
      state.context = null;
      contextOptionsEl.innerHTML = '';
      showPanel('category');
      focusHeading(categoryQuestionEl);
    }
  }

  /* ------------------------------ Event delegation ----------------------------- */
  stage.addEventListener('click', function (e) {
    var optionBtn = e.target.closest('[data-tg-pr-value]');
    if (optionBtn) {
      var value = optionBtn.getAttribute('data-tg-pr-value');
      var withinCategoryPanel = panels.category.contains(optionBtn);
      if (withinCategoryPanel) {
        selectCategory(value);
      } else {
        selectContext(value);
      }
      return;
    }

    var backBtn = e.target.closest('[data-tg-pr-back]');
    if (backBtn) {
      goBack(backBtn.getAttribute('data-tg-pr-back'));
    }
  });

  /* ------------------------- Hand off to Project Intake ------------------------
     Only when the CTA is actually headed to the contact page's intake
     widget — the "explore our work" path goes to work.html instead, and
     there's nothing to seed there. Never blocks or delays the navigation
     itself; this is a plain <a>, and if sessionStorage throws (private
     mode, storage disabled), the link still works exactly the same, just
     without the seed. js/tg-pi.js reads and immediately clears this key
     on load — see its recommenderSeed handling. */
  if (ctaEl) {
    ctaEl.addEventListener('click', function () {
      var href = ctaEl.getAttribute('href') || '';
      if (!state.category || href.indexOf('contact.html') !== 0) return;
      var seed = SEED_MAP[state.category];
      if (!seed) return;
      try {
        window.sessionStorage.setItem('techigrateRecommenderSeed', seed);
      } catch (err) { /* storage unavailable — link still works without the seed */ }
    });
  }

  // Initial state
  showPanel('category');
})();
