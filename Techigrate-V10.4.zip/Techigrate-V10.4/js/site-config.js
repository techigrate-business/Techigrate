/* ==========================================================================
   TECHIGRATE — site constants (single source of truth)
   Every script that needs the contact email or the lead endpoint reads it
   from here. Change a value once and it changes everywhere in JavaScript.
   (Static text in the HTML — footer, contact page — shows the same values.)
   ========================================================================== */
window.TECHIGRATE_SITE = Object.freeze({
  name: 'Techigrate',
  email: 'techigrate.business@gmail.com',
  location: 'Delhi, India',
  // Google Apps Script Web App that receives leads (Website form -> doPost -> Leads sheet)
  appsScriptUrl: 'https://script.google.com/macros/s/AKfycbwgv6au8BStQIekHTh3YPZYywxYewwyKh7VePddLi0xMQ4TXvnEkgMvunhuEs6RDzBVXA/exec',
  // Analytics on/off for the whole site (the Settings tab "analytics_enabled" can also switch it off remotely).
  analytics: true,
  // true = visitors who send Do-Not-Track / Global Privacy Control are not tracked.
  respectDoNotTrack: true,
  // How long the contact form waits for the backend's "saved" confirmation before it assumes the message was sent.
  leadTimeoutMs: 9000
});
