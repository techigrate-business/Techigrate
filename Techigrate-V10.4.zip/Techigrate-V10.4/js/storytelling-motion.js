
/* ============================================================================
   TECHIGRATE — STORYTELLING MOTION
   Lightweight enhancement layer inspired by the supplied motion reference.
   It adds sequencing, active emphasis and subtle image depth without changing
   the site's content or branding.
   ============================================================================ */
(function(){
  'use strict';
  const reduce = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
  const fine = window.matchMedia?.('(pointer:fine)').matches;

  const page = location.pathname.split('/').pop() || 'index.html';
  const isMainPage = !/^(privacy|terms|404|demo|preview|template)\.html$/i.test(page);
  if(!isMainPage) return;

  const mark = (el)=>{
    if(!el || el.dataset.tgStoryPrepared==='1') return;
    el.dataset.tgStoryPrepared='1';
    el.setAttribute('data-tg-story','');

    // Reveal the visual hierarchy in deliberate beats.
    const candidates = el.querySelectorAll(':scope > .container > *, :scope > .hero-inner > *, :scope > .section-head > *, :scope > .capability-row, :scope > .process-grid > *, :scope > .work-preview-grid > *, :scope > .model-grid > *, :scope > .toolkit-grid > *, :scope > .values-grid > *, :scope > .team-grid > *, :scope > .benefits-grid > *, :scope > .role-list > *, :scope > .faq-list > *, :scope > .contact-grid > *, :scope > .tg-pricing');
    let delay = 0;
    candidates.forEach(node=>{
      if(node.matches('.nav-search__dialog')) return;
      node.classList.add('tg-story-enter');
      delay = Math.min(delay+1,5);
      node.dataset.tgStoryDelay=String(delay);
    });
  };

  document.querySelectorAll('main > section, main > .sj-track > section').forEach(sec=>{
    if(sec.classList.contains('project-modal-panel') || sec.classList.contains('nav-search__dialog')) return;
    mark(sec);
  });

  // Add image depth to prominent visual regions.
  document.querySelectorAll('.hero-visual,.hero-orb-stage,.work-tile-art,.project-panel-art,.service-art,.stack-scene,.story-grid figure,[data-story-image]').forEach(wrap=>{
    wrap.classList.add('tg-story-image-wrap');
    const img=wrap.querySelector('img');
    if(img) img.classList.add('tg-story-image');
  });

  // Emphasis groups: one item grows in focus while the surrounding items recede.
  ['.capability-list','.model-grid','.toolkit-grid','.values-grid','.team-grid','.benefits-grid'].forEach(sel=>{
    document.querySelectorAll(sel).forEach(group=>{
      group.classList.add('tg-focus-group');
      group.querySelectorAll(':scope > *').forEach(item=>{
        item.addEventListener('pointerenter',()=>item.classList.add('tg-focus-active'),{passive:true});
        item.addEventListener('pointerleave',()=>item.classList.remove('tg-focus-active'),{passive:true});
      });
    });
  });

  const io = new IntersectionObserver(entries=>{
    entries.forEach(entry=>{
      if(entry.isIntersecting){
        entry.target.classList.add('tg-story-visible');
        io.unobserve(entry.target);
      }
    });
  },{threshold:.14, rootMargin:'0px 0px -8% 0px'});
  document.querySelectorAll('[data-tg-story]').forEach(el=>io.observe(el));

  if(!reduce && fine){
    let scrollY=window.scrollY||0;
    let raf=0;
    const updateParallax=()=>{
      raf=0;
      const viewport=innerHeight||1;
      document.querySelectorAll('.tg-story-image').forEach(img=>{
        const r=img.getBoundingClientRect();
        if(r.bottom<0 || r.top>viewport) return;
        const center=r.top+r.height/2;
        const delta=(viewport/2-center)/viewport;
        img.style.setProperty('--tg-parallax-y', `${(delta*10).toFixed(2)}px`);
      });
    };
    const request=()=>{if(!raf) raf=requestAnimationFrame(updateParallax)};
    window.addEventListener('scroll',request,{passive:true});
    window.addEventListener('resize',request,{passive:true});
    request();
  }

  // Tiny pointer tilt for selected visual cards; bounded so the site remains calm.
  if(!reduce && fine){
    document.querySelectorAll('.work-tile,.model-card,.toolkit-card,.value-card,.team-card,.benefit').forEach(card=>{
      let active=false;
      card.addEventListener('pointerenter',()=>{active=true;},{passive:true});
      card.addEventListener('pointermove',e=>{
        if(!active) return;
        const r=card.getBoundingClientRect();
        const x=(e.clientX-r.left)/r.width-.5;
        const y=(e.clientY-r.top)/r.height-.5;
        card.style.setProperty('--tg-tilt-x',`${(-y*2.1).toFixed(2)}deg`);
        card.style.setProperty('--tg-tilt-y',`${(x*2.1).toFixed(2)}deg`);
        card.style.transform=`perspective(900px) translateY(-4px) rotateX(var(--tg-tilt-x)) rotateY(var(--tg-tilt-y))`;
      },{passive:true});
      card.addEventListener('pointerleave',()=>{
        active=false;
        card.style.removeProperty('--tg-tilt-x');
        card.style.removeProperty('--tg-tilt-y');
        card.style.removeProperty('transform');
      },{passive:true});
    });
  }
})();
