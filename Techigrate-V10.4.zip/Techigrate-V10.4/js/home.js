/* TECHIGRATE HOME V6 — minimal interactions */
(function(){
  'use strict';

  const card=document.querySelector('.hero-feature-card');
  card?.querySelector('.hero-feature-card__close')?.addEventListener('click',()=>{
    card.classList.add('is-dismissed');
    try{sessionStorage.setItem('techigrate-home-feature-dismissed','1')}catch(e){}
  });
  try{if(sessionStorage.getItem('techigrate-home-feature-dismissed')==='1') card?.classList.add('is-dismissed')}catch(e){}

  // Hero wordmark: type TECHIGRATE once, then leave a blinking caret.
  const typingRoot=document.querySelector('.tg-hero-typing[data-typing-text]');
  const typingTarget=typingRoot?.querySelector('.tg-hero-typing__text');
  if(!typingRoot||!typingTarget) return;

  const text=typingRoot.getAttribute('data-typing-text')||'TECHIGRATE';
  const reduceMotion=window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;

  typingTarget.textContent='';
  if(reduceMotion){
    typingTarget.textContent=text;
    return;
  }

  typingRoot.classList.add('is-typing');
  let index=0;
  const typeNext=()=>{
    typingTarget.textContent=text.slice(0,index+1);
    index+=1;
    if(index<text.length){
      window.setTimeout(typeNext,index<3?120:74);
    }else{
      typingRoot.classList.remove('is-typing');
    }
  };

  /* Wait for the existing intro/preloader to finish. We do not change the
     intro itself; we only delay the hero typing so it becomes visible after
     the initial welcome animation has cleared. */
  const startTypingAfterIntro=()=>{
    const begin=()=>window.setTimeout(typeNext,1120);
    if(document.fonts?.ready){
      document.fonts.ready.then(begin).catch(begin);
    }else{
      begin();
    }
  };
  if(document.body.classList.contains('tg-loaded')){
    startTypingAfterIntro();
  }else{
    const observer=new MutationObserver(()=>{
      if(document.body.classList.contains('tg-loaded')){
        observer.disconnect();
        startTypingAfterIntro();
      }
    });
    observer.observe(document.body,{attributes:true,attributeFilter:['class']});
    window.setTimeout(()=>{observer.disconnect();startTypingAfterIntro();},9000);
  }
})();
