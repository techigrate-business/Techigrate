/* ============================================================================
   TECHIGRATE — NAVIGATION RENOVATION V6 BEHAVIOR
   Visual hierarchy + page-state metadata, kept independent from the existing
   navigation and Dynamic Island logic so a failure here cannot break nav.
   ============================================================================ */
(function () {
  'use strict';

  try {
    const header = document.querySelector('.site-header');
    if (!header) return;
    header.classList.add('tg-nav-renovated');

    const navLinks = header.querySelector('.nav-links');
    const mobilePanel = header.querySelector('.mobile-panel');
    const topLinks = navLinks ? Array.from(navLinks.querySelectorAll('a[href]')) : [];
    const mobileLinks = mobilePanel ? Array.from(mobilePanel.querySelectorAll('a[href]')) : [];

    const normalize = (href) => {
      try {
        const url = new URL(href, window.location.href);
        return (url.pathname.split('/').pop() || 'index.html').toLowerCase();
      } catch (_) {
        return String(href || '').split('/').pop().toLowerCase();
      }
    };

    const current = (window.location.pathname.split('/').pop() || 'index.html').toLowerCase();
    const labelMap = {
      'services.html': 'Services',
      'work.html': 'Work',
      'technology.html': 'Technology',
      'about.html': 'About',
      'contact.html': 'Contact',
      'index.html': 'Home'
    };

    const assignMeta = (links) => {
      links.forEach((link, index) => {
        const href = link.getAttribute('href') || '';
        const file = normalize(href);
        link.dataset.navIndex = String(index + 1).padStart(2, '0');
        if (file === current) link.setAttribute('aria-current', 'page');
        const label = (labelMap[file] || link.textContent || '').trim();
        if (label) link.setAttribute('data-nav-label', label);
      });
    };

    assignMeta(topLinks);
    assignMeta(mobileLinks);

    /* Live page-progress rail under the expanded desktop dock. */
    let rail = header.querySelector('.tg-nav-progress');
    if (!rail) {
      rail = document.createElement('div');
      rail.className = 'tg-nav-progress';
      rail.setAttribute('aria-hidden', 'true');
      rail.innerHTML = '<span></span>';
      header.appendChild(rail);
    }

    const progressTick = () => {
      const max = Math.max(1, document.documentElement.scrollHeight - window.innerHeight);
      const value = Math.max(0, Math.min(1, (window.scrollY || 0) / max));
      header.style.setProperty('--tg-nav-page-progress', value.toFixed(4));
    };
    progressTick();
    window.addEventListener('scroll', progressTick, { passive: true });
    window.addEventListener('resize', progressTick, { passive: true });

    /* Clicking the collapsed Dynamic Island returns to the top where the full
       command dock is available again. It is deliberately not a fake page
       change: the island remains a navigation surface, the motion is only a
       spatial transition back to the dock. */
    const island = document.querySelector('.tg-island');
    if (island && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      island.removeAttribute('aria-hidden');
      island.setAttribute('role', 'button');
      island.setAttribute('tabindex', '0');
      island.setAttribute('aria-label', 'Return to top navigation');
      const goTop = () => {
        if (window.tgLenis && typeof window.tgLenis.scrollTo === 'function') {
          window.tgLenis.scrollTo(0, { duration: 0.7 });
        } else {
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }
      };
      island.addEventListener('click', goTop);
      island.addEventListener('keydown', (event) => {
        if (event.key === 'Enter' || event.key === ' ') {
          event.preventDefault();
          goTop();
        }
      });
    }

    /* Add a compact brand mark to the Dynamic Island. */
    if (island && !island.querySelector('.tg-island__mark')) {
      const mark = document.createElement('span');
      mark.className = 'tg-island__mark';
      mark.setAttribute('aria-hidden', 'true');
      mark.textContent = 'TG';
      const status = island.querySelector('.tg-island__status');
      island.insertBefore(mark, status || island.firstChild);
    }

    /* Stronger press feedback for every desktop nav link without changing the
       link's normal hover behavior. */
    [...topLinks, ...mobileLinks].forEach((link) => {
      link.addEventListener('pointerdown', () => {
        link.classList.remove('tg-nav-tap');
        void link.offsetWidth;
        link.classList.add('tg-nav-tap');
      }, { passive: true });
    });
  } catch (error) {
    console.error('Techigrate navigation renovation failed; existing navigation remains active.', error);
  }
})();
