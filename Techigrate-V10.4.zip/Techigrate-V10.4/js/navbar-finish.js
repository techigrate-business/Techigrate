/* Techigrate — final navbar detail layer */
(function(){
  'use strict';
  const header = document.querySelector('.site-header.tg-luxury-nav');
  if(!header) return;
  const dock = header.querySelector('[data-nav-dock]');
  const navLinks = header.querySelector('.nav-links');
  const finePointer = window.matchMedia('(pointer:fine)');
  const reduceQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
  const coarseQuery = window.matchMedia('(pointer:coarse)');
  if(!dock || !navLinks) return;

  /* One shared hover lens: it glides between top-level navigation options.
     Dropdown list entries are deliberately excluded. */
  const lens = document.createElement('span');
  lens.className = 'tg-nav-hover-lens';
  lens.setAttribute('aria-hidden','true');
  navLinks.prepend(lens);
  navLinks.style.setProperty('--tg-nav-lens-alpha','0');

  const topItems = Array.from(navLinks.children).flatMap((node) => {
    if(node.classList.contains('tg-nav-hover-lens')) return [];
    const direct = node.matches('.nav-item') ? node : node.querySelector(':scope > .nav-item');
    return direct ? [direct] : [];
  });

  const updateLens = (el, immediate = false) => {
    if(!el || !finePointer.matches || coarseQuery.matches || reduceQuery.matches) return;
    const nr = navLinks.getBoundingClientRect();
    const er = el.getBoundingClientRect();
    if(!nr.width || !er.width) return;
    navLinks.style.setProperty('--tg-nav-lens-x', `${(er.left - nr.left - 2).toFixed(2)}px`);
    navLinks.style.setProperty('--tg-nav-lens-y', `${(er.top - nr.top - 1).toFixed(2)}px`);
    navLinks.style.setProperty('--tg-nav-lens-w', `${(er.width + 4).toFixed(2)}px`);
    navLinks.style.setProperty('--tg-nav-lens-h', `${Math.max(40, er.height + 2).toFixed(2)}px`);
    navLinks.style.setProperty('--tg-nav-lens-alpha','1');
    navLinks.classList.add('tg-nav-has-hover-lens');
    if(immediate){
      lens.style.transition = 'none';
      requestAnimationFrame(() => { lens.style.transition = ''; });
    }
  };

  const hideLens = () => {
    navLinks.style.setProperty('--tg-nav-lens-alpha','0');
    navLinks.classList.remove('tg-nav-has-hover-lens');
  };

  topItems.forEach((el) => {
    el.addEventListener('pointerenter', () => updateLens(el), {passive:true});
    el.addEventListener('focusin', () => updateLens(el), {passive:true});
  });
  navLinks.addEventListener('pointerleave', hideLens, {passive:true});
  navLinks.addEventListener('focusout', (e) => {
    if(!navLinks.contains(e.relatedTarget)) hideLens();
  });

  /* Surface light follows the pointer without changing layout. */
  if(finePointer.matches && !reduceQuery.matches && !coarseQuery.matches){
    dock.addEventListener('pointermove', (e) => {
      const r = dock.getBoundingClientRect();
      if(!r.width || !r.height) return;
      dock.style.setProperty('--tg-nav-cursor-x', `${(e.clientX - r.left).toFixed(1)}px`);
      dock.style.setProperty('--tg-nav-cursor-y', `${(e.clientY - r.top).toFixed(1)}px`);
      dock.style.setProperty('--tg-nav-cursor-alpha','1');
      dock.style.setProperty('--tg-finish-glow','1');
    }, {passive:true});
    dock.addEventListener('pointerleave', () => {
      dock.style.setProperty('--tg-nav-cursor-alpha','0');
      dock.style.setProperty('--tg-finish-glow','0');
    }, {passive:true});
  }

  /* Add a local specular light layer once; it's intentionally inert. */
  if(!dock.querySelector('.tg-nav-finish-light')){
    const light = document.createElement('span');
    light.className = 'tg-nav-finish-light';
    light.setAttribute('aria-hidden','true');
    dock.prepend(light);
  }

  /* Tactile press ripple on top-level actions only. */
  const rippleTargets = header.querySelectorAll(
    '.nav-links > .nav-item, .nav-links > .tg-nav-menu > .nav-item, .nav-project-btn, .tg-nav-notification, .tg-nav-search-button'
  );
  rippleTargets.forEach((el) => {
    if(el.dataset.tgRippleBound) return;
    el.dataset.tgRippleBound = '1';
    el.style.overflow = 'hidden';
    el.addEventListener('pointerdown', (e) => {
      if(reduceQuery.matches || (e.pointerType && e.pointerType !== 'mouse')) return;
      const r = el.getBoundingClientRect();
      el.style.setProperty('--tg-ripple-x', `${e.clientX - r.left}px`);
      el.style.setProperty('--tg-ripple-y', `${e.clientY - r.top}px`);
      const ripple = document.createElement('span');
      ripple.className = 'tg-nav-ripple';
      ripple.setAttribute('aria-hidden','true');
      el.appendChild(ripple);
      ripple.addEventListener('animationend', () => ripple.remove(), {once:true});
    }, {passive:true});
  });

  /* Let the icon cluster breathe when scrolling, then settle. */
  let scrollTimer = 0;
  let lastY = window.scrollY || 0;
  window.addEventListener('scroll', () => {
    if(reduceQuery.matches) return;
    const y = window.scrollY || 0;
    const delta = Math.abs(y - lastY);
    lastY = y;
    if(delta < 1) return;
    header.classList.add('tg-nav-scroll-charged');
    window.clearTimeout(scrollTimer);
    scrollTimer = window.setTimeout(() => header.classList.remove('tg-nav-scroll-charged'), 180);
  }, {passive:true});

  /* Theme toggle receives one controlled impact animation. */
  header.querySelectorAll('.nav-theme-toggle .input').forEach((input) => {
    input.addEventListener('change', () => {
      if(reduceQuery.matches) return;
      const toggle = input.closest('.nav-theme-toggle');
      toggle?.classList.remove('tg-theme-flip');
      requestAnimationFrame(() => toggle?.classList.add('tg-theme-flip'));
      window.setTimeout(() => toggle?.classList.remove('tg-theme-flip'), 600);
    });
  });

  window.addEventListener('resize', () => {
    const active = navLinks.querySelector('.nav-item:hover, .tg-nav-menu-trigger:focus-visible');
    if(active) updateLens(active, true);
  }, {passive:true});
})();
