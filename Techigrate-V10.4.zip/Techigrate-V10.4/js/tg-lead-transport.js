/*
 * TECHIGRATE — LEAD TRANSPORT V3
 *
 * Sends a lead to the Google Apps Script backend with a native form POST through a hidden
 * iframe (no CORS problems), then waits for the backend's confirmation message so the
 * website knows whether the lead was really saved.
 *
 * Endpoint: read from js/site-config.js (window.TECHIGRATE_SITE.appsScriptUrl) — the one
 * place it is configured. It can be overridden per call with options.endpoint (used by lead-test.html).
 *
 * Usage:
 *   <script src="js/site-config.js"></script>
 *   <script src="js/tg-lead-transport.js" defer></script>
 *
 *   TGLeadTransport.postLead({ name, email, message, phone, company, service, budget, website })
 *     .then(function (r) { r.ok, r.confirmed, r.id, r.error });
 *
 * Result:
 *   { ok: true,  confirmed: true,  id }            saved — the backend said so
 *   { ok: true,  confirmed: false }                sent, but no confirmation arrived in time
 *   { ok: false, confirmed: true,  error }         the backend refused it (validation, rate limit...)
 *   rejects with Error                             the endpoint is not configured
 */
(function () {
  'use strict';

  var ACK_SOURCE = 'techigrate-backend';
  var DEFAULT_TIMEOUT = 9000;

  function configuredEndpoint(options) {
    var site = window.TECHIGRATE_SITE || {};
    return (options && options.endpoint) || site.appsScriptUrl || '';
  }

  function isEndpoint(url) {
    return typeof url === 'string' && /^https:\/\/script\.google(usercontent)?\.com\/.*\/exec(\?.*)?$/.test(url);
  }

  function makeRequestId() {
    try {
      if (window.crypto && crypto.randomUUID) return 'lead_' + crypto.randomUUID();
    } catch (_) {}
    return 'lead_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 10);
  }

  function makeHiddenFrame(name) {
    var frame = document.createElement('iframe');
    frame.name = name;
    frame.id = name;
    frame.title = 'Techigrate form delivery';
    frame.setAttribute('aria-hidden', 'true');
    frame.tabIndex = -1;
    frame.style.cssText = 'position:fixed;width:1px;height:1px;border:0;opacity:0;pointer-events:none;left:-9999px;top:0';
    document.body.appendChild(frame);
    return frame;
  }

  function postLead(fields, options) {
    options = options || {};
    var endpoint = configuredEndpoint(options);

    if (!isEndpoint(endpoint)) {
      return Promise.reject(new Error('The Apps Script Web App URL is not configured (js/site-config.js).'));
    }

    var requestId = makeRequestId();
    var timeout = options.timeoutMs || (window.TECHIGRATE_SITE || {}).leadTimeoutMs || DEFAULT_TIMEOUT;

    return new Promise(function (resolve) {
      var frame = makeHiddenFrame('tgLeadFrame_' + requestId);
      var form = document.createElement('form');
      var finished = false;
      var timer = 0;

      function finish(result) {
        if (finished) return;
        finished = true;
        window.clearTimeout(timer);
        window.removeEventListener('message', onMessage);
        window.setTimeout(function () {
          if (form.parentNode) form.parentNode.removeChild(form);
          if (frame.parentNode) frame.parentNode.removeChild(frame);
        }, 400);
        resolve(result);
      }

      function onMessage(event) {
        var data = event && event.data;
        if (!data || typeof data !== 'object') return;
        if (data.source !== ACK_SOURCE || data.requestId !== requestId) return;
        if (data.ok) finish({ ok: true, confirmed: true, id: data.id || '' });
        else finish({ ok: false, confirmed: true, error: data.error || 'The message could not be saved.' });
      }

      window.addEventListener('message', onMessage);

      form.method = 'POST';
      form.action = endpoint;
      form.target = frame.name;
      form.acceptCharset = 'UTF-8';
      form.style.display = 'none';

      var payload = {};
      Object.keys(fields || {}).forEach(function (k) { payload[k] = fields[k]; });
      payload.action = 'lead';
      payload.transport = 'frame';
      payload.requestId = requestId;
      payload.source = payload.source || window.location.href;

      Object.keys(payload).forEach(function (key) {
        var input = document.createElement('input');
        input.type = 'hidden';
        input.name = key;
        input.value = payload[key] == null ? '' : String(payload[key]);
        form.appendChild(input);
      });

      document.body.appendChild(form);

      // Sent, but no confirmation came back (very old deployment, blocked third-party frames...).
      timer = window.setTimeout(function () {
        finish({ ok: true, confirmed: false });
      }, timeout);

      try {
        form.submit();
      } catch (err) {
        finish({ ok: false, confirmed: false, error: 'The message could not be sent. Please try again.' });
      }
    });
  }

  window.TGLeadTransport = { postLead: postLead, isEndpoint: isEndpoint };
})();
