/* ==========================================================================
   ABOUT — staggers the timeline rows so they settle in one after another
   instead of all at once (global.js still handles the actual reveal).
   ========================================================================== */

(function () {
  'use strict';

  document.querySelectorAll('.timeline-row[data-reveal]').forEach((row, i) => {
    row.style.transitionDelay = `${i * 90}ms`;
  });
})();
