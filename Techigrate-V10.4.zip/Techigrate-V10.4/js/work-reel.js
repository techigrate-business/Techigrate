/* V10.3 — animated project reel (auto-cycling 3D browser stack, pointer tilt) */
(function(){
  'use strict';
  var root=document.querySelector('[data-reel]'); if(!root) return;
  var cards=[].slice.call(root.querySelectorAll('.tg-reel-card'));
  var bars=[].slice.call(root.querySelectorAll('[data-reel-bar]'));
  var label=root.querySelector('[data-reel-label]');
  var rig=root.querySelector('.tg-reel-rig');
  var names=cards.map(function(c){return c.getAttribute('data-name');});
  var MS=3600, cur=0, timer=null;
  var reduce=window.matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches;
  root.style.setProperty('--reel-ms',MS+'ms');
  function show(i){
    cur=(i+cards.length)%cards.length;
    cards.forEach(function(c,k){
      c.classList.remove('is-active','is-next','is-prev');
      if(k===cur)c.classList.add('is-active');
      else if(k===(cur+1)%cards.length)c.classList.add('is-next');
      else c.classList.add('is-prev');
    });
    bars.forEach(function(b,k){b.classList.remove('is-on');if(k===cur){void b.offsetWidth;b.classList.add('is-on');}});
    if(label)label.textContent=String(cur+1).padStart(2,'0')+' · '+names[cur];
  }
  function start(){ if(reduce)return; stop(); timer=setInterval(function(){show(cur+1);},MS); }
  function stop(){ if(timer){clearInterval(timer);timer=null;} }
  bars.forEach(function(b,k){b.addEventListener('click',function(){show(k);start();});});
  cards.forEach(function(c,k){c.addEventListener('click',function(){if(k!==cur){show(k);start();}});});
  root.addEventListener('pointermove',function(e){
    var r=root.getBoundingClientRect();
    var x=(e.clientX-r.left)/r.width-.5, y=(e.clientY-r.top)/r.height-.5;
    rig.style.setProperty('--ry',(x*8).toFixed(2)+'deg');
    rig.style.setProperty('--rx',(-y*6).toFixed(2)+'deg');
  });
  root.addEventListener('pointerleave',function(){rig.style.setProperty('--ry','0deg');rig.style.setProperty('--rx','0deg');});
  if('IntersectionObserver' in window){
    new IntersectionObserver(function(es){es.forEach(function(e){e.isIntersecting?start():stop();});},{threshold:.2}).observe(root);
  } else start();
  show(0);
})();
