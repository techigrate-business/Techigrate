/*
  TECHIGRATE V6.2 — LUXURY NAVIGATION EXPERIENCE
  ------------------------------------------------
  Keeps the existing markup and branding, but centralises navigation behavior:
  - compact scroll morph / Dynamic Island expansion
  - cursor-reactive surface light (inside the glass, never a rotating halo)
  - magnetic micro-movement
  - active navigation indicator
  - desktop inline command/search mode + mobile fallback
  - smart announcements panel
  - advanced theme-toggle polish hooks
  - restrained micro sound feedback
*/
(function(){
  'use strict';

  const header = document.querySelector('.site-header.tg-luxury-nav');
  if(!header) return;
  const dock = header.querySelector('[data-nav-dock]');
  const full = header.querySelector('[data-nav-full]');
  const island = header.querySelector('[data-island-face]');
  const mobileToggle = header.querySelector('[data-nav-toggle]');
  const mobilePanel = header.querySelector('.mobile-panel');
  const notificationButton = header.querySelector('[data-nav-notification]');
  const notificationPanel = header.querySelector('[data-nav-notification-panel]');
  const notificationList = header.querySelector('[data-nav-notification-list]');
  const notificationClose = notificationPanel?.querySelector('[data-nav-notification-close]');
  const atmosphere = document.querySelector('[data-nav-atmosphere]');
  const reduceQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
  const coarseQuery = window.matchMedia('(pointer: coarse)');
  const finePointer = window.matchMedia('(pointer:fine)');
  const prefersReduced = () => reduceQuery.matches;
  const isCompactDevice = () => coarseQuery.matches || window.innerWidth <= 900;
  const clamp = (v,a,b) => Math.max(a, Math.min(b,v));

  let lastY = window.scrollY || 0;
  let targetMorph = 0;
  let currentMorph = 0;
  let fullDockWidth = 0;
  let fullDockHeight = 64;
  let raf = 0;
  let islandHoverTimer = 0;
  let searchShell = null;
  let searchInput = null;
  let searchResults = null;
  let searchItems = [];
  let activeSearchIndex = -1;
  let audioCtx = null;
  let lastHoverTone = 0;

  /* ---------------------------------------------------------------------- */
  /* Scroll morph / Dynamic Island                                          */
  /* ---------------------------------------------------------------------- */
  const closeIslandStates = () => {
    header.classList.remove('is-hovered','is-pinned');
    island?.setAttribute('aria-expanded','false');
  };

  /* Read the expanded dock once so its responsive width can be morphed
     continuously into the compact island instead of snapping at a threshold. */
  const refreshDockMetrics = () => {
    if(!dock) return;
    const wasIsland = header.classList.contains('is-island');
    if(wasIsland) header.classList.remove('is-island');
    const rect = dock.getBoundingClientRect();
    if(rect.width > 0) fullDockWidth = rect.width;
    if(rect.height > 0) fullDockHeight = rect.height;
    if(wasIsland) header.classList.add('is-island');
  };
  refreshDockMetrics();

  const smoothstep = (edge0, edge1, value) => {
    const t = clamp((value - edge0) / Math.max(.0001, edge1 - edge0), 0, 1);
    return t * t * (3 - 2 * t);
  };

  const computeMorphTarget = () => {
    if(isCompactDevice() || mobilePanel?.classList.contains('is-open')) return 0;
    if(header.classList.contains('tg-nav-searching')) return 0;
    /* V09.1: on the home page the flat bar -> floating pill hand-off owns the first stretch of scroll, then the island morph */
    const morphStart = document.body.classList.contains('tg-scene-nav') ? 260 : 18;
    return clamp((lastY - morphStart) / 145, 0, 1);
  };

  const renderMorph = () => {
    raf = 0;
    targetMorph = computeMorphTarget();
    const blend = prefersReduced() ? 1 : 0.16;
    currentMorph += (targetMorph - currentMorph) * blend;
    if(Math.abs(targetMorph - currentMorph) < 0.001) currentMorph = targetMorph;

    const m = currentMorph;
    const shellWidth = fullDockWidth > 0 ? fullDockWidth - (fullDockWidth - 248) * m : 248;
    const shellHeight = fullDockHeight - (fullDockHeight - 50) * smoothstep(.04, 1, m);
    const fullExit = smoothstep(.50, .98, m);
    const islandEnter = smoothstep(.66, .98, m);
    const contentScale = 1 - (.055 * fullExit);
    const contentLift = -3 * fullExit;
    const contentBlur = 5.5 * fullExit;

    dock?.style.setProperty('--nav-morph', m.toFixed(4));
    dock?.style.setProperty('--tg-dock-width', `${shellWidth.toFixed(2)}px`);
    dock?.style.setProperty('--tg-dock-height', `${shellHeight.toFixed(2)}px`);
    dock?.style.setProperty('--tg-full-opacity', (1 - fullExit).toFixed(4));
    dock?.style.setProperty('--tg-full-scale', contentScale.toFixed(4));
    dock?.style.setProperty('--tg-full-lift', `${contentLift.toFixed(2)}px`);
    dock?.style.setProperty('--tg-full-blur', `${contentBlur.toFixed(2)}px`);
    dock?.style.setProperty('--tg-island-opacity', islandEnter.toFixed(4));
    const morphGlow = 0.14 + m * .42;
    dock?.style.setProperty('--tg-island-scale', (0.94 + islandEnter * .06).toFixed(4));
    dock?.style.setProperty('--tg-morph-glow', morphGlow.toFixed(4));
    dock?.style.setProperty('--tg-shadow-y', `${(18 + morphGlow * 7).toFixed(2)}px`);
    dock?.style.setProperty('--tg-shadow-blur', `${(38 + morphGlow * 28).toFixed(2)}px`);
    dock?.style.setProperty('--tg-shadow-alpha', (0.16 - morphGlow * .07).toFixed(4));
    dock?.style.setProperty('--tg-shadow-spread', `${(.7 + morphGlow * .8).toFixed(2)}px`);
    dock?.style.setProperty('--tg-highlight-alpha', (0.98 - morphGlow * .10).toFixed(4));
    dock?.style.setProperty('--tg-inner-shadow-alpha', (0.08 - morphGlow * .03).toFixed(4));
    dock?.style.setProperty('--tg-border-alpha', (0.10 + morphGlow * .08).toFixed(4));
    dock?.style.setProperty('--tg-aura-scale-x', (1 - m * .38).toFixed(4));
    dock?.style.setProperty('--tg-aura-scale-y', (1 + m * .45).toFixed(4));
    dock?.style.setProperty('--tg-aura-blur', `${(12 + m * 10).toFixed(2)}px`);
    dock?.style.setProperty('--tg-island-blur', `${((1 - islandEnter) * 2.5).toFixed(2)}px`);
    dock?.style.setProperty('--tg-island-ring-scale', (0.82 + islandEnter * .18).toFixed(4));
    dock?.style.setProperty('--tg-island-ring-opacity', (0.28 + islandEnter * .72).toFixed(4));

    /* The class now flips only near the end of the morph. Width/height and
       content visibility are continuous, so the dock never "jumps" into the
       island state halfway through the animation. */
    const islandMode = currentMorph > 0.82;
    header.classList.toggle('is-island', islandMode);

    if(!islandMode) closeIslandStates();
    island?.setAttribute('aria-expanded', String(header.classList.contains('is-pinned')));

    if(Math.abs(targetMorph - currentMorph) > 0.001 && !document.hidden){
      raf = requestAnimationFrame(renderMorph);
    }
  };

  const scheduleMorph = () => { if(!raf) raf = requestAnimationFrame(renderMorph); };
  const onScroll = () => { lastY = window.scrollY || window.pageYOffset || 0; scheduleMorph(); };
  window.addEventListener('scroll', onScroll, {passive:true});
  window.addEventListener('resize', () => {
    refreshDockMetrics();
    scheduleMorph();
    removeOrphanTopClose();
  }, {passive:true});

  /* V6.2's actual close buttons all live inside their respective overlays/cards.
     A stray top-right × control has appeared in some preview wrappers, so
     remove only that exact shape when it is injected at the document level. */
  let orphanCloseScanRaf = 0;
  const removeOrphanTopClose = () => {
    if(orphanCloseScanRaf) return;
    orphanCloseScanRaf = requestAnimationFrame(() => {
      orphanCloseScanRaf = 0;
      const protectedZones = '.hero-feature-card,.project-modal,.nav-search,.tg-nav-notification-panel,.site-header';
      document.querySelectorAll('button,a,[role="button"]').forEach((el) => {
        if(String(el.textContent || '').trim() !== '×') return;
        if(el.closest(protectedZones)) return;
        const r = el.getBoundingClientRect();
        const nearTop = r.top >= -6 && r.top < 90;
        const nearRight = r.right > window.innerWidth - 72;
        const compact = r.width <= 72 && r.height <= 72;
        if(nearTop && nearRight && compact) el.remove();
      });
    });
  };
  removeOrphanTopClose();
  const closeObserver = new MutationObserver(removeOrphanTopClose);
  closeObserver.observe(document.body, {childList:true, subtree:true});

  dock?.addEventListener('pointerenter', (e) => {
    if(isCompactDevice() || (e.pointerType && e.pointerType !== 'mouse')) return;
    if(!header.classList.contains('is-island')) return;
    clearTimeout(islandHoverTimer);
    header.classList.add('is-hovered');
    dock.style.setProperty('--nav-morph','0');
  }, {passive:true});

  dock?.addEventListener('pointerleave', () => {
    clearTimeout(islandHoverTimer);
    if(header.classList.contains('is-pinned')) return;
    islandHoverTimer = setTimeout(() => header.classList.remove('is-hovered'), 120);
  }, {passive:true});

  island?.addEventListener('click', () => {
    if(!header.classList.contains('is-island')) return;
    header.classList.toggle('is-pinned');
    header.classList.remove('is-hovered');
    island.setAttribute('aria-expanded', String(header.classList.contains('is-pinned')));
  });

  /* ---------------------------------------------------------------------- */
  /* Cursor-reactive lighting — IN the navbar surface, not around it.       */
  /* ---------------------------------------------------------------------- */
  if(finePointer.matches && dock){
    dock.addEventListener('pointermove', (e) => {
      const r = dock.getBoundingClientRect();
      dock.style.setProperty('--tg-cursor-x', `${e.clientX - r.left}px`);
      dock.style.setProperty('--tg-cursor-y', `${e.clientY - r.top}px`);
      dock.style.setProperty('--tg-cursor-alpha', '1');
    }, {passive:true});
    dock.addEventListener('pointerleave', () => {
      dock.style.setProperty('--tg-cursor-alpha', '0');
    }, {passive:true});
  }

  /* ---------------------------------------------------------------------- */
  /* Magnetic interaction — intentionally tiny, capped, and stable.         */
  /* ---------------------------------------------------------------------- */
  const magneticElements = header.querySelectorAll(
    '.tg-nav-mark, .nav-item[data-nav-key], .tg-nav-menu-trigger, .tg-nav-search-button, .tg-nav-notification, .nav-project-btn'
  );

  if(finePointer.matches && !prefersReduced()){
    magneticElements.forEach((el) => {
      let moveRaf = 0;
      let pendingX = 0;
      let pendingY = 0;
      const strength = el.classList.contains('nav-project-btn') ? 3.2 : el.classList.contains('tg-nav-mark') ? 2.6 : 2.1;

      const apply = () => {
        moveRaf = 0;
        el.style.setProperty('--tg-mx', `${pendingX.toFixed(2)}px`);
        el.style.setProperty('--tg-my', `${pendingY.toFixed(2)}px`);
      };

      el.addEventListener('pointermove', (e) => {
        const r = el.getBoundingClientRect();
        const nx = clamp((e.clientX - (r.left + r.width/2)) / Math.max(1, r.width/2), -1, 1);
        const ny = clamp((e.clientY - (r.top + r.height/2)) / Math.max(1, r.height/2), -1, 1);
        pendingX = nx * strength;
        pendingY = ny * strength * 0.7;
        if(!moveRaf) moveRaf = requestAnimationFrame(apply);
      }, {passive:true});

      el.addEventListener('pointerleave', () => {
        el.style.setProperty('--tg-mx', '0px');
        el.style.setProperty('--tg-my', '0px');
      }, {passive:true});
    });
  }

  /* ---------------------------------------------------------------------- */
  /* Desktop menus                                                           */
  /* ---------------------------------------------------------------------- */
  const menus = header.querySelectorAll('.tg-nav-menu');

  const positionAtmosphere = (menu) => {
    if(!atmosphere || !menu) return;
    const dropdown = menu.querySelector('.tg-nav-dropdown');
    if(!dropdown) return;
    const rect = dropdown.getBoundingClientRect();
    const x = clamp(rect.left + rect.width * .5, 110, Math.max(110, window.innerWidth - 110));
    const y = clamp(rect.top + Math.min(rect.height * .22, 105), 84, Math.max(84, window.innerHeight * .45));
    atmosphere.style.setProperty('--tg-atmo-x', `${x}px`);
    atmosphere.style.setProperty('--tg-atmo-y', `${y}px`);
  };

  const setAtmosphere = (open, menu = null) => {
    if(!atmosphere) return;
    if(open && menu){
      positionAtmosphere(menu);
      document.documentElement.classList.add('tg-nav-focus');
    }else{
      document.documentElement.classList.remove('tg-nav-focus');
    }
  };

  const closeAllMenus = () => {
    menus.forEach((menu) => {
      menu.classList.remove('is-open','tg-nav-preview-visible');
      menu.querySelector('.tg-nav-menu-trigger')?.setAttribute('aria-expanded','false');
    });
    setAtmosphere(false);
  };

  menus.forEach((menu) => {
    const trigger = menu.querySelector('.tg-nav-menu-trigger');
    const preview = menu.querySelector('[data-nav-hover-preview]');
    const items = menu.querySelectorAll('.tg-nav-dropdown-item[data-preview-title]');

    const open = () => {
      if(isCompactDevice()) return;
      menus.forEach(other => {
        if(other !== menu){
          other.classList.remove('is-open','tg-nav-preview-visible');
          other.querySelector('.tg-nav-menu-trigger')?.setAttribute('aria-expanded','false');
        }
      });
      menu.classList.add('is-open');
      trigger?.setAttribute('aria-expanded','true');
      setAtmosphere(true, menu);
    };

    const close = () => {
      if(menu.matches(':focus-within')) return;
      menu.classList.remove('is-open','tg-nav-preview-visible');
      trigger?.setAttribute('aria-expanded','false');
      if(!header.querySelector('.tg-nav-menu.is-open')) setAtmosphere(false);
    };

    menu.addEventListener('mouseenter', () => open(), {passive:true});
    menu.addEventListener('mouseleave', close, {passive:true});
    trigger?.addEventListener('focus', open);
    trigger?.addEventListener('click', (e) => {
      if(trigger.tagName === 'BUTTON' || isCompactDevice()){
        e.preventDefault();
        menu.classList.contains('is-open') ? closeAllMenus() : open();
      }
    });

    menu.addEventListener('keydown', (e) => {
      if(e.key === 'Escape'){
        e.preventDefault();
        closeAllMenus();
        trigger?.focus();
      }
    });

    items.forEach((item) => {
      item.addEventListener('mouseenter', () => {
        if(!preview) return;
        preview.querySelector('[data-preview-title]')?.replaceChildren(document.createTextNode(item.dataset.previewTitle || ''));
        preview.querySelector('[data-preview-copy]')?.replaceChildren(document.createTextNode(item.dataset.previewCopy || ''));
        preview.querySelector('.tg-nav-hover-preview__tag')?.replaceChildren(document.createTextNode(item.dataset.previewTag || 'Explore'));
        menu.classList.add('tg-nav-preview-visible');
      }, {passive:true});
      item.addEventListener('focusin', () => {
        if(!preview) return;
        preview.querySelector('[data-preview-title]')?.replaceChildren(document.createTextNode(item.dataset.previewTitle || ''));
        preview.querySelector('[data-preview-copy]')?.replaceChildren(document.createTextNode(item.dataset.previewCopy || ''));
        preview.querySelector('.tg-nav-hover-preview__tag')?.replaceChildren(document.createTextNode(item.dataset.previewTag || 'Explore'));
        menu.classList.add('tg-nav-preview-visible');
      });
    });
  });

  document.addEventListener('pointerdown', (e) => {
    if(!header.contains(e.target)) closeAllMenus();
  }, {passive:true});

  window.addEventListener('resize', () => {
    const openMenu = header.querySelector('.tg-nav-menu.is-open');
    if(openMenu && !isCompactDevice()) positionAtmosphere(openMenu);
    else if(isCompactDevice()) setAtmosphere(false);
  }, {passive:true});

  /* ---------------------------------------------------------------------- */
  /* Active page indicator                                                    */
  /* ---------------------------------------------------------------------- */
  const currentFile = (location.pathname.split('/').pop() || 'index.html').toLowerCase();
  const normalize = (href) => {
    try { return (new URL(href, location.href).pathname.split('/').pop() || 'index.html').toLowerCase(); }
    catch { return String(href || '').split('/').pop().toLowerCase(); }
  };
  header.querySelectorAll('.nav-item[data-nav-key], .mobile-nav-link').forEach(link => {
    link.toggleAttribute('aria-current', normalize(link.getAttribute('href')) === currentFile);
  });

  /* ---------------------------------------------------------------------- */
  /* Micro sound feedback                                                     */
  /* ---------------------------------------------------------------------- */
  const soundEnabled = () => localStorage.getItem('techigrate-nav-sound') !== 'off';
  const tone = (freq=680, duration=.025, volume=.012, type='sine') => {
    if(prefersReduced() || !soundEnabled()) return;
    try{
      audioCtx ||= new (window.AudioContext || window.webkitAudioContext)();
      if(audioCtx.state === 'suspended') audioCtx.resume();
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      const now = audioCtx.currentTime;
      osc.type = type;
      osc.frequency.value = freq;
      gain.gain.setValueAtTime(.0001, now);
      gain.gain.exponentialRampToValueAtTime(volume, now + .005);
      gain.gain.exponentialRampToValueAtTime(.0001, now + duration);
      osc.connect(gain).connect(audioCtx.destination);
      osc.start(now); osc.stop(now + duration + .01);
    }catch{}
  };
  header.querySelectorAll('.nav-item[href], .nav-project-btn').forEach(el => el.addEventListener('click', () => tone(520,.026,.011,'sine')));
  header.querySelectorAll('.tg-nav-menu-trigger').forEach(el => el.addEventListener('click', () => tone(620,.032,.012,'triangle')));
  header.querySelectorAll('.nav-icon-button, .tg-nav-search-button, .tg-nav-notification').forEach(el => el.addEventListener('click', () => tone(710,.024,.010,'sine')));
  header.querySelectorAll('.tg-nav-dropdown-item').forEach(el => el.addEventListener('mouseenter', () => {
    const now = performance.now();
    if(now - lastHoverTone < 180) return;
    lastHoverTone = now;
    tone(760,.016,.007,'sine');
  }, {passive:true}));

  /* ---------------------------------------------------------------------- */
  /* Announcements                                                           */
  /* ---------------------------------------------------------------------- */
  let announcements = [];
  window.TGSetAnnouncements = (items) => {
    announcements = Array.isArray(items) ? items.map(item => ({
      title: item?.Title || item?.title || '',
      copy: item?.Message || item?.copy || '',
      href: item?.['Link URL'] || item?.href || '#'
    })) : [];
    const dot = notificationButton?.querySelector('.tg-nav-notification__dot');
    if(dot) dot.hidden = !announcements.length;
    renderAnnouncements();
  };

  const renderAnnouncements = () => {
    if(!notificationList) return;
    notificationList.innerHTML = '';
    announcements.forEach(item => {
      const el = document.createElement('a');
      el.className = 'tg-nav-notification-item';
      el.href = item.href || '#';
      el.innerHTML = `<span class="tg-nav-notification-item__dot" aria-hidden="true"></span><span><strong></strong><small></small></span><span class="tg-nav-notification-item__arrow" aria-hidden="true">↗</span>`;
      el.querySelector('strong').textContent = item.title;
      el.querySelector('small').textContent = item.copy;
      notificationList.appendChild(el);
    });
  };

  const setAnnouncementOpen = (open) => {
    if(!notificationButton || !notificationPanel) return;
    notificationPanel.classList.toggle('is-open', open);
    notificationPanel.setAttribute('aria-hidden', String(!open));
    notificationButton.setAttribute('aria-expanded', String(open));
  };

  if(notificationButton && notificationPanel){
    notificationPanel.hidden = false;
    notificationPanel.setAttribute('aria-hidden','true');
    notificationButton.addEventListener('click', () => {
      const open = !notificationPanel.classList.contains('is-open');
      closeAllMenus();
      setAnnouncementOpen(open);
      tone(open ? 680 : 500, .03, .012, 'triangle');
    });
    notificationClose?.addEventListener('click', () => setAnnouncementOpen(false));
    document.addEventListener('pointerdown', (e) => {
      if(!notificationPanel.classList.contains('is-open')) return;
      if(!notificationPanel.contains(e.target) && !notificationButton.contains(e.target)) setAnnouncementOpen(false);
    }, {passive:true});
  }

  document.addEventListener('keydown', (e) => {
    if(e.key === 'Escape'){
      closeAllMenus();
      setAnnouncementOpen(false);
      closeSearch();
      header.classList.remove('is-hovered','is-pinned');
    }
  });

  /* ---------------------------------------------------------------------- */
  /* Command / Search mode — desktop inline, mobile uses existing overlay.   */
  /* ---------------------------------------------------------------------- */
  const overlay = document.querySelector('[data-nav-search-overlay]');
  const overlayInput = overlay?.querySelector('[data-nav-search-input]');
  const overlayResults = overlay?.querySelector('[data-nav-search-results]');
  const searchButton = header.querySelector('[data-nav-search]');

  const searchData = [
    ['Home','Homepage and latest work','index.html'],
    ['Services','Web, apps, AI and UI/UX','services.html'],
    ['Web Development','Modern & scalable builds','services.html#web-development'],
    ['AI Solutions','Applied intelligence and automation','services.html#ai-solutions'],
    ['Work','Public showcase and case studies','work.html'],
    ['Technology','Stack, systems and experiments','technology.html'],
    ['About','How Techigrate works','about.html'],
    ['Contact','Start a project','contact.html']
  ];

  const drawSearchResults = (container, query) => {
    if(!container) return;
    const needle = String(query || '').trim().toLowerCase();
    const filtered = searchData.filter(([title, copy]) => (title+' '+copy).toLowerCase().includes(needle));
    container.innerHTML = filtered.slice(0,7).map((item,i) => `<a class="tg-inline-search-result" href="${item[2]}"><span class="tg-inline-search-index">${String(i+1).padStart(2,'0')}</span><span><strong>${item[0]}</strong><small>${item[1]}</small></span><span>↗</span></a>`).join('') || '<div class="tg-inline-search-empty">No matching Techigrate destination.</div>';
  };

  const closeInlineSearch = () => {
    header.classList.remove('tg-nav-searching');
    if(searchShell) searchShell.remove();
    searchShell = null; searchInput = null; searchResults = null; searchItems = []; activeSearchIndex = -1;
    scheduleMorph();
  };

  function closeSearch(){
    closeInlineSearch();
    if(overlay && window.innerWidth <= 900){ overlay.hidden = true; document.body.style.overflow=''; }
  }

  const openSearch = () => {
    closeAllMenus();
    setAnnouncementOpen(false);
    header.classList.remove('is-island','is-hovered','is-pinned');

    if(window.innerWidth <= 900){
      if(!overlay) return;
      overlay.hidden = false;
      document.body.style.overflow = 'hidden';
      drawSearchResults(overlayResults, '');
      setTimeout(() => overlayInput?.focus(), 18);
      return;
    }

    if(searchShell) return;
    header.classList.add('tg-nav-searching');
    searchShell = document.createElement('div');
    searchShell.className = 'tg-inline-search';
    searchShell.innerHTML = `<span class="tg-inline-search-icon" aria-hidden="true">⌕</span><input type="search" aria-label="Search Techigrate" placeholder="Search Techigrate…" autocomplete="off"><button type="button" class="tg-inline-search-close" aria-label="Close search">Esc</button><div class="tg-inline-search-results" role="listbox"></div>`;
    dock?.appendChild(searchShell);
    searchInput = searchShell.querySelector('input');
    searchResults = searchShell.querySelector('.tg-inline-search-results');
    drawSearchResults(searchResults,'');
    searchInput.addEventListener('input', () => { drawSearchResults(searchResults,searchInput.value); activeSearchIndex=-1; syncSearchActive(false); });
    searchInput.addEventListener('keydown', (e) => {
      searchItems = Array.from(searchResults.querySelectorAll('a'));
      if(e.key === 'Escape'){e.preventDefault();closeInlineSearch();}
      else if(e.key === 'ArrowDown'){e.preventDefault();activeSearchIndex=Math.min(searchItems.length-1,activeSearchIndex+1);syncSearchActive(true);}
      else if(e.key === 'ArrowUp'){e.preventDefault();activeSearchIndex=Math.max(0,activeSearchIndex-1);syncSearchActive(true);}
      else if(e.key === 'Enter' && activeSearchIndex>=0){e.preventDefault();searchItems[activeSearchIndex]?.click();}
    });
    searchShell.querySelector('.tg-inline-search-close')?.addEventListener('click',closeInlineSearch);
    setTimeout(() => searchInput?.focus(), 20);
    tone(640,.035,.012,'triangle');
  };

  const syncSearchActive = (sound) => {
    searchItems.forEach((item,i)=>item.classList.toggle('is-active',i===activeSearchIndex));
    if(activeSearchIndex>=0) searchItems[activeSearchIndex]?.scrollIntoView({block:'nearest'});
    if(sound) tone(720,.016,.008,'sine');
  };

  searchButton?.addEventListener('click', openSearch);
  overlay?.querySelectorAll('[data-nav-search-close]').forEach(el => el.addEventListener('click', () => {overlay.hidden=true;document.body.style.overflow='';}));
  overlayInput?.addEventListener('input', () => drawSearchResults(overlayResults,overlayInput.value));
  overlayInput?.addEventListener('keydown', (e) => {
    if(e.key==='Escape'){e.preventDefault();closeSearch();}
    if(e.key==='Enter'){const first=overlayResults?.querySelector('a[href]');if(first){e.preventDefault();first.click();}}
  });
  document.addEventListener('keydown',(e)=>{
    if((e.ctrlKey||e.metaKey) && e.key.toLowerCase()==='k'){e.preventDefault();openSearch();}
  });

  /* Close search when any nav destination is chosen. */
  header.querySelectorAll('a[href]').forEach(a => a.addEventListener('click', () => {
    if(header.classList.contains('tg-nav-searching')) closeInlineSearch();
  }));

  /* Theme toggle feedback: the existing global handler still owns theme state. */
  header.querySelectorAll('.theme-toggle .input').forEach(input => {
    input.addEventListener('change', () => tone(input.checked ? 430 : 720, .04, .012, 'triangle'));
  });

  /* Start clean. */
  window.TGNavSearch = openSearch;
  lastY = window.scrollY || 0;
  scheduleMorph();
})();
