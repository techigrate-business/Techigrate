/* ==========================================================================
   TECHNOLOGY — subtle pointer-driven tilt on the isometric layer stack
   ========================================================================== */

(function () {
  'use strict';

  const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const isTouch = window.matchMedia('(hover: none)').matches;
  const scene = document.querySelector('.stack-scene');
  const stage = document.querySelector('.stack-diagram');
  if (!scene || !stage || prefersReducedMotion || isTouch) return;

  stage.addEventListener('pointermove', (e) => {
    const rect = stage.getBoundingClientRect();
    const px = (e.clientX - rect.left) / rect.width - 0.5;
    scene.style.transform = `rotateX(34deg) rotateZ(${(-2 + px * 6).toFixed(2)}deg)`;
  });
  stage.addEventListener('pointerleave', () => {
    scene.style.transform = 'rotateX(34deg) rotateZ(-2deg)';
  });
})();
