/* TECHIGRATE V09.6 — aurora in-view toggle (IntersectionObserver only). */
(function () {
  'use strict';
  if (!('IntersectionObserver' in window)) return;
  var d = document.documentElement;
  var io = new IntersectionObserver(function (es) {
    es.forEach(function (e) { e.target.classList.toggle('tg-in-view', e.isIntersecting); });
  }, { rootMargin: '10% 0px' });
  [].forEach.call(document.querySelectorAll('#what-we-build,.v8-end,.work-preview-grid'), function (el) {
    io.observe(el.closest('section') || el);
  });
  document.addEventListener('visibilitychange', function () { d.classList.toggle('tg-hidden', document.hidden); });
})();
