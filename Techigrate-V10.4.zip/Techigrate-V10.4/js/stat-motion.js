/* ==========================================================================
   TECHIGRATE V09.2 — stats count-up (V09.7: odometer reels)
   When the "By the numbers" strip scrolls into view each figure counts up from
   0 to its value (decimals, prefix/suffix and thousands separators preserved),
   staggered left to right, with an accent bar that fills as the number climbs.
   Plays once per page view. Skipped under prefers-reduced-motion.
   ========================================================================== */
(function () {
  'use strict';
  var strip = document.querySelector('.stats-strip');
  if (!strip || window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;

  var items = [].slice.call(strip.querySelectorAll('.stat')).map(function (st) {
    var v = st.querySelector('.stat-value');
    if (!v) return null;
    var txt = v.textContent.trim();
    var m = /^([^\d-]*)(-?[\d,]*\.?\d+)(.*)$/.exec(txt);
    if (!m) return null;
    var raw = m[2].replace(/,/g, '');
    return { st: st, v: v, pre: m[1], suf: m[3], to: parseFloat(raw), dec: (raw.split('.')[1] || '').length, comma: m[2].indexOf(',') > -1, final: txt };
  }).filter(Boolean);
  if (!items.length || !('IntersectionObserver' in window)) return;

  function fmt(it, val) {
    var s = val.toFixed(it.dec);
    if (it.comma) s = Number(s).toLocaleString('en-US', { minimumFractionDigits: it.dec, maximumFractionDigits: it.dec });
    return it.pre + s + it.suf;
  }
  var ease = function (t) { return t >= 1 ? 1 : 1 - Math.pow(2, -10 * t); };      // ease-out expo

  // V09.7 odometer: every digit becomes a reel (0-9 stacked twice); other characters stay as text.
  // Screen readers keep the real value through aria-label on .stat-value.
  items.forEach(function (it) {
    it.v.setAttribute('aria-label', it.final);
    it.v.textContent = '';
    it.reels = [];
    var frag = document.createDocumentFragment();
    it.final.split('').forEach(function (ch) {
      var wrap = document.createElement('span');
      wrap.setAttribute('aria-hidden', 'true');
      if (/\d/.test(ch)) {
        wrap.className = 'od-d';
        var reel = document.createElement('span');
        reel.className = 'od-r';
        var html = '';
        for (var k = 0; k < 20; k++) html += '<i>' + (k % 10) + '</i>';
        reel.innerHTML = html;
        wrap.appendChild(reel);
        it.reels.push({ el: reel, n: parseInt(ch, 10) });
      } else {
        wrap.className = 'od-c';
        wrap.textContent = ch === ' ' ? '\u00a0' : ch;
      }
      frag.appendChild(wrap);
    });
    it.v.appendChild(frag);
    it.v.style.setProperty('--p', 0);
  });
  strip.classList.add('js-stat');

  function run(it, delay) {
    var DUR = 2000;
    setTimeout(function () {
      it.st.classList.add('is-counting');
      // roll the reels: one full turn plus the digit, left digits settle first, right ones last
      it.reels.forEach(function (r, i) {
        r.el.style.setProperty('--od-t', (1500 + i * 170) + 'ms');
        r.el.style.setProperty('--od-delay', (i * 60) + 'ms');
        r.el.style.setProperty('--n', r.n + 10);
      });
      // accent bar keeps its own eased fill
      var t0 = performance.now();
      (function step(now) {
        var p = Math.min(1, (now - t0) / DUR), e = ease(p);
        it.v.style.setProperty('--p', e.toFixed(4));
        if (p < 1) requestAnimationFrame(step);
        else { it.v.style.setProperty('--p', 1); it.st.classList.add('is-done'); }
      })(t0);
    }, delay);
  }

  var io = new IntersectionObserver(function (es) {
    if (!es.some(function (e) { return e.isIntersecting; })) return;
    io.disconnect();
    items.forEach(function (it, i) { run(it, 120 + i * 150); });
  }, { threshold: 0.35, rootMargin: '0px 0px -6% 0px' });
  io.observe(strip);
})();
