/* ==========================================================================
   TECHIGRATE — MOBILE LAYER (V10.3)
   Only does anything at <= 900px (the site's phone/tablet breakpoint).
   - Adds a dimmed backdrop behind the menu sheet and closes the sheet when
     the backdrop is tapped, when a link inside it is used, or on swipe-down.
   - The "More" button in the bottom navigation stays the open/close toggle
     (wired in js/global.js).
   ========================================================================== */
(function () {
  'use strict';
  var mq = window.matchMedia('(max-width: 900px)');
  var panel = document.querySelector('.mobile-panel');
  var more = document.querySelector('[data-nav-more]');
  if (!panel || !more) return;

  var scrim = document.createElement('div');
  scrim.className = 'tg-sheet-scrim';
  scrim.setAttribute('aria-hidden', 'true');
  /* Only attached while the phone layout is active and the sheet is open, so
     desktop never gets an extra element in the DOM. */

  function isOpen() { return panel.classList.contains('is-open'); }
  function sync() {
    var on = mq.matches && isOpen();
    if (on && !scrim.parentNode) { document.body.appendChild(scrim); void scrim.offsetWidth; }
    scrim.classList.toggle('is-on', on);
    if (!on && scrim.parentNode && !mq.matches) scrim.remove();
  }
  function close() { if (isOpen() && mq.matches) more.click(); }

  /* Follow the panel's own open/close state instead of re-implementing it. */
  new MutationObserver(sync).observe(panel, { attributes: true, attributeFilter: ['class'] });
  mq.addEventListener ? mq.addEventListener('change', sync) : mq.addListener(sync);

  scrim.addEventListener('click', close);

  /* Swipe down on the sheet's top edge to dismiss. */
  var startY = null;
  panel.addEventListener('touchstart', function (e) {
    startY = (panel.scrollTop <= 0 && e.touches.length === 1) ? e.touches[0].clientY : null;
  }, { passive: true });
  panel.addEventListener('touchend', function (e) {
    if (startY === null) return;
    var dy = e.changedTouches[0].clientY - startY;
    startY = null;
    if (dy > 70) close();
  }, { passive: true });
})();
