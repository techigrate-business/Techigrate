/* Techigrate V6 — cursor trail intentionally disabled on the luxury reference build. */
(function(){
  'use strict';
  document.documentElement.classList.add('tg-performance-build');
})();
