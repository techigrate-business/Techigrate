/* ==========================================================================
   TECHIGRATE — GLOBAL BEHAVIOR
   Shared across every page: header state, mobile nav (hamburger + bottom-nav
   "More", one shared panel), scroll-reveal, footer year, pointer parallax,
   the light/dark theme toggle, the Back to Home / Back to Top floating
   control, scroll progress, magnetic tilt, and word-stagger text reveals.

   FAULT ISOLATION: each feature block below is wrapped in its own
   try/catch. These features are independent of each other (a broken
   parallax effect has nothing to do with whether the mobile menu opens),
   so one throwing shouldn't take the others down with it. This matters
   most for the reveal observer: [data-reveal] elements start at
   opacity:0 in CSS and only become visible once that block's
   IntersectionObserver runs, so if it can't reach this file at all, the
   <noscript> fallback in each page's <head> covers that case; if it
   reaches this file but throws partway through, this try/catch is what
   keeps that failure from also silently killing the header, nav, and
   theme toggle below it.
   ========================================================================== */

(function () {
  'use strict';

  const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const isTouch = window.matchMedia('(hover: none)').matches;

  /* ---- Load-in flag ----
     Two rAFs guarantee the browser has actually painted the hidden
     (opacity:0) state at least once before we flip to visible. Without
     this, on some paint schedules the class lands before first paint and
     the hero/entrance transition never gets seen — it just appears
     "finished". Every page-load transition keys off body.is-loaded, so
     this one fix benefits all of them. */
  try {
    requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        document.body.classList.add('is-loaded');
      });
    });
  } catch (err) {
    console.error('Techigrate: load-in flag failed', err);
  }

  /* ---- Smooth scroll (Lenis) ----
     Buttery, inertia-eased scrolling site-wide — the same "things feel
     alive as you move through them" quality as the drag-and-scroll
     reference this was modeled on, applied to ordinary page scrolling
     instead of a literal drag grid. Lenis wraps native scroll (not a
     fake/virtual one), so position:sticky, anchor links, and screen
     readers all keep working exactly as before.

     Progressive enhancement, same pattern as js/hero-scene.js: this only
     runs if js/vendor/lenis.min.js actually loaded. If it's blocked,
     offline, or fails for any reason, `Lenis` is just undefined and the
     page scrolls exactly as it always did — nothing else here depends on
     this block running.

     Skipped entirely under prefers-reduced-motion rather than merely
     de-tuned: motion-sensitive visitors get plain native scroll, full
     stop. (Lenis also respects that setting on its own — respectReducedMotion
     defaults to true — this is a belt-and-suspenders explicit bail so the
     library isn't even instantiated for them.)

     window.tgLenis is exposed so the two spots elsewhere on the site that
     scroll the page programmatically (the Back to Top button below, and
     js/section-nav.js's prev/next control) can hand the animation to Lenis
     too — mixing native `window.scrollTo` calls with an active Lenis
     instance is a known way to desync the two and cause a visible jump on
     the next scroll. */
  try {
    if (!prefersReducedMotion && typeof Lenis !== 'undefined') {
      window.tgLenis = new Lenis({
        autoRaf: true,
        anchors: true,
        lerp: 0.072,
        wheelMultiplier: 0.86,
        touchMultiplier: 1.02,
        syncTouch: true,
        syncTouchLerp: 0.075,
        smoothWheel: true,
        orientation: 'vertical',
        gestureOrientation: 'vertical'
      });
    }
  } catch (err) {
    console.error('Techigrate: smooth scroll failed — native scroll still works', err);
  }

  const header = document.querySelector('.site-header');
  const panel = document.querySelector('.mobile-panel');

  /* ---- Sticky header state ---- */
  try {
    if (header) {
      const setScrolled = () => {
        header.classList.toggle('is-scrolled', window.scrollY > 8);
      };
      setScrolled();
      window.addEventListener('scroll', setScrolled, { passive: true });

      /* ---- Hide on scroll down, reveal on scroll up ----
         The CSS for .is-hidden already existed; nothing was ever toggling
         it. Only engages past a small threshold (so the header doesn't
         flicker right at the top), ignores the mobile menu being open, and
         always re-shows the moment the person scrolls back up — that's the
         direction that means "I want to get back to the nav". */
      const HIDE_AFTER = 140;
      let lastY = window.scrollY;
      let ticking = false;

      const updateHeaderVisibility = () => {
        const y = window.scrollY;
        const menuOpen = panel && panel.classList.contains('is-open');
        const dynamicIslandOwnsVisibility = header.classList.contains('tg-dynamic-island');
        if (!menuOpen && !dynamicIslandOwnsVisibility) {
          if (y > lastY && y > HIDE_AFTER) {
            header.classList.add('is-hidden');
          } else if (y < lastY) {
            header.classList.remove('is-hidden');
          }
        } else if (dynamicIslandOwnsVisibility) {
          header.classList.remove('is-hidden');
        }
        lastY = y;
        ticking = false;
      };

      window.addEventListener('scroll', () => {
        if (!ticking) {
          requestAnimationFrame(updateHeaderVisibility);
          ticking = true;
        }
      }, { passive: true });
    }
  } catch (err) {
    console.error('Techigrate: header scroll state failed', err);
  }

  /* ---- Mobile nav toggle ----
     Two triggers now open the same panel: the header hamburger, and the
     "More" item in the bottom nav (added for pages/links that don't have
     their own bottom-nav icon). Explicit open/close functions (rather than
     a bare classList.toggle) manage focus — into the panel on open, trapped
     inside it while open, restored to whichever trigger was pressed on
     close — and keep both triggers' aria-expanded in sync. */
  try {
    const menuTriggers = Array.from(document.querySelectorAll('.nav-toggle, [data-nav-more]'));

    if (menuTriggers.length && panel) {
      const focusableSelector = 'a[href], button:not([disabled])';
      let lastTrigger = menuTriggers[0];

      const setExpanded = (isOpen) => {
        menuTriggers.forEach((btn) => btn.setAttribute('aria-expanded', String(isOpen)));
      };

      const closePanel = () => {
        panel.classList.remove('is-open');
        setExpanded(false);
        document.body.style.overflow = '';
      };

      const openPanel = () => {
        panel.classList.add('is-open');
        setExpanded(true);
        document.body.style.overflow = 'hidden';
        const first = panel.querySelector(focusableSelector);
        if (first) first.focus();
      };

      menuTriggers.forEach((btn) => {
        btn.addEventListener('click', () => {
          lastTrigger = btn;
          if (panel.classList.contains('is-open')) {
            closePanel();
          } else {
            openPanel();
          }
        });
      });

      panel.querySelectorAll('a').forEach((link) => {
        link.addEventListener('click', closePanel);
      });

      document.addEventListener('keydown', (e) => {
        if (!panel.classList.contains('is-open')) return;

        if (e.key === 'Escape') {
          closePanel();
          lastTrigger.focus();
          return;
        }

        if (e.key === 'Tab') {
          const focusables = Array.from(panel.querySelectorAll(focusableSelector));
          if (!focusables.length) return;
          const first = focusables[0];
          const last = focusables[focusables.length - 1];
          if (e.shiftKey && document.activeElement === first) {
            e.preventDefault();
            last.focus();
          } else if (!e.shiftKey && document.activeElement === last) {
            e.preventDefault();
            first.focus();
          }
        }
      });
    }
  } catch (err) {
    console.error('Techigrate: mobile nav toggle failed', err);
  }


  /* ---- Navigation polish --------------------------------------------------
     Keeps the existing nav structure, but adds one light layer of interaction:
     the desktop capsule follows the current/hovered link, and every page marks
     its own link automatically so copied header markup cannot drift out of sync.
     The same current-page state is applied to the mobile panel + quick-nav. */
  try {
    const normalizeHref = (href) => {
      try {
        const url = new URL(href, window.location.href);
        return (url.pathname.split('/').pop() || 'index.html').toLowerCase();
      } catch (_) {
        return String(href || '').split('/').pop().toLowerCase();
      }
    };

    const currentFile = (window.location.pathname.split('/').pop() || 'index.html').toLowerCase();
    const navLinks = document.querySelector('.nav-links');
    const topLinks = navLinks ? Array.from(navLinks.querySelectorAll('a[href]')) : [];
    const mobileLinks = Array.from(document.querySelectorAll('.mobile-panel a[href]'));
    const quickLinks = Array.from(document.querySelectorAll('.bottom-nav a[href]'));

    const allNavLinks = [...topLinks, ...mobileLinks, ...quickLinks];
    const seen = new Set();
    allNavLinks.forEach((link) => {
      if (seen.has(link)) return;
      seen.add(link);
      const targetFile = normalizeHref(link.getAttribute('href'));
      if (targetFile === currentFile) link.setAttribute('aria-current', 'page');
    });

    if (navLinks && topLinks.length) {
      let activeLink = topLinks.find((link) => link.getAttribute('aria-current') === 'page') || null;
      let raf = 0;

      const placeIndicator = (link, visible = true) => {
        if (!link) return;
        cancelAnimationFrame(raf);
        raf = requestAnimationFrame(() => {
          const navRect = navLinks.getBoundingClientRect();
          const rect = link.getBoundingClientRect();
          if (!navRect.width || !rect.width) return;
          navLinks.style.setProperty('--tg-nav-ind-x', `${(rect.left - navRect.left).toFixed(2)}px`);
          navLinks.style.setProperty('--tg-nav-ind-w', `${rect.width.toFixed(2)}px`);
          navLinks.style.setProperty('--tg-nav-ind-o', visible ? '1' : '0');
        });
      };

      const restoreActive = () => placeIndicator(activeLink, Boolean(activeLink));

      if (activeLink) placeIndicator(activeLink);

      topLinks.forEach((link) => {
        link.addEventListener('pointerenter', () => placeIndicator(link), { passive: true });
        link.addEventListener('focusin', () => placeIndicator(link), { passive: true });
        link.addEventListener('pointerdown', () => {
          link.classList.remove('is-nav-press');
          void link.offsetWidth;
          link.classList.add('is-nav-press');
        }, { passive: true });
      });

      navLinks.addEventListener('pointerleave', restoreActive, { passive: true });
      navLinks.addEventListener('focusout', (event) => {
        if (!navLinks.contains(event.relatedTarget)) restoreActive();
      });

      window.addEventListener('resize', restoreActive, { passive: true });
      window.addEventListener('pageshow', restoreActive, { passive: true });
    }

    /* Recalculate the active state when the More menu is opened so the mobile
       panel never depends on hand-edited aria-current attributes. */
    mobileLinks.forEach((link) => {
      link.addEventListener('pointerdown', () => {
        link.classList.remove('is-nav-press');
        void link.offsetWidth;
        link.classList.add('is-nav-press');
      }, { passive: true });
    });
  } catch (err) {
    console.error('Techigrate: navigation polish failed — base navigation remains intact', err);
  }

  /* ---- Scroll reveal ----
     Same restrained single-pass IntersectionObserver as before. New: items
     that share a parent (a row of stat cards, a list of capability rows,
     work tiles, insight rows…) now cascade in with a small stagger instead
     of all snapping to visible at once — capped at 6 steps so a long list
     doesn't end with a silly tail. A page script (about.js, for example)
     that sets its own transitionDelay afterward still wins, since it runs
     later and writes the inline style directly.

     If this block throws before any [data-reveal] element gets
     .is-visible, those elements would otherwise stay at opacity:0
     forever — so the catch below force-reveals everything as a
     last-resort fallback, on top of the <noscript> case each page
     already handles in CSS. */
  try {
    const revealTargets = document.querySelectorAll('[data-reveal]');
    if (revealTargets.length) {
      const siblingCounts = new Map();
      revealTargets.forEach((el) => {
        const parent = el.parentElement;
        const index = siblingCounts.get(parent) || 0;
        el.style.setProperty('--reveal-d', `${Math.min(index, 6) * 70}ms`);
        siblingCounts.set(parent, index + 1);
      });

      if ('IntersectionObserver' in window) {
        const io = new IntersectionObserver(
          (entries) => {
            entries.forEach((entry) => {
              if (entry.isIntersecting) {
                entry.target.classList.add('is-visible');
                io.unobserve(entry.target);
              }
            });
          },
          { threshold: 0.16, rootMargin: '0px 0px -60px 0px' }
        );
        revealTargets.forEach((el) => io.observe(el));
      } else {
        revealTargets.forEach((el) => el.classList.add('is-visible'));
      }
    }
  } catch (err) {
    console.error('Techigrate: scroll reveal failed — revealing content as a fallback', err);
    document.querySelectorAll('[data-reveal]').forEach((el) => el.classList.add('is-visible'));
  }

  /* ---- Word-stagger text reveal ----
     Opt-in: any element with [data-reveal-text] gets its text split into
     per-word spans (once, on load — the original text content is rebuilt
     from the same words, so nothing is lost for selection/copy or a
     screen reader reading the element as a whole) and revealed with a
     short stagger the same way [data-reveal] elements are, via the same
     IntersectionObserver pattern. Kept as its own block so a failure here
     can never affect the plainer [data-reveal] elements above — headings
     matter too much to risk both reveal systems on one try/catch.

     Skipped under reduced motion (words are just left visible), and
     skipped for elements already containing markup more complex than
     plain text (a heading with an inline icon or gradient span, say) —
     splitting those on whitespace would silently mangle the markup, so
     this only ever touches elements whose entire content is a single
     text node. */
  try {
    const textTargets = document.querySelectorAll('[data-reveal-text]');
    if (textTargets.length && !prefersReducedMotion) {
      textTargets.forEach((el) => {
        if (el.childNodes.length !== 1 || el.childNodes[0].nodeType !== Node.TEXT_NODE) return;
        const words = el.textContent.trim().split(/\s+/);
        el.setAttribute('aria-label', el.textContent.trim());
        el.textContent = '';
        words.forEach((word, i) => {
          const span = document.createElement('span');
          span.className = 'tg-word';
          span.style.setProperty('--w-d', String(i * 45));
          span.textContent = word;
          span.setAttribute('aria-hidden', 'true');
          el.appendChild(span);
          if (i < words.length - 1) el.appendChild(document.createTextNode(' '));
        });
      });

      if ('IntersectionObserver' in window) {
        const io = new IntersectionObserver(
          (entries) => {
            entries.forEach((entry) => {
              if (entry.isIntersecting) {
                entry.target.classList.add('is-visible');
                io.unobserve(entry.target);
              }
            });
          },
          { threshold: 0.4 }
        );
        textTargets.forEach((el) => io.observe(el));
      } else {
        textTargets.forEach((el) => el.classList.add('is-visible'));
      }
    }
  } catch (err) {
    console.error('Techigrate: word-stagger reveal failed — leaving text as plain content', err);
    document.querySelectorAll('[data-reveal-text]').forEach((el) => el.classList.add('is-visible'));
  }

  /* ---- Footer year ---- */
  try {
    document.querySelectorAll('[data-year]').forEach((el) => {
      el.textContent = new Date().getFullYear();
    });
  } catch (err) {
    console.error('Techigrate: footer year failed', err);
  }

  /* ---- Subtle pointer parallax for spatial/glass compositions ----
     Applied to any element with [data-parallax]; children with
     [data-depth="n"] shift proportionally to pointer position. Disabled
     on touch devices and when reduced motion is requested.

     Fix: the previous version wrote a bare translate3d(...) straight into
     .style.transform, which silently erased each tile's own rotation (and
     hero-node-center's centering translate) the first time the pointer
     moved — and reset to translate3d(0,0,0) on leave, permanently killing
     it. Each layer's real base transform is now captured once up front and
     the parallax offset is composed on top of it, both while moving and on
     leave. */
  try {
    if (!prefersReducedMotion && !isTouch) {
      document.querySelectorAll('[data-parallax]').forEach((stage) => {
        const layers = Array.from(stage.querySelectorAll('[data-depth]'));
        if (!layers.length) return;

        const bases = layers.map((layer) => {
          const computed = window.getComputedStyle(layer).transform;
          return computed && computed !== 'none' ? computed : '';
        });

        let raf = null;
        stage.addEventListener('pointermove', (e) => {
          const rect = stage.getBoundingClientRect();
          const px = (e.clientX - rect.left) / rect.width - 0.5;
          const py = (e.clientY - rect.top) / rect.height - 0.5;

          if (raf) cancelAnimationFrame(raf);
          raf = requestAnimationFrame(() => {
            layers.forEach((layer, i) => {
              const depth = parseFloat(layer.dataset.depth) || 0;
              const x = px * depth * 22;
              const y = py * depth * 22;
              layer.style.transform = `${bases[i]} translate3d(${x}px, ${y}px, 0)`;
            });
          });
        });

        stage.addEventListener('pointerleave', () => {
          layers.forEach((layer, i) => {
            layer.style.transform = bases[i] || '';
          });
        });
      });
    }
  } catch (err) {
    console.error('Techigrate: pointer parallax failed', err);
  }

  /* ---- Magnetic tilt ----
     A lighter, faster sibling of the parallax block above, for the
     floating 3D controls (section-nav's two panels, back-nav's pills):
     any [data-tilt="N"] element gets its --mx/--my custom properties
     (consumed by that component's own transform in CSS — see
     global.css) driven by pointer position, up to N degrees of tilt,
     snapping back to 0 on leave. Deliberately NOT reused for the
     hero's [data-parallax] composition above: that one moves whole
     layered scenes at a shared depth ratio, this one tilts a single
     self-contained object toward the cursor — different enough
     mechanisms that sharing one block would make both harder to read.
     Skipped on touch (no hover/pointermove worth reacting to) and under
     reduced motion. */
  // Defined at module scope (not inside the try below) so the back-nav
  // block further down — which creates its own [data-tilt] buttons well
  // after this block's one-time query has already run — can wire them up
  // the same way instead of duplicating this logic.
  const wireTilt = (el) => {
    const max = parseFloat(el.dataset.tilt) || 6;
    let raf = null;
    el.addEventListener('pointermove', (e) => {
      const rect = el.getBoundingClientRect();
      const mx = ((e.clientX - rect.left) / rect.width - 0.5) * 2;
      const my = ((e.clientY - rect.top) / rect.height - 0.5) * 2;
      if (raf) cancelAnimationFrame(raf);
      raf = requestAnimationFrame(() => {
        el.style.setProperty('--mx', (mx * max).toFixed(2));
        el.style.setProperty('--my', (my * max).toFixed(2));
      });
    });
    el.addEventListener('pointerleave', () => {
      if (raf) cancelAnimationFrame(raf);
      el.style.setProperty('--mx', 0);
      el.style.setProperty('--my', 0);
    });
  };

  try {
    if (!prefersReducedMotion && !isTouch) {
      document.querySelectorAll('[data-tilt]').forEach(wireTilt);
    }
  } catch (err) {
    console.error('Techigrate: magnetic tilt failed', err);
  }

  /* ---- Scroll progress ----
     A slim gradient line under the header reflecting how far down the
     current page the person has scrolled — an inline indicator rather
     than a decoration, so it's built to survive resize/orientation
     change and content that loads in after first paint (it recomputes
     the page height on scroll, not just once). Uses transform: scaleX
     rather than width so the browser can run it entirely on the
     compositor. Hidden on pages short enough that there's nothing to
     track (under one viewport of scroll room). */
  try {
    const bar = document.createElement('div');
    bar.className = 'scroll-progress';
    bar.setAttribute('aria-hidden', 'true');
    document.body.appendChild(bar);

    let ticking = false;
    const updateProgress = () => {
      ticking = false;
      const scrollable = document.documentElement.scrollHeight - window.innerHeight;
      if (scrollable < window.innerHeight * 0.5) {
        bar.classList.remove('is-active');
        return;
      }
      bar.classList.add('is-active');
      const ratio = Math.min(1, Math.max(0, window.scrollY / scrollable));
      bar.style.transform = `scaleX(${ratio})`;
    };
    updateProgress();
    window.addEventListener('scroll', () => {
      if (!ticking) {
        ticking = true;
        requestAnimationFrame(updateProgress);
      }
    }, { passive: true });
    window.addEventListener('resize', updateProgress, { passive: true });
  } catch (err) {
    console.error('Techigrate: scroll progress failed', err);
  }

  /* ---- Theme toggle ----
     The switch's checked state IS the theme: unchecked = light, checked =
     dark. The initial theme is still applied synchronously in each page's
     <head> so there is no first-paint flash. User-triggered changes now use
     the View Transitions API when available: the incoming theme is revealed
     from the bottom edge upward, matching the reference component's clean
     directional wipe rather than simply cross-fading the whole page.

     A CSS fallback keeps the theme change functional in older browsers.
     Reduced-motion users get an immediate theme swap. */
  try {
    const themeInputs = document.querySelectorAll('.theme-toggle .input');
    if (themeInputs.length) {
      const root = document.documentElement;
      const themeMeta = document.querySelector('meta[name="theme-color"]');
      const supportsViewTransition = typeof document.startViewTransition === 'function';

      const syncInputs = (isDark) => {
        themeInputs.forEach((input) => { input.checked = isDark; });
      };

      const syncThemeColor = (theme) => {
        if (!themeMeta) return;
        themeMeta.setAttribute('content', theme === 'dark' ? '#0a0e1a' : '#ffffff');
      };

      const applyTheme = (next) => {
        root.setAttribute('data-theme', next);
        syncThemeColor(next);
        try { localStorage.setItem('techigrate-theme', next); } catch (e) { /* private mode etc. */ }
      };

      syncInputs(root.getAttribute('data-theme') === 'dark');
      syncThemeColor(root.getAttribute('data-theme') || 'light');

      themeInputs.forEach((input) => {
        input.addEventListener('change', () => {
          const next = input.checked ? 'dark' : 'light';
          const previous = root.getAttribute('data-theme') === 'dark' ? 'dark' : 'light';
          if (next === previous) return;

          const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
          syncInputs(next === 'dark');

          if (!supportsViewTransition || reducedMotion) {
            applyTheme(next);
            return;
          }

          /* View transitions capture the old page before this callback and
             the new page after it. global.css then clips the new snapshot
             upward, so the actual website — text, imagery, cards, nav, etc.
             — changes together as one surface instead of being covered by
             a fake color layer. */
          try {
            /* V09.7 day/night moment: while the homepage lake is on screen the
               page cross-dissolves (1.1s) instead of wiping, so the sunny and
               moonlit lakes melt into each other (home-scene.js runs the layer
               swap + sun/moon bloom on top). Everywhere else: the bottom-up wipe. */
            const scene = document.querySelector('[data-scene]');
            let lake = false;
            if (scene) {
              const r = scene.getBoundingClientRect();
              lake = r.bottom > window.innerHeight * 0.4 && r.top < window.innerHeight * 0.6;
            }
            root.classList.add(lake ? 'tg-vt-lake' : 'tg-vt-wipe');
            const vt = document.startViewTransition(() => {
              applyTheme(next);
            });
            const clear = () => root.classList.remove('tg-vt-lake', 'tg-vt-wipe');
            if (vt && vt.finished) vt.finished.then(clear, clear); else clear();
          } catch (transitionErr) {
            root.classList.remove('tg-vt-lake', 'tg-vt-wipe');
            /* A failed transition must never strand the toggle between
               states. The fallback is an ordinary instant theme update. */
            console.warn('Techigrate: theme transition fallback', transitionErr);
            applyTheme(next);
          }
        });
      });
    }
  } catch (err) {
    console.error('Techigrate: theme toggle failed', err);
  }

  /* ---- Outbound page transition ----
     V5.5: deliberately lightweight. The previous full-page blur/backdrop
     treatment could trigger expensive compositor work on complex pages.
     This version keeps the premium motion cue but uses only transform,
     opacity and a single GPU-friendly wash before native navigation.
  */
  try {
    const pageTransition = document.createElement('div');
    pageTransition.className = 'tg-page-transition';
    pageTransition.setAttribute('aria-hidden', 'true');
    pageTransition.innerHTML =
      '<div class="tg-page-transition__wash"></div>' +
      '<span class="tg-page-transition__bar tg-page-transition__bar--1"></span>' +
      '<span class="tg-page-transition__bar tg-page-transition__bar--2"></span>' +
      '<span class="tg-page-transition__grain"></span>';
    document.body.appendChild(pageTransition);

    let navigating = false;

    /* V09.7: browsers with cross-document View Transitions (css/v097-motion.css)
       animate the page change natively, so the wash + 360ms delay steps aside. */
    const nativePageTransitions = 'CSSViewTransitionRule' in window;

    const shouldSkip = (event, link) => {
      if (nativePageTransitions) return true;
      if (!link || navigating || event.defaultPrevented) return true;
      if (link.dataset.noPageTransition !== undefined) return true;
      if (link.hasAttribute('download')) return true;
      if (link.target && link.target !== '_self') return true;
      if (event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return true;

      const rawHref = link.getAttribute('href');
      if (!rawHref || rawHref.startsWith('#') || rawHref.startsWith('mailto:') || rawHref.startsWith('tel:') || rawHref.startsWith('javascript:')) return true;

      let url;
      try { url = new URL(rawHref, window.location.href); } catch (e) { return true; }
      if (url.origin !== window.location.origin) return true;
      if (url.pathname === window.location.pathname && url.search === window.location.search && url.hash) return true;
      if (url.pathname === window.location.pathname && url.search === window.location.search) return true;
      return false;
    };

    document.addEventListener('click', (event) => {
      if (event.button !== 0) return;
      const link = event.target.closest('a[href]');
      if (shouldSkip(event, link)) return;

      const url = new URL(link.href, window.location.href);
      navigating = true;
      event.preventDefault();

      const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
      const x = Math.max(0, Math.min(window.innerWidth, event.clientX));
      const y = Math.max(0, Math.min(window.innerHeight, event.clientY));
      document.documentElement.style.setProperty('--tg-transition-x', x + 'px');
      document.documentElement.style.setProperty('--tg-transition-y', y + 'px');

      if (reduced) {
        window.location.assign(url.href);
        return;
      }

      pageTransition.classList.remove('is-active', 'is-navigating');
      void pageTransition.offsetWidth;
      pageTransition.classList.add('is-active');

      requestAnimationFrame(() => {
        requestAnimationFrame(() => pageTransition.classList.add('is-navigating'));
      });

      /* Keep the handoff below half a second. The old 620ms + heavy blur made
         navigation feel delayed even when the destination was already fast. */
      window.setTimeout(() => window.location.assign(url.href), 360);
    });
  } catch (err) {
    console.error('Techigrate: outbound page transition failed — native links remain active', err);
  }

  /* ---- Back to Home / Back to Top ----
     A single persistent floating 3D control, injected on every page that
     loads this file (opt out with <body data-no-back-nav>, used on
     404.html since it already has an inline "Back to home" button front
     and center). Unlike js/section-nav.js's prev/next panels, this one has
     nothing to do with a page's section count or scroll position within
     it — it's a site-wide escape hatch, so it lives here rather than
     there.

     Two variants:
     - Subpages: a "Back to Home" pill that's always the resting/visible
       face of the control. Hovering or focusing it pops a second
       "Back to Top" action out above it — see the CSS for the transform
       choreography. Touch devices (no hover) get a tap-to-expand instead:
       the first tap opens it (and is prevented from following the Home
       link early), a second tap on either action follows through; tapping
       anywhere outside closes it again.
     - Homepage: "Back to Home" would just point at the page already on
       screen, so only the single "Back to Top" circle is shown — no
       expand interaction needed for one action.

     Both variants stay out of the way until there's actually somewhere to
     go back to: hidden near the top of the page, appearing past a small
     scroll threshold (with a little hysteresis so it doesn't flicker
     right at the boundary). */
  try {
    if (!document.body.hasAttribute('data-no-back-nav')) {
      const isHomePage = /(^|\/)index\.html$/.test(location.pathname) ||
                          /\/$/.test(location.pathname);

      const ICON_HOME = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 11.5 12 4l8 7.5"/><path d="M6.5 9.5V19a1 1 0 0 0 1 1H10v-5.5h4V20h2.5a1 1 0 0 0 1-1V9.5"/></svg>';
      const ICON_TOP = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 19V6"/><path d="M6.5 11.5 12 6l5.5 5.5"/></svg>';

      const backNav = document.createElement('div');
      backNav.className = 'back-nav is-hidden' + (isHomePage ? ' back-nav-home-only' : '');

      const topBtn = document.createElement('button');
      topBtn.type = 'button';
      topBtn.className = 'back-nav-btn back-nav-top';
      topBtn.setAttribute('data-tilt', '4');
      topBtn.setAttribute('aria-label', 'Back to top');
      topBtn.innerHTML = '<span class="back-nav-icon">' + ICON_TOP + '</span><span class="back-nav-label">Back to Top</span>';

      const scrollToTop = () => {
        if (window.tgLenis) {
          window.tgLenis.scrollTo(0, { immediate: prefersReducedMotion });
        } else {
          window.scrollTo({ top: 0, behavior: prefersReducedMotion ? 'auto' : 'smooth' });
        }
      };
      topBtn.addEventListener('click', scrollToTop);

      if (isHomePage) {
        backNav.appendChild(topBtn);
        document.body.appendChild(backNav);
      } else {
        const homeBtn = document.createElement('a');
        homeBtn.href = 'index.html';
        homeBtn.className = 'back-nav-btn back-nav-home';
        homeBtn.setAttribute('data-tilt', '4');
        homeBtn.setAttribute('aria-label', 'Back to Home');
        homeBtn.innerHTML = '<span class="back-nav-icon">' + ICON_HOME + '</span><span class="back-nav-label">Back to Home</span>';

        backNav.appendChild(topBtn);
        backNav.appendChild(homeBtn);
        document.body.appendChild(backNav);

        /* Touch devices have no hover, so the pop-out needs an explicit
           tap-to-expand instead of relying on :hover/:focus-within. The
           first tap only opens it; the Home link's default navigation is
           held back that once via preventDefault so tapping the trigger
           doesn't immediately leave the page before the second action is
           even visible. */
        if (isTouch) {
          homeBtn.addEventListener('click', (e) => {
            if (!backNav.classList.contains('is-expanded')) {
              e.preventDefault();
              backNav.classList.add('is-expanded');
            }
          });
          document.addEventListener('click', (e) => {
            if (backNav.classList.contains('is-expanded') && !backNav.contains(e.target)) {
              backNav.classList.remove('is-expanded');
            }
          });
        }

        /* Keyboard users tabbing in from below (Home is the last thing in
           the DOM order after Top) would reach Home first without ever
           seeing Top expand — Escape while focus is inside collapses it
           and returns focus to the resting Home pill, same shape as the
           mobile-panel's Escape handling above. */
        backNav.addEventListener('keydown', (e) => {
          if (e.key === 'Escape' && backNav.classList.contains('is-expanded')) {
            backNav.classList.remove('is-expanded');
            homeBtn.focus();
          }
        });
      }

      // Apply the same tilt wiring defined above to these two buttons —
      // they were created after that block's one-time query already ran.
      try {
        if (!prefersReducedMotion && !isTouch) {
          backNav.querySelectorAll('[data-tilt]').forEach(wireTilt);
        }
      } catch (tiltErr) {
        console.error('Techigrate: back-nav tilt failed', tiltErr);
      }

      /* ---- Show past a small scroll threshold, with hysteresis ---- */
      const SHOW_AFTER = 240;
      const HIDE_BEFORE = 160;
      let visible = false;
      let bnTicking = false;

      // Premium Back to Top micro-interactions: scroll progress + pointer sheen.
      const setBackTopEffects = () => {
        if (!backNav || !topBtn) return;
        const maxScroll = Math.max(1, document.documentElement.scrollHeight - window.innerHeight);
        const progress = Math.max(0, Math.min(1, (window.scrollY || 0) / maxScroll));
        topBtn.style.setProperty('--btt-progress', (progress * 100).toFixed(2) + '%');
      };

      if (!prefersReducedMotion && !isTouch) {
        topBtn.addEventListener('pointermove', (e) => {
          const rect = topBtn.getBoundingClientRect();
          const x = ((e.clientX - rect.left) / rect.width) * 100;
          const y = ((e.clientY - rect.top) / rect.height) * 100;
          topBtn.style.setProperty('--btt-sheen-x', x.toFixed(1) + '%');
          topBtn.style.setProperty('--btt-sheen-y', y.toFixed(1) + '%');
        }, { passive: true });
        topBtn.addEventListener('pointerleave', () => {
          topBtn.style.setProperty('--btt-sheen-x', '50%');
          topBtn.style.setProperty('--btt-sheen-y', '50%');
        }, { passive: true });
      }
      setBackTopEffects();
      window.addEventListener('resize', setBackTopEffects, { passive: true });

      const updateBackNavVisibility = () => {
        bnTicking = false;
        const y = window.scrollY;
        if (!visible && y > SHOW_AFTER) {
          visible = true;
          backNav.classList.remove('is-hidden');
        } else if (visible && y < HIDE_BEFORE) {
          visible = false;
          backNav.classList.add('is-hidden');
          backNav.classList.remove('is-expanded');
        }
      };
      updateBackNavVisibility();
      window.addEventListener('scroll', () => {
        setBackTopEffects();
        if (!bnTicking) {
          bnTicking = true;
          requestAnimationFrame(updateBackNavVisibility);
        }
      }, { passive: true });

      /* Hide behind the mobile menu while it's open, same reasoning as
         js/section-nav.js's equivalent block — `panel` is already queried
         above for the mobile nav toggle. */
      if (panel) {
        const syncBackNavWithPanel = () => {
          backNav.classList.toggle('is-suppressed', panel.classList.contains('is-open'));
        };
        new MutationObserver(syncBackNavWithPanel).observe(panel, { attributes: true, attributeFilter: ['class'] });
      }
    }
  } catch (err) {
    console.error('Techigrate: back-nav failed', err);
  }
})();
