/* ==========================================================================
   TECHIGRATE — SIGNAL-DECODE INTRO + IRIS OPEN
   Homepage only. Each greeting scrambles through glyphs of its own script and
   locks in letter by letter; a counter + progress line run underneath; the
   final welcome opens the site through a glowing circular iris.

   Contract with the rest of the site (unchanged from the previous intro):
   - markup:      .tg-preloader > [data-loader-word]   (index.html untouched)
   - body states: tg-preloading -> tg-loaded (+ tg-stair-handoff-active and
                  tg-site-releasing while the iris is opening)
   - session key: sessionStorage 'techigrate-home-intro-seen'; ?intro=1 replays
   The previous version lives in _intro-backup/ if you ever want to roll back.
   ========================================================================== */
(function () {
  'use strict';

  var loader = document.querySelector('.tg-preloader');
  var word = loader && loader.querySelector('[data-loader-word]');
  if (!loader || !word) return;

  /* Skip the full sequence after it has played once in this tab. */
  var forceReplay = false;
  try {
    forceReplay = new URLSearchParams(window.location.search).get('intro') === '1';
  } catch (e) {}

  var introSeen = false;
  try {
    introSeen = sessionStorage.getItem('techigrate-home-intro-seen') === '1';
  } catch (e) {}

  if (introSeen && !forceReplay) {
    document.body.classList.remove('tg-preloading');
    document.body.classList.add('tg-loaded');
    loader.remove();
    return;
  }

  var reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  var greetings = [
    { t: 'Hello',                        l: 'English'  },
    { t: 'नमस्ते',                        l: 'हिन्दी'     },
    { t: 'Bonjour',                      l: 'Français' },
    { t: 'こんにちは',                     l: '日本語'     },
    { t: 'Hello, Welcome to TECHIGRATE', l: 'Welcome'  }
  ];
  var BRAND = 'TECHIGRATE';

  var stepDelays = [240, 180, 150, 130];
  var finalDecodeMs = 380;
  var finalHoldMs = 140;
  var counterCompleteMs = 120;
  var irisMs = 600;
  var maxWaitMs = 2300;

  var pageReady = document.readyState === 'complete';
  var sequenceComplete = false;
  var finished = false;
  document.body.classList.add('tg-preloading');

  /* ------------------------------ Build stage ----------------------------- */
  loader.insertAdjacentHTML('afterbegin',
    '<div class="tg-pl__bg" aria-hidden="true">' +
      '<div class="tg-pl__aurora tg-pl__aurora--a"></div>' +
      '<div class="tg-pl__aurora tg-pl__aurora--b"></div>' +
      '<div class="tg-pl__grid"></div>' +
      '<div class="tg-pl__orbit"></div>' +
      '<div class="tg-pl__orbit tg-pl__orbit--inner"></div>' +
      '<span class="tg-pl__corner tg-pl__corner--tl"></span>' +
      '<span class="tg-pl__corner tg-pl__corner--tr"></span>' +
      '<span class="tg-pl__corner tg-pl__corner--bl"></span>' +
      '<span class="tg-pl__corner tg-pl__corner--br"></span>' +
    '</div>' +
    '<div class="tg-pl__hud tg-pl__hud--tl">Techigrate</div>' +
    '<div class="tg-pl__hud tg-pl__hud--tr">Tech for people.</div>' +
    '<div class="tg-pl__hud tg-pl__hud--bl"><b class="tg-pl__pct" data-pl-pct>000</b><span>%</span></div>' +
    '<div class="tg-pl__hud tg-pl__hud--br">Initialising</div>' +
    '<div class="tg-pl__bar"><i data-pl-bar></i></div>'
  );

  var stage = document.createElement('div');
  stage.className = 'tg-pl__stage';
  stage.innerHTML =
    '<div class="tg-pl__mark" aria-hidden="true"><svg viewBox="0 0 32 32" focusable="false"><defs><linearGradient id="tgPlMarkG" gradientUnits="userSpaceOnUse" x1="4" y1="4" x2="29" y2="28"><stop stop-color="#2E83FF"/><stop offset=".48" stop-color="#5D5CFF"/><stop offset="1" stop-color="#B45AF2"/></linearGradient></defs><path d="M4.5 6.5h23v6.2h-8.35v13h-6.3v-13H4.5z" fill="url(#tgPlMarkG)"/><path d="M15.4 13h3.75v9.1l-2.1 2.2h-1.65z" fill="#F8FDFF" opacity=".78"/></svg></div>' +
    '<div class="tg-pl__meta" aria-hidden="true">' +
      '<span data-pl-index>01</span><i></i><span data-pl-lang>English</span>' +
    '</div>';
  loader.appendChild(stage);
  stage.appendChild(word); /* moves the existing word node into the stage */

  var elIndex = loader.querySelector('[data-pl-index]');
  var elLang = loader.querySelector('[data-pl-lang]');
  var elPct = loader.querySelector('[data-pl-pct]');
  var elBar = loader.querySelector('[data-pl-bar]');

  /* ------------------------------ Glyph pools ------------------------------ */
  var POOL_UP = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ#%&*+=?';
  var POOL_LO = 'abcdefghijklmnopqrstuvwxyz#%&*+=?';
  var POOL_DEV = 'अआइईउऊएऐओऔकखगघचछजझटठडढणतथदधनपफबभमयरलवशषसह';
  var POOL_KANA = 'あいうえおかきくけこさしすせそたちつてとなにぬねのはひふへほまみむめもやゆよらりるれろわをん';
  var POOL_HANGUL = '가나다라마바사아자차카타파하한글안녕세요';

  function poolFor(ch) {
    if (/[\u0900-\u097F]/.test(ch)) return POOL_DEV;
    if (/[\u3040-\u30FF]/.test(ch)) return POOL_KANA;
    if (/[\uAC00-\uD7AF]/.test(ch)) return POOL_HANGUL;
    if (/[A-Z]/.test(ch)) return POOL_UP;
    if (/[a-zÀ-ÿ]/.test(ch)) return POOL_LO;
    return null; /* punctuation and anything else stays put */
  }
  function pick(pool) { return pool.charAt(Math.floor(Math.random() * pool.length)); }

  function esc(s) { return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }

  function lerpHex(a, b, t) {
    function p(h, i) { return parseInt(h.substr(i, 2), 16); }
    var out = '#';
    for (var i = 1; i <= 5; i += 2) {
      var v = Math.round(p(a, i) + (p(b, i) - p(a, i)) * t);
      out += (v < 16 ? '0' : '') + v.toString(16);
    }
    return out;
  }

  /* --------------------------- Render + decode word ------------------------ */
  var rafDecode = 0;

  function buildWord(text) {
    var brandAt = text.indexOf(BRAND);
    var brandStart = brandAt < 0 ? -1 : Array.from(text.slice(0, brandAt)).length;
    var brandLen = BRAND.length;
    var idx = 0;
    var html = '';
    text.split(' ').forEach(function (w, wi) {
      if (wi > 0) { html += ' '; idx += 1; }
      html += '<span class="tg-w">';
      Array.from(w).forEach(function (ch) {
        var isBrand = brandStart >= 0 && idx >= brandStart && idx < brandStart + brandLen;
        var style = '';
        if (isBrand) {
          var t = (idx - brandStart) / (brandLen - 1);
          style = ' style="--lc:' + lerpHex('#8fa6ff', '#c29bff', t) + '"';
        }
        html += '<span class="tg-letter' + (isBrand ? ' tg-letter--brand' : '') + '"' + style +
          ' data-c="' + esc(ch) + '" aria-hidden="true">' + esc(ch) + '</span>';
        idx += 1;
      });
      html += '</span>';
    });
    return html;
  }

  function decodeWord(text, durationMs, isFinal) {
    if (rafDecode) { window.cancelAnimationFrame(rafDecode); rafDecode = 0; }

    word.setAttribute('aria-label', text);
    word.classList.remove('is-entering', 'is-final');
    word.innerHTML = buildWord(text);

    var letters = Array.prototype.slice.call(word.querySelectorAll('.tg-letter'));

    if (reduceMotion) {
      letters.forEach(function (el) { el.classList.add('is-set'); });
      return;
    }

    /* Lock every letter to its final width so scrambling never reflows the line. */
    letters.forEach(function (el) { el.style.width = el.getBoundingClientRect().width + 'px'; });

    void word.offsetWidth; /* retrigger the entrance animation */
    word.classList.add('is-entering');
    if (isFinal) word.classList.add('is-final');

    var n = letters.length;
    var lead = Math.min(70, durationMs * 0.2);
    var stagger = Math.max(14, (durationMs - lead) / Math.max(n, 1));
    var start = performance.now();
    var lastSwap = letters.map(function () { return 0; });
    var resolved = letters.map(function () { return false; });
    var left = n;

    letters.forEach(function (el) {
      var ch = el.getAttribute('data-c');
      var pool = poolFor(ch);
      if (pool) el.textContent = pick(pool);
    });

    function frame(now) {
      var t = now - start;
      for (var i = 0; i < n; i += 1) {
        if (resolved[i]) continue;
        var el = letters[i];
        var ch = el.getAttribute('data-c');
        var pool = poolFor(ch);
        if (!pool || t >= lead + i * stagger) {
          el.textContent = ch;
          el.classList.add('is-set');
          resolved[i] = true;
          left -= 1;
        } else if (now - lastSwap[i] > 52) {
          el.textContent = pick(pool);
          lastSwap[i] = now;
        }
      }
      rafDecode = left > 0 ? window.requestAnimationFrame(frame) : 0;
    }
    rafDecode = window.requestAnimationFrame(frame);
  }

  /* ------------------------------ Progress HUD ----------------------------- */
  var pctNow = 0;
  var rafPct = 0;

  function pad3(v) { v = Math.round(v); return (v < 10 ? '00' : v < 100 ? '0' : '') + v; }

  function setProgress(target, ms) {
    elBar.style.transitionDuration = (reduceMotion ? 0 : ms) + 'ms';
    elBar.style.transform = 'scaleX(' + (target / 100) + ')';
    if (rafPct) window.cancelAnimationFrame(rafPct);
    if (reduceMotion || ms <= 0) { pctNow = target; elPct.textContent = pad3(target); return; }
    var from = pctNow;
    var t0 = performance.now();
    function tick(now) {
      var k = Math.min(1, (now - t0) / ms);
      var e = 1 - Math.pow(1 - k, 3);
      pctNow = from + (target - from) * e;
      elPct.textContent = pad3(pctNow);
      rafPct = k < 1 ? window.requestAnimationFrame(tick) : 0;
    }
    rafPct = window.requestAnimationFrame(tick);
  }

  function showGreeting(i) {
    var g = greetings[i];
    var isFinal = i === greetings.length - 1;
    elIndex.textContent = (i + 1 < 10 ? '0' : '') + (i + 1);
    elLang.textContent = g.l;
    var dur = isFinal ? finalDecodeMs : Math.max(150, Math.min(330, (stepDelays[i] || 200) * 0.85));
    decodeWord(g.t, dur, isFinal);
    /* Hold at 99 until the page is actually ready; the last 1% lands on reveal. */
    setProgress(isFinal ? 99 : Math.round(((i + 1) / greetings.length) * 96), isFinal ? finalDecodeMs : (stepDelays[i] || 200));
  }

  /* -------------------------------- Sequence ------------------------------- */
  function runSequence() {
    if (reduceMotion) {
      showGreeting(greetings.length - 1);
      sequenceComplete = true;
      maybeFinish();
      return;
    }

    var cursor = 0;
    showGreeting(0);

    function next() {
      if (cursor >= greetings.length - 1) {
        window.setTimeout(function () {
          sequenceComplete = true;
          maybeFinish();
        }, finalDecodeMs + finalHoldMs);
        return;
      }
      cursor += 1;
      showGreeting(cursor);
      if (cursor >= greetings.length - 1) { next(); return; }
      window.setTimeout(next, stepDelays[cursor]);
    }

    window.setTimeout(next, stepDelays[0]);
  }

  /* ------------------------------ Iris open exit --------------------------- */
  function easeInOut(k) { return k < 0.5 ? 4 * k * k * k : 1 - Math.pow(-2 * k + 2, 3) / 2; }

  function openIris() {
    var ring = document.createElement('div');
    ring.className = 'tg-iris-ring';
    ring.setAttribute('aria-hidden', 'true');

    /* Reveal the real page underneath; the loader now only covers it with a growing hole. */
    document.body.classList.remove('tg-preloading');
    document.body.classList.add('tg-loaded', 'tg-stair-handoff-active');
    document.body.appendChild(ring);
    loader.classList.add('is-iris');

    var maxR = Math.hypot(window.innerWidth, window.innerHeight) / 2 + 24;
    var t0 = performance.now();

    window.requestAnimationFrame(function () {
      document.body.classList.add('tg-site-releasing');
    });

    function frame(now) {
      var k = Math.min(1, (now - t0) / irisMs);
      var r = easeInOut(k) * maxR;
      var v = r.toFixed(1) + 'px';
      loader.style.setProperty('--r', v);
      ring.style.setProperty('--r', v);
      ring.style.opacity = k < 0.04 ? String(k / 0.04) : k > 0.9 ? String(Math.max(0, (1 - k) / 0.1)) : '1';
      if (k < 1) {
        window.requestAnimationFrame(frame);
      } else {
        cleanup(ring);
      }
    }
    window.requestAnimationFrame(frame);
  }

  function cleanup(ring) {
    if (ring && ring.parentNode) ring.remove();
    if (loader.parentNode) loader.remove();
    if (rafDecode) { window.cancelAnimationFrame(rafDecode); rafDecode = 0; }
    window.setTimeout(function () {
      document.body.classList.remove('tg-stair-handoff-active', 'tg-site-releasing');
    }, 60);
  }

  function revealSite() {
    if (finished) return;
    finished = true;
    try { sessionStorage.setItem('techigrate-home-intro-seen', '1'); } catch (e) {}

    /* Counter lands on 100, then the stage dissolves and the iris opens. */
    setProgress(100, reduceMotion ? 0 : counterCompleteMs);

    if (reduceMotion) {
      document.body.classList.remove('tg-preloading');
      document.body.classList.add('tg-loaded');
      loader.classList.add('is-leaving');
      window.setTimeout(function () { loader.remove(); }, 300);
      return;
    }

    window.setTimeout(function () {
      loader.classList.add('is-leaving');
    }, counterCompleteMs);

    window.setTimeout(openIris, counterCompleteMs + 160);
  }

  function maybeFinish() {
    if (sequenceComplete && pageReady) revealSite();
  }

  window.addEventListener('load', function () {
    pageReady = true;
    maybeFinish();
  }, { once: true });

  window.setTimeout(function () {
    pageReady = true;
    maybeFinish();
  }, maxWaitMs);

  runSequence();
})();
