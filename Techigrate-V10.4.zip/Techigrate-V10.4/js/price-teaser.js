
(function(){
  'use strict';
  var pop = document.querySelector('[data-price-teaser]');
  if(!pop) return;
  var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var close = pop.querySelector('[data-price-teaser-close]');
  var dismissed = false;
  function show(){ if(dismissed) return; pop.classList.add('is-visible'); }
  function hide(){ dismissed=true; pop.classList.add('is-closing'); window.setTimeout(function(){pop.remove();}, reduce?0:420); }
  close && close.addEventListener('click', hide);
  window.addEventListener('keydown', function(e){if(e.key==='Escape' && pop.classList.contains('is-visible')) hide();});
  function waitForLoad(){
    var run=function(){
      window.setTimeout(show, reduce?700:2600);
    };
    if(document.body.classList.contains('tg-loaded')) run(); else window.addEventListener('load',run,{once:true});
  }
  waitForLoad();
})();
