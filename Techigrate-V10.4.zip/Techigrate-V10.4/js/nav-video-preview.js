/* Techigrate — delayed Technology hover video preview */
(function(){
  'use strict';
  const header = document.querySelector('.site-header.tg-luxury-nav');
  const panel = document.querySelector('[data-nav-video-preview]');
  const video = panel?.querySelector('[data-nav-video]');
  const status = panel?.querySelector('[data-nav-video-status]');
  const progress = panel?.querySelector('[data-nav-video-progress]');
  const techLink = header?.querySelector('.nav-item[data-nav-key="technology"]');
  if(!header || !panel || !video || !techLink) return;

  const reduce = window.matchMedia('(prefers-reduced-motion: reduce)');
  const finePointer = window.matchMedia('(pointer:fine)');
  let showTimer = 0;
  let hideTimer = 0;
  let visible = false;
  let pointerInside = false;

  const isEligible = () => finePointer.matches && window.innerWidth > 900 && !reduce.matches;

  const position = () => {
    const rect = techLink.getBoundingClientRect();
    const panelWidth = Math.min(360, window.innerWidth - 32);
    const center = rect.left + rect.width / 2;
    const clamped = Math.max(panelWidth / 2 + 16, Math.min(window.innerWidth - panelWidth / 2 - 16, center));
    panel.style.left = `${clamped}px`;
  };

  const setStatus = (text) => {
    if(status) status.textContent = text;
  };

  const stopAndHide = () => {
    clearTimeout(showTimer);
    clearTimeout(hideTimer);
    visible = false;
    panel.classList.remove('is-visible');
    panel.setAttribute('aria-hidden','true');
    video.pause();
    try{ video.currentTime = 0; }catch{}
    setStatus('PREVIEW');
    if(progress) progress.style.transform = 'scaleX(0)';
  };

  const show = async () => {
    if(!isEligible()) return;
    position();
    visible = true;
    panel.classList.add('is-visible');
    panel.setAttribute('aria-hidden','false');
    setStatus('PLAYING');
    if(progress) progress.style.transform = 'scaleX(0)';
    try{
      video.currentTime = 0;
      await video.play();
    }catch{}
  };

  const scheduleShow = () => {
    if(!isEligible()) return;
    clearTimeout(hideTimer);
    clearTimeout(showTimer);
    showTimer = window.setTimeout(() => show(), 1500);
  };

  const scheduleHide = () => {
    clearTimeout(showTimer);
    clearTimeout(hideTimer);
    hideTimer = window.setTimeout(() => {
      if(!pointerInside) stopAndHide();
    }, 180);
  };

  techLink.addEventListener('mouseenter', () => { pointerInside = true; scheduleShow(); }, {passive:true});
  techLink.addEventListener('mouseleave', () => { pointerInside = false; scheduleHide(); }, {passive:true});
  techLink.addEventListener('focusin', scheduleShow);
  techLink.addEventListener('focusout', scheduleHide);

  panel.addEventListener('mouseenter', () => {
    pointerInside = true;
    clearTimeout(hideTimer);
  }, {passive:true});
  panel.addEventListener('mouseleave', () => {
    pointerInside = false;
    scheduleHide();
  }, {passive:true});

  video.addEventListener('timeupdate', () => {
    if(progress && video.duration) progress.style.transform = `scaleX(${Math.min(1, video.currentTime / video.duration)})`;
  });

  video.addEventListener('ended', () => {
    if(!visible) return;
    setStatus('REPLAY');
    try{ video.currentTime = 0; }catch{}
  });

  /* Keep the preview attached to Technology while the navbar morphs/scrolls. */
  let raf = 0;
  const track = () => {
    raf = 0;
    if(visible) position();
  };
  const requestTrack = () => { if(!raf) raf = requestAnimationFrame(track); };
  window.addEventListener('scroll', requestTrack, {passive:true});
  window.addEventListener('resize', () => {
    if(!isEligible()) stopAndHide();
    else requestTrack();
  }, {passive:true});

  /* Close the preview when any dropdown is opened. */
  document.addEventListener('pointerdown', (e) => {
    if(e.target.closest('.tg-nav-menu')) stopAndHide();
  }, {passive:true});
})();
