/* TECHIGRATE V09.3 — reveal for the V08 sections (heading rise, row stagger, closing block). */
(function () {
  'use strict';
  var targets = [].slice.call(document.querySelectorAll('.v8-h2, .v8-rows, .v8-end'));
  if (!targets.length) return;
  var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (reduce || !('IntersectionObserver' in window)) { targets.forEach(function (t) { t.classList.add('is-in'); }); return; }
  document.documentElement.classList.add('v8-js');
  var io = new IntersectionObserver(function (es) {
    es.forEach(function (e) {
      if (!e.isIntersecting) return;
      e.target.classList.add('is-in');
      io.unobserve(e.target);
      // the closing block animates its heading too
      if (e.target.classList.contains('v8-end')) { var h = e.target.querySelector('.v8-h2'); if (h) h.classList.add('is-in'); }
    });
  }, { threshold: 0.2, rootMargin: '0px 0px -8% 0px' });
  targets.forEach(function (t) { io.observe(t); });
})();
