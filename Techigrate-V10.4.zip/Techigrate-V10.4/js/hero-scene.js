/* ==========================================================================
   HOME — Three.js hero scene (progressive enhancement, not load-bearing)

   Draws a small "engineering constellation": a glass-like core (the
   "Engineering" node from the flat version) with four satellite shapes —
   Product / Intelligence / Automation / Experience, same four pillars as
   the CSS hero — connected by gradient lines, slowly rotating, tilting
   toward the pointer.

   IMPORTANT: this file only runs if it can fully succeed. If the Three.js
   CDN didn't load, the browser has no WebGL, or anything here throws, the
   function returns early and the original CSS/SVG hero (already sitting in
   the DOM in index.html) stays exactly as visible as it's always been.
   Nothing else on the page depends on this file — home.js's entrance
   animation and global.js's reveal system don't know or care whether this
   runs.
   ========================================================================== */

(function () {
  'use strict';

  const container = document.getElementById('heroVisual');
  const canvas = document.getElementById('heroCanvas');
  if (!container || !canvas) return;
  if (typeof THREE === 'undefined') return; // CDN blocked/offline — bail, fallback stays up

  const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  let renderer;
  try {
    renderer = new THREE.WebGLRenderer({ canvas: canvas, alpha: true, antialias: true, powerPreference: 'high-performance' });
  } catch (e) {
    return; // no WebGL support — bail, fallback stays up
  }
  if (!renderer.getContext()) return;

  canvas.addEventListener('webglcontextlost', (e) => {
    e.preventDefault();
    running = false;
  });

  // ---- Scene ----
  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(45, 1, 0.1, 100);
  camera.position.set(0, 0, 6.2);

  function resize() {
    const size = container.clientWidth;
    if (!size) return;
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.5));
    renderer.setSize(size, size, false); // false: don't let three.js fight our CSS sizing
    camera.aspect = 1;
    camera.updateProjectionMatrix();
  }

  // ---- Lighting — tinted with the site's own blue/violet accent ----
  scene.add(new THREE.AmbientLight(0xffffff, 0.55));
  const keyLight = new THREE.PointLight(0x3552e0, 1.4, 20);
  keyLight.position.set(3, 3, 4);
  scene.add(keyLight);
  const rimLight = new THREE.PointLight(0x7b3fe4, 1.2, 20);
  rimLight.position.set(-3, -2, 3);
  scene.add(rimLight);

  // ---- The cluster (rotated together as one group) ----
  const group = new THREE.Group();
  scene.add(group);

  const coreGeo = new THREE.IcosahedronGeometry(0.85, 1);
  const coreMat = new THREE.MeshPhysicalMaterial({
    color: 0x4c66e8,
    metalness: 0.25,
    roughness: 0.2,
    transparent: true,
    opacity: 0.9,
    emissive: 0x2033a0,
    emissiveIntensity: 0.35,
  });
  const core = new THREE.Mesh(coreGeo, coreMat);
  group.add(core);

  // Same four pillars as the flat hero, now placed in real 3D space.
  const satelliteDefs = [
    { pos: [-1.7, 1.1, 0.4] },  // Product
    { pos: [1.8, 0.9, -0.3] },  // Intelligence
    { pos: [-1.6, -1.2, -0.4] }, // Automation
    { pos: [1.7, -1.0, 0.3] },  // Experience
  ];

  const colorStart = new THREE.Color(0x3552e0);
  const colorEnd = new THREE.Color(0x7b3fe4);
  const satellites = [];
  const lineGroup = new THREE.Group();
  group.add(lineGroup);

  satelliteDefs.forEach((def, i) => {
    const mixT = i / (satelliteDefs.length - 1);
    const satColor = colorStart.clone().lerp(colorEnd, mixT);

    const geo = new THREE.OctahedronGeometry(0.32, 0);
    const mat = new THREE.MeshPhysicalMaterial({
      color: satColor,
      metalness: 0.3,
      roughness: 0.25,
      transparent: true,
      opacity: 0.92,
    });
    const mesh = new THREE.Mesh(geo, mat);
    mesh.position.set(def.pos[0], def.pos[1], def.pos[2]);
    group.add(mesh);
    satellites.push(mesh);

    // Gradient line from the core out to this satellite (vertex-colored,
    // same blue-to-violet gradient used everywhere else on the site).
    const points = [new THREE.Vector3(0, 0, 0), new THREE.Vector3(def.pos[0], def.pos[1], def.pos[2])];
    const lineGeo = new THREE.BufferGeometry().setFromPoints(points);
    lineGeo.setAttribute(
      'color',
      new THREE.Float32BufferAttribute([colorStart.r, colorStart.g, colorStart.b, colorEnd.r, colorEnd.g, colorEnd.b], 3)
    );
    const lineMat = new THREE.LineBasicMaterial({ vertexColors: true, transparent: true, opacity: 0.55 });
    lineGroup.add(new THREE.Line(lineGeo, lineMat));
  });

  resize();

  // ---- Pointer tilt (damped, so it settles instead of snapping) ----
  let targetX = 0, targetY = 0, currentX = 0, currentY = 0;
  container.addEventListener('pointermove', (e) => {
    const rect = container.getBoundingClientRect();
    targetX = ((e.clientX - rect.left) / rect.width - 0.5) * 2;
    targetY = ((e.clientY - rect.top) / rect.height - 0.5) * 2;
  });
  container.addEventListener('pointerleave', () => {
    targetX = 0;
    targetY = 0;
  });

  // ---- Only animate while it's actually visible (saves battery/CPU) ----
  let isOnScreen = true;
  if ('IntersectionObserver' in window) {
    new IntersectionObserver((entries) => {
      isOnScreen = entries[0].isIntersecting;
    }, { threshold: 0.05 }).observe(container);
  }

  let running = true;
  document.addEventListener('visibilitychange', () => {
    running = document.visibilityState === 'visible';
  });

  // ---- Render loop ----
  const clock = new THREE.Clock();
  function tick() {
    requestAnimationFrame(tick);
    if (!running || !isOnScreen) return;

    const dt = Math.min(clock.getDelta(), 0.1); // clamp so a tabbed-away spike doesn't jump the scene
    const t = clock.getElapsedTime();

    if (!prefersReducedMotion) {
      group.rotation.y += dt * 0.18;
      core.rotation.x += dt * 0.1;
      satellites.forEach((s, i) => {
        s.rotation.x += dt * (0.3 + i * 0.05);
        s.rotation.y += dt * (0.25 + i * 0.04);
      });
      core.scale.setScalar(1 + Math.sin(t * 1.2) * 0.03);

      currentX += (targetY * 0.35 - currentX) * 0.06;
      currentY += (targetX * 0.5 - currentY) * 0.06;
      group.rotation.x = currentX;
      group.rotation.z = currentY * 0.15;
    }

    renderer.render(scene, camera);
  }

  window.addEventListener('resize', resize);

  // Everything above ran without throwing — reveal the canvas and hide the
  // flat SVG/tile fallback (see the .is-3d rules in css/home.css).
  container.classList.add('is-3d');
  tick();
})();
