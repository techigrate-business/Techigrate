/* ==========================================================================
   TECHIGRATE — PROJECT INTAKE (upgrade module)
   Vanilla JS, no external services, no analytics, no build step.

   PROGRESSIVE ENHANCEMENT
   Without this file, the widget is a single plain form: every fieldset is
   visible, stacked in document order, and the "Continue" link at the
   bottom works immediately. This file turns that into a one-question-at-
   a-time flow. If anything in here throws, init() catches it, and the
   markup is left exactly as it would be with no JS at all — so a failure
   here degrades to the plain-form fallback, not to a broken page.

   PRIVACY
   All answers live in this tab's sessionStorage only (cleared when the tab
   closes), under the key below. Nothing is sent anywhere by this script,
   ever — there is no fetch, no beacon, no third-party call. The one
   exception is the moment someone clicks "Continue": it writes one extra,
   separate sessionStorage entry (see WRITE ON CONTINUE below), which
   js/contact.js reads on the same page to prefill the real contact form —
   see PROJECT-INTAKE.md for exactly what that does and doesn't do. The
   click itself is never intercepted or delayed for this write.

   RECEIVING A SEED FROM PROJECT RECOMMENDER
   If a visitor already answered the homepage's "What are you trying to
   build?" widget (js/project-recommender.js, namespaced tg-pr-) and
   clicked through to this page, that script leaves one small sessionStorage
   entry (see SEED_KEY below) naming the category they picked. This file
   reads it once, on load, pre-selects the matching Step 1 option here (so
   the visitor isn't asked the same thing twice), and clears the key
   immediately. It never auto-advances past Step 1 on its own — the
   visitor still sees and confirms the pre-selected answer themselves.
   See PROJECT-RECOMMENDER.md for the category-to-value mapping.
   ========================================================================== */

(function () {
  'use strict';

  var STATE_KEY = 'techigrateProjectIntakeState';
  var SUMMARY_KEY = 'techigrateProjectIntakeSummary';
  var SEED_KEY = 'techigrateRecommenderSeed';

  var LABELS = {
    improve: {
      web: 'Websites & digital products',
      software: 'Software & applications',
      ai: 'AI & automation',
      infrastructure: 'Automation & infrastructure',
      unsure: 'Not sure yet'
    },
    bottleneck: {
      legacy: 'Outdated or fragile technology',
      manual: 'Manual, repetitive work',
      scale: 'Can\u2019t scale with demand',
      reliability: 'Breaks or slows under load',
      unsure: 'Not sure — help us diagnose'
    },
    involvement: {
      advise: 'Advise & review',
      embedded: 'Build alongside your team',
      ownership: 'Own delivery end-to-end',
      unsure: 'Not sure yet'
    },
    priority: {
      speed: 'Speed',
      reliability: 'Reliability',
      simplicity: 'Simplicity',
      scale: 'Scale',
      automation: 'Automation'
    }
  };

  var SUMMARY_ROWS = [
    { key: 'improve', label: 'Improving' },
    { key: 'bottleneck', label: 'Bottleneck' },
    { key: 'involvement', label: 'Involvement' },
    { key: 'priority', label: 'Priority' },
    { key: 'notes', label: 'Notes' }
  ];

  function readState() {
    try {
      var raw = window.sessionStorage.getItem(STATE_KEY);
      return raw ? JSON.parse(raw) : null;
    } catch (err) {
      return null;
    }
  }

  function writeState(state) {
    try {
      window.sessionStorage.setItem(STATE_KEY, JSON.stringify(state));
    } catch (err) {
      /* private-mode / storage disabled — the widget still works in-memory
         for the rest of this page view, it just won't survive a refresh */
    }
  }

  function clearState() {
    try {
      window.sessionStorage.removeItem(STATE_KEY);
    } catch (err) { /* nothing to do */ }
  }

  function initWidget(root) {
    var form = root.querySelector('.tg-pi-form');
    if (!form) return;

    var steps = Array.from(form.querySelectorAll('[data-tg-pi-step]')).sort(function (a, b) {
      return parseInt(a.getAttribute('data-tg-pi-step'), 10) - parseInt(b.getAttribute('data-tg-pi-step'), 10);
    });
    if (!steps.length) return;

    var lastIndex = steps.length - 1; // the summary step
    var progressEl = root.querySelector('[data-tg-pi-progress]');
    var progressFill = root.querySelector('[data-tg-pi-progress-fill]');
    var stepCurrentEl = root.querySelector('[data-tg-pi-step-current]');
    var stepTotalEl = root.querySelector('[data-tg-pi-step-total]');
    var nav = root.querySelector('[data-tg-pi-nav]');
    var backBtn = root.querySelector('[data-tg-pi-back]');
    var nextBtn = root.querySelector('[data-tg-pi-next]');
    var restartBtn = root.querySelector('[data-tg-pi-restart]');
    var continueLink = root.querySelector('[data-tg-pi-continue]');
    var summaryList = root.querySelector('[data-tg-pi-summary]');

    var index = 0;
    var editingFromSummary = false;

    function fieldsForStep(i) {
      var stepNum = i + 1;
      if (stepNum === 1) return { radios: form.querySelectorAll('input[name="tg-pi-improve"]') };
      if (stepNum === 2) return { radios: form.querySelectorAll('input[name="tg-pi-bottleneck"]') };
      if (stepNum === 3) return { radios: form.querySelectorAll('input[name="tg-pi-involvement"]') };
      if (stepNum === 4) return { radios: form.querySelectorAll('input[name="tg-pi-priority"]') };
      return null; // notes (5) and summary (6) have no required-radio gate
    }

    function stepIsAnswered(i) {
      var fields = fieldsForStep(i);
      if (!fields) return true;
      return Array.from(fields.radios).some(function (r) { return r.checked; });
    }

    function collectAnswers() {
      var notesEl = form.querySelector('textarea[name="tg-pi-notes"]');
      function checkedValue(name) {
        var el = form.querySelector('input[name="' + name + '"]:checked');
        return el ? el.value : '';
      }
      return {
        improve: checkedValue('tg-pi-improve'),
        bottleneck: checkedValue('tg-pi-bottleneck'),
        involvement: checkedValue('tg-pi-involvement'),
        priority: checkedValue('tg-pi-priority'),
        notes: notesEl ? notesEl.value.trim() : ''
      };
    }

    function saveState() {
      var answers = collectAnswers();
      answers.stepIndex = index;
      writeState(answers);
    }

    function restoreAnswers(saved) {
      if (!saved) return;
      ['improve', 'bottleneck', 'involvement', 'priority'].forEach(function (name) {
        if (!saved[name]) return;
        var input = form.querySelector('input[name="tg-pi-' + name + '"][value="' + saved[name] + '"]');
        if (input) input.checked = true;
      });
      if (saved.notes) {
        var notesEl = form.querySelector('textarea[name="tg-pi-notes"]');
        if (notesEl) notesEl.value = saved.notes;
      }
    }

    function renderSummary() {
      if (!summaryList) return;
      var answers = collectAnswers();
      summaryList.querySelectorAll('.tg-pi-summary-row').forEach(function (row) { row.remove(); });

      SUMMARY_ROWS.forEach(function (row, rowIndex) {
        var value = answers[row.key];
        var displayValue = value;
        var isEmpty = !value;

        if (row.key !== 'notes') {
          displayValue = (LABELS[row.key] && LABELS[row.key][value]) || '';
          isEmpty = !displayValue;
        } else {
          displayValue = value || 'No notes added';
        }

        var el = document.createElement('div');
        el.className = 'tg-pi-summary-row';
        el.innerHTML =
          '<div>' +
            '<dt class="tg-pi-summary-label">' + row.label + '</dt>' +
            '<dd class="tg-pi-summary-value' + (isEmpty ? ' tg-pi-summary-value--empty' : '') + '">' +
              (isEmpty ? 'Not answered' : escapeHtml(displayValue)) +
            '</dd>' +
          '</div>' +
          '<button type="button" class="tg-pi-summary-edit" data-tg-pi-edit="' + (rowIndex + 1) + '">Edit</button>';
        summaryList.appendChild(el);
      });
    }

    function escapeHtml(str) {
      var div = document.createElement('div');
      div.textContent = str;
      return div.innerHTML;
    }

    function updateNav() {
      var fields = fieldsForStep(index);
      var answered = !fields || stepIsAnswered(index);
      if (backBtn) backBtn.hidden = index === 0;
      if (nextBtn) nextBtn.hidden = index === lastIndex;
      if (nextBtn) nextBtn.disabled = !answered;
      if (nextBtn) nextBtn.textContent = (index === lastIndex - 1) ? 'Review' : 'Continue';
    }

    function updateProgress() {
      var pct = Math.round((index / lastIndex) * 100);
      if (progressFill) progressFill.style.setProperty('--tg-pi-progress', pct + '%');
      if (stepCurrentEl) stepCurrentEl.textContent = String(index + 1);
      if (stepTotalEl) stepTotalEl.textContent = String(steps.length);
    }

    function showStep(nextIndex) {
      index = Math.max(0, Math.min(lastIndex, nextIndex));
      steps.forEach(function (step, i) {
        step.classList.toggle('tg-pi-is-active', i === index);
      });
      if (index === lastIndex) renderSummary();
      updateNav();
      updateProgress();
      saveState();

      var heading = steps[index].querySelector('.tg-pi-question');
      if (heading) {
        try { heading.focus({ preventScroll: true }); } catch (err) { /* older Safari */ }
      }
    }

    // ---- Wire up events ----
    form.addEventListener('change', function (e) {
      if (e.target && e.target.matches('input[type="radio"]')) {
        updateNav();
        saveState();
      }
    });

    var notesField = form.querySelector('textarea[name="tg-pi-notes"]');
    if (notesField) {
      notesField.addEventListener('input', saveState);
    }

    if (nextBtn) {
      nextBtn.addEventListener('click', function () {
        if (fieldsForStep(index) !== null && !stepIsAnswered(index)) return;
        if (editingFromSummary) {
          editingFromSummary = false;
          showStep(lastIndex);
        } else {
          showStep(index + 1);
        }
      });
    }

    if (backBtn) {
      backBtn.addEventListener('click', function () {
        editingFromSummary = false;
        showStep(index - 1);
      });
    }

    if (summaryList) {
      summaryList.addEventListener('click', function (e) {
        var btn = e.target.closest('[data-tg-pi-edit]');
        if (!btn) return;
        var targetStep = parseInt(btn.getAttribute('data-tg-pi-edit'), 10) - 1;
        editingFromSummary = true;
        showStep(targetStep);
      });
    }

    if (restartBtn) {
      restartBtn.addEventListener('click', function () {
        form.querySelectorAll('input[type="radio"]:checked').forEach(function (r) { r.checked = false; });
        if (notesField) notesField.value = '';
        editingFromSummary = false;
        clearState();
        showStep(0);
      });
    }

    if (continueLink) {
      // Never intercepted, never delayed, never preventDefault-ed — this
      // always does its default job (following the href) no matter what
      // happens below. The widget is now embedded directly on contact.html,
      // so that href is a same-page anchor (#contact-form) rather than a
      // cross-page link — the browser's own smooth-scroll (see
      // scroll-behavior in global.css) carries the visitor down to the
      // form on its own; nothing here needs to trigger that.
      continueLink.addEventListener('click', function () {
        try {
          var answers = collectAnswers();
          window.sessionStorage.setItem(SUMMARY_KEY, JSON.stringify({
            improve: answers.improve,
            bottleneck: answers.bottleneck,
            involvement: answers.involvement,
            priority: answers.priority,
            notes: answers.notes,
            generatedAt: new Date().toISOString()
          }));
        } catch (err) { /* best-effort only; navigation proceeds regardless */ }

        // The intake is the first step of the contact journey. Keep the
        // summary parked in sessionStorage; pricing will carry it into the
        // final form only after the visitor explicitly chooses a plan.
        try {
          document.dispatchEvent(new CustomEvent('techigrate:intake-to-pricing'));
        } catch (err) { /* older browser — the anchor still works */ }
      });
    }

    // ---- Enhance ----
    root.setAttribute('data-tg-pi-js', '');
    if (progressEl) progressEl.hidden = false;
    if (nav) nav.hidden = false;
    if (restartBtn) restartBtn.hidden = false;

    var saved = readState();
    restoreAnswers(saved);

    // Apply a Project Recommender seed, if one is waiting — but only if
    // this visitor doesn't already have a resumed answer for Step 1 (a
    // real prior intake session always wins over a homepage seed). Either
    // way, the seed is consumed here: read once, applied at most once,
    // removed immediately so it can't reapply on a later, unrelated visit.
    try {
      var seed = window.sessionStorage.getItem(SEED_KEY);
      if (seed) window.sessionStorage.removeItem(SEED_KEY);
      if (seed && !form.querySelector('input[name="tg-pi-improve"]:checked')) {
        var seedInput = form.querySelector('input[name="tg-pi-improve"][value="' + seed + '"]');
        if (seedInput) seedInput.checked = true;
      }
    } catch (err) { /* storage unavailable — quiz still works, just unseeded */ }

    var startIndex = 0;
    if (saved && typeof saved.stepIndex === 'number') {
      startIndex = Math.max(0, Math.min(lastIndex, saved.stepIndex));
    }
    showStep(startIndex);
  }

  function init() {
    var roots = document.querySelectorAll('[data-tg-pi-root]');
    roots.forEach(function (root) {
      try {
        initWidget(root);
      } catch (err) {
        // Leave this instance exactly as the no-JS fallback would render it.
        console.error('Techigrate project intake: widget failed to enhance', err);
      }
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
