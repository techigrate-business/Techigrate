# Homepage hero renovation

Reference-inspired hero pass: glass/orb focal visual, richer atmospheric grading, floating pricing card, scroll cue, and lightweight pointer tilt. Existing navigation and downstream homepage sections remain intact. Three.js hero rendering is no longer loaded on the homepage so the new hero stays CSS-driven and lightweight.
