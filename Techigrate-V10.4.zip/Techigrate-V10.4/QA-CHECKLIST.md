# Project Intake — QA checklist

Manual pass. Open `preview.html` for all of these unless noted otherwise.
Check a box mentally as you go — nothing here is automated.

## 1. No-JS fallback (do this one first)

- [ ] Disable JavaScript (e.g. Chrome DevTools → Cmd/Ctrl+Shift+P → "Disable
      JavaScript", then reload).
- [ ] Confirm all six steps render stacked, in order, all visible at once:
      improve → bottleneck → involvement → priority → notes → summary note.
- [ ] Confirm there is no progress bar and no Back/Continue nav row visible
      (they're `hidden` by default and only appear once JS runs).
- [ ] Confirm the "Continue to contact form" button is visible and, when
      clicked, actually navigates to the real `contact.html`.
- [ ] Confirm nothing on the page is invisible, cut off, or overlapping.
- [ ] Re-enable JavaScript before continuing.

## 2. Core flow (JS on)

- [ ] Reload `preview.html`. Step 1 is active; Continue is disabled until
      an option is picked.
- [ ] Pick an option in step 1 → Continue enables → click it → step 2 shows.
- [ ] Repeat through steps 2, 3, 4 (each required; Continue stays disabled
      until an option is picked in that step).
- [ ] Step 5 (notes): Continue is enabled immediately, with or without
      typing anything.
- [ ] Reaching step 5 → Continue's label reads "Review" (not "Continue").
- [ ] Step 6 (summary): every prior answer appears with the correct label,
      matching what was actually picked. Notes shows either the typed text
      or "No notes added" in muted italic if left blank.
- [ ] Progress bar and "Step X of 6" label update correctly on every step,
      reaching 100% / "Step 6 of 6" on the summary.

## 3. Back navigation & edits

- [ ] From any step > 1, Back is visible and returns to the previous step
      with that step's previous answer still selected.
- [ ] From step 1, Back is hidden (nothing to go back to).
- [ ] From the summary, click "Edit" next to any row → jumps directly to
      that step, with the current answer still selected.
- [ ] After editing, click Continue on the edited step → returns directly
      to the summary (not forward through the remaining steps again).
- [ ] Summary reflects the edited answer correctly after this round-trip.

## 4. Restart

- [ ] "Start over" is visible once JS has enhanced the widget.
- [ ] Clicking it clears every selection and the notes field, and returns
      to step 1.
- [ ] Reload the page after starting over — it should stay reset (nothing
      restored from a prior session).

## 5. Refresh persistence

- [ ] Answer steps 1–3 (leave 4 unanswered), then reload the page.
- [ ] Confirm it resumes on step 4 (or wherever you left off), with steps
      1–3's answers still selected if you page Back to check them.

## 6. "Continue" hand-off and prefill

- [ ] With at least one answer filled in, click "Continue". It must
      navigate to the real `contact.html` every time — confirm this
      explicitly with DevTools open and a breakpoint or `console.log`
      temporarily added to the click handler, if you want to be certain
      nothing ever calls `preventDefault()`.
- [ ] On arrival at `contact.html`, confirm: **Project type** is
      pre-selected to match what you picked in step 1; **Message**
      contains a short recap of your bottleneck/involvement/priority/notes
      answers; a small note appears above the form explaining the
      prefill; focus lands in the **Name** field.
- [ ] Confirm **Name**, **Email**, **Company**, and **Budget** are left
      blank — the quiz never collects them, and prefill must not invent
      values for them.
- [ ] Confirm nothing was auto-submitted — you land on the form, not on a
      "message sent" confirmation. You have to click **Send message**
      yourself for anything to go out.
- [ ] In DevTools → Application → Session Storage, confirm
      `techigrateProjectIntakeSummary` is **gone** after the prefill runs
      (removed immediately on read, so it can't re-apply on a refresh).
- [ ] Reload `contact.html` after the above — confirm the prefilled note
      does *not* reappear and existing field values aren't clobbered.
- [ ] Go directly to `contact.html` from the nav (skipping the intake
      entirely) — confirm the form loads completely normally, with no
      note, no prefilled values, and no console errors. This is the "no
      intake data present" path and must be a total no-op.
- [ ] Test with an ad blocker / privacy extension that blocks
      `sessionStorage` (or Firefox strict private browsing) — confirm the
      form still loads normally with no console errors; the prefill
      should fail silently, not break the page.
- [ ] Confirm every other part of the real contact form — validation,
      the Apps Script / mailto submit flow, the FAQ accordion — still behaves
      exactly as before. Only the prefill-on-load behavior is new.

## 7. Dark mode

- [ ] Toggle the theme switch in the preview page's top bar. Confirm the
      widget's background, borders, text, option cards, progress bar, and
      buttons all adapt — no light-mode-only colors left behind, no
      unreadable text.
- [ ] Reload with dark mode already active (or with your OS set to dark
      and no prior choice saved) — confirm it starts in dark mode with no
      flash of light mode first.

## 8. Reduced motion

- [ ] Enable "prefers-reduced-motion: reduce" (Chrome DevTools → Rendering
      tab → Emulate CSS media feature `prefers-reduced-motion`, or your OS
      accessibility settings).
- [ ] Reload and step through the flow — step transitions should have no
      slide/fade animation (they should appear instantly).

## 9. Keyboard & screen reader basics

- [ ] Tab through step 1: focus reaches each option in order, Enter/Space
      selects the focused option.
- [ ] Continue/Back/Edit/Start over are all reachable and operable by
      keyboard alone.
- [ ] Each step's question is announced when the step changes (focus
      moves to the heading on every `showStep` call — confirm with a
      screen reader, or at minimum confirm focus visibly lands there).
- [ ] Every option's selected state is visible without relying on color
      alone (the dot fills, and the card gets a visible border-color
      change).

## 10. Mobile / responsive

- [ ] Narrow the viewport to ~375px wide (or use a real phone).
- [ ] Confirm the priority step's five options stack into a single column
      below ~560px rather than staying two-across.
- [ ] Confirm every option card and every button meets a comfortable touch
      target (should feel like ~44px+ tap height — nothing cramped).
- [ ] Confirm the footer CTA buttons stack full-width on narrow screens
      rather than staying side-by-side and cramped.
- [ ] Confirm nothing overflows horizontally at any width from ~320px up.

## 11. Isolation (the "did we break anything" pass)

- [ ] Confirm `contact.html`, `css/contact.css`, `css/global.css`,
      `js/global.js`, and every nav/footer markup block are byte-for-byte
      unchanged from before this module was added (a `diff` against a
      pre-upgrade copy of the repo, excluding this module's own files —
      `css/tg-pi.css`, `js/tg-pi.js`, `preview.html`, `template.html`,
      `PROJECT-INTAKE.md`, `QA-CHECKLIST.md` — should be empty).
- [ ] `js/contact.js` is the one intentional exception: confirm its
      *only* difference from the pre-upgrade version is the new
      `prefillFromIntake()` block (see "What this does — and doesn't —
      touch" in `PROJECT-INTAKE.md`) — the existing Apps Script / mailto
      submit logic and FAQ accordion code should be untouched, line for
      line, below that new block.
- [ ] Confirm no class name or `data-*` attribute introduced by this
      module (outside reused existing utility classes like `.glass` /
      `.btn` / `.type-*`) appears anywhere in the existing site's CSS or
      JS — i.e. nothing here could have silently collided with something
      that already existed.


## Backend connection (V10.1)
- [ ] `lead-test.html`: health OK, content OK, test lead shows **SAVED ✔** and a new `Leads` row (Status New)
- [ ] Contact form: valid send → success screen + `Leads` row + email alert + `lead` row in `Events`
- [ ] Contact form: with the endpoint wrong/offline → error message with the email address; form stays filled
- [ ] Sending the same message twice quickly → only one `Leads` row
- [ ] Every page (not only home) adds a `page_view` row in `Events`; no console errors if the backend is offline
- [ ] Add an active Announcement → bell shows it on all pages; dot clears after opening the bell
- [ ] Browser with Do-Not-Track on → no `Events` rows
- [ ] Dashboard: Event Mix and Leads by Status survive running `setup()` again
