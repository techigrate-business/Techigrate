# Techigrate V5.8 — Navigation Renovation V6

- Floating command-dock navigation with stronger visual hierarchy.
- Numbered nav items + moving active lens.
- Refined Contact / theme / Start a Project control cluster.
- Dynamic Island receives TG brand identity and click-to-top behavior.
- Mobile navigation becomes a rounded command sheet.
- Added live page-progress rail.
- Homepage greeting/stair intro now plays once per session; `?intro=1` forces replay for testing.
