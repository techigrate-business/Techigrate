# Project Intake — upgrade module

> **Note on this file's name:** this documentation originally shipped as
> `README.md` inside a self-contained `upgrades/project-intake/` folder.
> Somewhere between that delivery and this copy of the project, `css/tg-
> pi.css`, `js/tg-pi.js`, `preview.html`, `template.html`, and `QA-
> CHECKLIST.md` got moved up into the site's existing folders — but a
> `README.md` already existed at the site root (the one describing the
> whole Techigrate project), so this module's own README never made the
> move; it was silently dropped rather than overwriting that file. This
> is that content, restored, under a name that won't collide with
> anything. See "A note on the folder move" at the bottom for what else
> that reorganization affected and how it's been fixed.

A premium, progressive "tell us what needs to work better" flow: five calm
questions plus optional notes, a summary screen, then a hand-off to the
existing contact form.

```
(site root)
├── PROJECT-INTAKE.md    — this file
├── QA-CHECKLIST.md      — manual test pass before anyone wires this in
├── preview.html         — standalone page to view/try the widget today
├── template.html        — the isolated widget markup, ready to copy into a page
├── css/tg-pi.css        — namespaced stylesheet (all classes start tg-pi-)
└── js/tg-pi.js          — namespaced vanilla JS controller
```

## Try it

Open `preview.html` directly (double-click it, or serve the site root with
any static server). No build step, no dependencies to install.

Reduced motion, dark mode, and no-JS are all real, testable states here —
see `QA-CHECKLIST.md` for exactly how to check each one.

## What this does — and doesn't — touch (updated)

The module started life fully read-only with respect to the rest of the
site. That changed by explicit request: the hand-off to the contact form
is now real, which meant editing `js/contact.js` — the one file every
earlier version of this document said would stay untouched. Precisely:

- **`js/contact.js` now has one new, self-contained block** —
  `prefillFromIntake()` — added at the top of the file, before its
  existing form-submit logic (which is otherwise unchanged, line for
  line). It runs once on page load, is a complete no-op for every visitor
  who didn't come from the intake quiz, and never calls `preventDefault()`
  or submits anything on its own. See "What 'Continue' actually does
  today" below for exactly what it does.
- **`contact.html`, `css/contact.css`, `css/global.css`, `js/global.js`,
  and every nav/footer markup block are still untouched.** `css/tg-pi.css`
  and `js/tg-pi.js` are still new files sitting alongside the existing
  ones, not edits to them.
- It still does not call any external service, analytics endpoint, or
  API, and still does not submit the contact form on the visitor's
  behalf — the visitor always clicks Send themselves, on the real form,
  after reviewing what's there.

## What "Continue" actually does today

Clicking it does two things, in order:

1. Writes one JSON blob to `sessionStorage` (key
   `techigrateProjectIntakeSummary`, shape `{ improve, bottleneck,
   involvement, priority, notes, generatedAt }`), in a click handler that
   never calls `preventDefault()` and never delays the navigation.
2. Navigates to the real `contact.html`.

On `contact.html`'s load, `js/contact.js`'s `prefillFromIntake()` reads
that same key, **removes it immediately** (so it never re-applies on a
refresh or a later, unrelated visit), and — only where it can do so
safely — fills in:

- **Project type** — set directly, since `improve`'s values
  (`web`/`software`/`ai`/`infrastructure`/`unsure`) match that select's
  `<option>` values exactly.
- **Message** — a short, human-readable recap built from `bottleneck`,
  `involvement`, `priority`, and `notes` (only the parts that were
  actually answered), only if the field is still empty.
- A small note is inserted above the form explaining the fields were
  prefilled and are safe to edit.
- Focus moves to the **Name** field, since that's the one thing the
  intake quiz deliberately never asks for.

Name, email, company, and budget are always left for the visitor to fill
in themselves — the intake quiz never collects them, by design.

**Nothing here sends anything.** The visitor still reads the prefilled
form and clicks **Send message** themselves, which runs the same
Apps Script / mailto logic that already existed — see the top of
`js/contact.js` for that (still pending its real access key).

The in-progress answers (before someone clicks Continue) live under a
separate key, `techigrateProjectIntakeState`, purely so a page refresh
doesn't lose progress mid-quiz. Also `sessionStorage`, also never
transmitted anywhere, also never read by anything outside `tg-pi.js`.

## Receiving a seed from Project Recommender

The homepage's own quick 2-question widget ("What are you trying to
build?", namespaced `tg-pr-` — see `PROJECT-RECOMMENDER.md`) hands off to
this one. When someone completes it and clicks through, `js/project-
recommender.js` writes a small `sessionStorage` entry (key
`techigrateRecommenderSeed`) naming the category they picked, then
navigates to `contact.html#tg-pi-root` — landing directly on this widget,
not just the top of the page.

On load, `js/tg-pi.js` reads that key once, removes it immediately, and —
only if Step 1 doesn't already have a resumed answer from this visitor's
own prior session — pre-selects the matching option. It never
auto-advances past Step 1 on its own; the visitor still sees and confirms
the pre-selected answer themselves, same principle as everything else in
this module.

See `PROJECT-RECOMMENDER.md` for the full category-to-value mapping and
why "Automation" (that module's term) and "Automation & infrastructure"
(this module's Step 1 option, previously labeled "Infrastructure &
technical support") now agree on the same underlying value
(`infrastructure`) instead of being two different taxonomies.

## Integration status: done

The widget is live, embedded directly in `contact.html` — not just
reachable via `preview.html` anymore. What actually happened, for the
record:

1. `<link rel="stylesheet" href="css/tg-pi.css">` and
   `<script src="js/tg-pi.js" defer></script>` are both in `contact.html`.
2. The widget sits inside `<section class="section-tight container">`,
   directly above `<div class="contact-grid" id="contact-form">` — a
   visitor sees the intake widget first, the existing form right after it.
3. The self-link problem this document used to warn about here is
   resolved: `id="tg-pi-root"` was added to the widget's own `<section>`,
   and its "Continue" button links to `#tg-pi-root` for a same-page
   scroll-and-prefill (see "What 'Continue' actually does today" above) —
   not a page reload, and not a link to nowhere.

`preview.html` and `template.html` still exist — `preview.html` as a
standalone way to demo just the quiz in isolation (useful for QA without
the rest of the contact page around it), `template.html` as the
reference copy of the fragment's markup, kept in sync by hand since
there's no build step. Neither is required for the live feature to work;
both are convenience/reference copies of what's already on `contact.html`.

Re-run `QA-CHECKLIST.md` against the live `contact.html` page specifically
(not just `preview.html`) before launch — a few checks (touch targets
against the real bottom-nav, stacking against the real page header) can
only really be judged in place.

## A note on the folder move

This module was originally delivered self-contained under
`upgrades/project-intake/`, specifically so it could never collide with
anything at the site root — including this project's own pre-existing
`README.md`. When the module's files were moved up into the shared `css/`
and `js/` folders and the site root, two things broke silently, and have
now been fixed in this copy:

- **`preview.html` had four dead links.** It was written assuming it
  lived two folders below the site root (`href="../../css/global.css"`,
  `../../index.html`, `../../contact.html`, `src="../../js/global.js"`).
  Sitting at the root instead, those `../../` paths pointed *outside* the
  project entirely. Concretely, this meant `global.css` never loaded (the
  whole page would have rendered unstyled), the theme toggle never worked
  (`global.js` never loaded either), and — worse — the one link required
  to always work, "Continue to contact form," was dead. All four are now
  plain root-relative paths (`css/global.css`, `index.html`,
  `contact.html`, `js/global.js`) and resolve correctly from the module's
  current location.
- **This documentation was silently dropped.** The module's own
  `README.md` collided with the site's existing root `README.md` on the
  move; the site's original survived, this one didn't come along. It's
  restored here as `PROJECT-INTAKE.md` instead, with its internal
  structure diagram and integration-step code snippets updated to match
  the flat paths (no more `upgrades/project-intake/` prefix anywhere).
- **`template.html`** needed the same link fix as `preview.html` for the
  same reason — done, with an updated comment explaining the self-link
  caveat once it's pasted into `contact.html` for real.
- **`QA-CHECKLIST.md`** needed no path fixes — its one mention of
  `/upgrades/` was a description of the isolation check, not a working
  link, and has been updated to describe the diff check in terms of the
  current file layout instead.

If a nested, fully self-contained folder (immune to exactly this kind of
collision) is preferred, moving `css/tg-pi.css`, `js/tg-pi.js`,
`preview.html`, `template.html`, `QA-CHECKLIST.md`, and this file back
into a single `upgrades/project-intake/` folder — and restoring the
`../../` paths this file documents in its own git history — would do it.

## Design notes

- **Tokens, not a new palette.** Every color, spacing, radius, shadow,
  and font in `tg-pi.css` is a `var(--...)` reference into the existing
  `css/global.css` token set (`--paper`, `--ink`, `--blue`, `--gradient`,
  `--r-sm/md/lg/xl`, `--sp-*`, `--shadow-*`, `--font-display/body`). Dark
  mode "just works" because those tokens already flip under
  `[data-theme="dark"]` in the file the site already loads — this module
  adds no dark-mode CSS of its own.
- **`.glass` is reused, not reinvented.** The outer widget panel uses the
  existing `.glass` utility class from `global.css` directly.
- **Reduced motion** is respected twice over: once for free, via
  `global.css`'s existing sitewide `@media (prefers-reduced-motion:
  reduce)` rule (which applies to any element, including this module's,
  the instant `global.css` is loaded on the same page); and again
  independently inside `tg-pi.css` itself, so the module still behaves if
  it's ever used somewhere that doesn't load `global.css`.
- **Progressive enhancement, not a JS requirement.** Every step's
  fieldset is visible by default; `js/tg-pi.js` is what turns that into a
  one-question-at-a-time flow (see the big comment atop both `tg-pi.css`
  and `tg-pi.js` for exactly how the hand-off works). The no-JS path was
  a hard requirement in the brief, not an afterthought — it's the actual
  default rendering, not a separate code path bolted on.
- **Copy reuses existing site vocabulary on purpose.** Step 1's five
  categories mirror the "Project type" dropdown already on
  `contact.html` word-for-word, so the two feel like one continuous
  conversation rather than two different taxonomies. No budget question
  was added — the brief said not to require one, and the existing
  contact form already asks it, optionally, later in the real flow.
- **Namespace discipline.** Every class and every `data-*` attribute this
  module defines starts with `tg-pi-`. Search the whole module for a
  bare, non-prefixed class name — the only ones you'll find are reused
  *existing* utility classes (`glass`, `btn`, `btn-primary`, `btn-
  secondary`, `btn-ghost`, `type-h3`, `type-h4`, `type-small`, `eyebrow`,
  `container`), applied by class attribute, never redefined here.
