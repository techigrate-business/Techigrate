# Techigrate — Lead Connection (V10.1)

Flow: contact form → `js/tg-lead-transport.js` (hidden-iframe POST) → Apps Script `doPost` → `saveLead_` → `Leads` tab,
plus a `lead` row in `Events` and an email alert to `notify_email`.

- The endpoint lives in **one place**: `js/site-config.js` → `appsScriptUrl`.
- The backend replies with a small page that posts a confirmation (`{ok, id, error, requestId}`) to the website, so the
  form shows success only when the lead was saved (or a clear "sent, unconfirmed" message if the confirmation times out).
- Spam protection: hidden honeypot field `website`, duplicate guard (2 min), 5 messages/hour per email.
- No third-party form service is used.

Analytics and announcements/projects use `js/tg-backend.js` on every page. See `BACKEND-CHANGES.md`.
