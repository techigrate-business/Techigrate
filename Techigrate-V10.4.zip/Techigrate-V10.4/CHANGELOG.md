## V10.4 — Mobile pass, merged onto V10.3 (real projects + faster intro)
Phones/tablets only (<= 900px, the site's existing bottom-nav breakpoint); desktop is untouched because the new stylesheet is linked with media="(max-width: 900px)".
- New: css/mobile.css (linked last in <head> on every page) and js/mobile.js (menu-sheet backdrop + swipe-down close).
- Floating top navbar (logo pill, hamburger, contact link) removed on mobile. Bottom navigation kept; "More" opens the menu as a bottom sheet above it, with a dimmed backdrop. Sheet colours fixed for light and dark themes (Start a Project label and search icon were invisible in light mode; links unreadable in dark).
- Contact page: two-column grid now collapses to one column (page was ~634px wide and scrolled sideways). Long e-mail addresses wrap.
- Footer columns can shrink (3px sideways overflow on every page). html/body overflow-x: clip as a safety net.
- Homepage hero: title, planet and buttons stack without overlap and adapt to screen height (320x568 up to tablet); landscape phones hide the planet. js/home-scene.js: phone branch of the title fit also caps the font size by viewport height (desktop branch unchanged).
- Inputs are 16px (no iOS zoom on focus). "Back to Home" chip removed on mobile; one small round "Back to Top" button on every page. Right-edge section rail hidden on mobile. Work modal uses dvh.
- Page headers no longer reserve space for the removed top bar (--nav-h is 0 on mobile).

## V10.3 — Real projects in "See our work" (your upload)
Replaced the 6 placeholder projects (work.html, homepage tiles, popup data) with Koras Cafe, The Cafe and Madav Tutorials; screenshots in assets/work/. New animated 3D project reel at the top of work.html (css/work-reel.css, js/work-reel.js). Popup shows an auto-playing screenshot slideshow with factual stats; fixed the see-through popup panel and stacked stat numbers; filters are All work / Food & hospitality / Education. V10.3d: faster homepage intro (5 greetings, ~2.5s), logo mark pop-in, shimmer on the progress bar, quicker orbits and iris (see V10.3-NOTES.md).

## V10.2 — New intro: Signal Decode + Iris Open (on V10.1)
Only css/preloader.css and js/preloader.js changed (index.html untouched). The white rolling-greeting + stair peel is replaced by a dark "signal" intro: each greeting scrambles through glyphs of its own script (Latin, Devanagari, Kana, Hangul) and locks in letter by letter, with a language tag, 000-100 counter, gradient progress line, orbiting rings and corner HUD; the final "Hello, Welcome to TECHIGRATE" resolves with a brand-gradient TECHIGRATE, then the screen opens through a glowing circular iris onto the homepage. Same hooks as before (tg-preloading / tg-loaded, session skip, ?intro=1 replay, reduced-motion fallback). Previous intro saved in _intro-backup/ for instant rollback.

## V10.1 — Backend connection overhaul (on V10)
Analytics, announcements/projects and lead saving now run through two shared scripts (`js/tg-backend.js`, `js/tg-lead-transport.js`) on every page. Contact form shows real, confirmed delivery; honeypot added; inline script removed from `index.html`. Backend v2.1 fixes event saving, Dashboard rebuild, formula injection, duplicates; adds email alerts. Full details: BACKEND-CHANGES.md.

## V10 — Cursor update on V09.9
Only css/v097-motion.css and js/v097-motion.js changed: theme/surface-aware cursor colours, dot + lagging ring, rounded snap-frame on buttons/nav/chips, gradient "View" disc on cards, click pulse. Everything else is V09.9. See V10-NOTES.md.

## V09.9 — Merge: V09.7 motion + V09.8 launch clean-up
V09.7 (motion batch: scroll-driven animation, line reveals, stacking cards, pinned horizontal scroll, velocity marquee, custom cursor + magnetic buttons, View Transitions, odometer stats, looping process video) kept intact; V09.8 clean-up applied on top: Web3Forms removed, Careers removed, dev pages/placeholders removed, contact constants centralised (js/site-config.js), one footer on every page, Terms & Conditions design shell. Also fixed: homepage now loads js/site-config.js (V09.8 read the endpoint from it without loading it). See V09.9-NOTES.md.

## V09.7 — Motion batch
Native scroll-driven parallax/wipes, line-by-line headings, stacking work cards, pinned horizontal scroll (Services + new homepage "How we work"), velocity marquee, custom cursor + magnetic buttons, cross-page View Transitions, SVG line drawing, card tilt/glare, arrow morph + underlines, odometer stats, 6 s looping video with play-on-enter, day/night dissolve. Details: V09.7-NOTES.md.

## V09.6 — Aesthetic batch (homepage only)
- Added css/v096-aesthetic.css and js/v096-aesthetic.js: shared glass recipe (.tg-glass), aurora backgrounds with scroll-driven colour crossfade, static grain, bento grids for "What we build" and the work preview, editorial italic serif (.tg-ital, Instrument Serif), oversized section headings, and one raw closing block (.v8-end). index.html edited only for tags, bento markup/motifs, .tg-ital spans and the font link. See AESTHETIC.md.

## V09.4
- Replaced the floating glass PREV / NEXT section panels (they covered text) with a slim right-edge section rail: dots + continuous progress line, hover labels, J/K keyboard jumps, idle fade, touch progress strip. Removed ~1,500 lines of old panel CSS. See V09.4-NOTES.md.

# V5.8 — Dynamic Island performance + interaction polish

- Reworked the Dynamic Island motion loop to sample scroll state once per frame instead of writing styles from the scroll handler.
- Removed the old header hide-on-scroll conflict from the Dynamic Island path.
- Fixed collapsed-state pointer logic so the invisible full navbar cannot steal hover events from the island.
- Reduced expensive blur/filter work while keeping the light/night reference styling and 3D depth.
- Smoothed hover expansion, pointer inertia, progress motion, live-status pulse, and shape morphing.
- Reduced cursor-trail point count and capped the Three.js hero render pixel ratio to 1.5 to lower GPU/CPU pressure.
- Mirrored all shared changes into the `site/` build.

# V5.8 — Pricing stage polish

- Dark, layered pricing-stage background tuned to the supplied reference image.
- Added subtle grid texture, deep glass surfaces, purple ambient glow, and nested stage borders while retaining plan-specific accent colors.
- Reworked pricing click sparks to match the standalone Pricing V3 treatment: 8 brighter particles with a visible white core/cross flare and accent glow.
- Pricing remains fully scoped to the Contact page component; no website-wide behavior changed.

# Techigrate Change Log

## V5.7 — Guided contact flow

- Contact page now follows a guided sequence: Project Intake → Pricing → Final Contact Form.
- Choosing a pricing plan automatically syncs the selected budget into the final contact form.
- Intake answers are carried into the final form only after a plan is explicitly selected.
- Added layered 3D/glass card treatment to the intake and final forms.
- Added global click-spark interaction across the live site (with reduced-motion/touch safeguards).
- Kept the existing V5.6 pricing visuals, homepage preloader, theme transition, smooth scroll, project showcase, and cursor trail intact.

# CHANGELOG

## V5.5 — Rolling Greeting + Butter-Smooth Handoff
- Reworked the homepage-only greeting sequence with rolling per-letter motion inspired by the supplied Rolling Text reference.
- Greeting set now keeps a small Indian-language presence and adds Spanish, French, Italian, Portuguese, German, Japanese, and Korean.
- Final greeting resolves to “Hello, Welcome to TECHIGRATE”.
- Removed the Tap to Continue gate and replaced it with an automatic double-stair reveal.
- Smoothed the white-to-stair handoff and reduced heavy page-wide animation work.
- Rebuilt internal page navigation transition to avoid full-page blur/backdrop filtering; navigation now uses a short GPU-friendly wash and speed streaks.
- Preserved all V5.4 project showcase, smooth-scroll, theme, cursor, and page behaviors.

# Techigrate changelog

## V5.2
- Fixed project-detail modal scroll leakage: Lenis is stopped while the modal is open and the page position is preserved/restored on close.
- Added true document scroll locking with scrollbar compensation and mobile overscroll containment.
- Kept the project detail panel independently scrollable on smaller screens.
- Added the same project showcase interaction to the homepage's three featured project cards.
- Homepage project cards now open the case-study modal directly instead of navigating away to Work.
- Added shared `js/project-showcase.js` and `css/project-showcase.css` so Work and Home use the same interaction layer.
- Preserved V5.1 archive under `versions/V5.1-Projects-Showcase.zip`.

## V5.3 — Drawing Cursor + Motion Polish
- Added a restrained drawing-style cursor trail inspired by the supplied reference.
- Uses a canvas-based trail with inertia, easing, fade-out, and a subtle active-pointer head.
- Disabled on touch/coarse pointers and under `prefers-reduced-motion`.
- Automatically hides during the homepage preloader/continue gate and project detail modal so overlays remain clean and usable.
- No input capture; normal system cursor remains intact.
- Mirrored into the `site/` build.
## V5.4 — Double-stair homepage handoff + outbound motion transitions
- Kept the multilingual white-word preloader unchanged.
- Replaced the post-preloader dark Tap to Continue stage with a double-stair handoff that clears outward on activation and reveals the homepage.
- Preserved keyboard activation and reduced-motion support.
- Added click-origin motion-blur navigation for normal internal page links, with speed streaks and a short cinematic handoff.
- Project showcase clicks remain isolated because the transition waits for existing click handlers to finish.
- Preserved V5.3 in `versions/V5.3-Drawing-Cursor.zip`.
## V5.6 — Pricing integration

- Integrated the V3 glass/3D pricing UI into `contact.html` between the project intake and contact form.
- Added Silver / Gold / Platinum / Diamond plan states with ₹ ranges and scoped feature labels.
- Added plan-aware glass lighting, square rings, glare, lightweight 3D tilt, text-roll transitions, and contact-form handoff.
- Added a non-blocking homepage pricing teaser linking to `contact.html#pricing`.
- Updated the contact budget selector to use the same ₹500–₹10,000+ plan ranges.
- Kept the V5.5 build and pricing V3 package available under `versions/` for rollback/reference.
- V5.8 navigation: added continuous scroll-driven luxury lighting and navbar-to-Dynamic-Island morph; the existing navigation shell remains the single DOM/header system.

## V09
Scroll journey (depth transitions on all pages, pinned planet-T dive on home), planet-T hero, unused SVGs removed. See V09-SCROLL-JOURNEY.md.

V09 update 2: lake video hero backgrounds (day/night), V08 centred title + V07 Hello, light default theme, pricing lag fix.

V09.1: flat navbar over live bg that morphs into the floating pill, thin V08 sliding band, pricing ad + floating buttons hidden over live bg, 3D interactive title/planet. See V09.1-NOTES.md.

V09.2: marquee pace matched to V08, home stats count-up on scroll. See V09.2-NOTES.md.

V09.3: home page - removed process + recommender sections; What we build and closing CTA now V08 layout (Let’s build.). See V09.3-NOTES.md.
