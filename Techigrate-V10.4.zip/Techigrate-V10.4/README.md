V5.8 update: pricing stage background and V3-style click sparks.

## Current build: V5.1 — Projects Showcase

# Techigrate — marketing site

A true multi-page site: seven static HTML pages sharing one design system
(`css/global.css` + `js/global.js`), each with its own page-specific
stylesheet and script.

## Structure

```
techigrate/
├── index.html          Home
├── services.html        Four service pillars + engagement models
├── work.html             Filterable, expandable case studies
├── technology.html       Isometric stack diagram, toolkit, principles
├── about.html             Story, values, leadership, timeline
├── careers.html            Culture, benefits, filterable open roles
├── contact.html            Form, office info, FAQ accordion
├── css/
│   ├── global.css      Design tokens, reset, nav, footer, buttons, glass, CTA
│   └── <page>.css       Page-specific layout only — no token overrides
├── js/
│   ├── global.js        Header scroll behavior, mobile menu, scroll-reveal
│   └── <page>.js         Page-specific interaction (filters, accordions, forms)
└── README.md
```

## Running it

No build step. Open `index.html` directly, or serve the folder with any
static file server (e.g. `npx serve .`) so relative paths resolve cleanly.

## Design system

Tokens live in `css/global.css` (`:root`) — surfaces, text, accent gradient,
type scale, spacing, radius, shadow. Every page pulls from the same tokens;
page stylesheets only add layout for that page's own sections.

Shared components (nav, footer, buttons, `.glass`, `.cta-banner`,
`.page-header`, filter chips, accordions) are copy-pasted markup rather than
templated, since this is static HTML with no build step — keep the markup
in sync across pages when editing one of them.

## Current state

- Built with CSS, SVG, layered/glass compositions, and a light Three.js
  scene for the homepage hero (`js/hero-scene.js`) for the "spatial" feel.
- The tech spec calls for a future Next.js / TypeScript / React Three Fiber /
  Framer Motion port. This HTML/CSS/JS version is the reference
  implementation for that port, not a placeholder to throw away — component
  boundaries (hero visual, stack diagram, case cards, etc.) were kept
  intentionally self-contained to make that translation straightforward.
- `assets/` holds the site's real, shipped images: favicons (`.ico`, `.svg`,
  16px/32px PNGs, Apple touch icon) and the Open Graph/Twitter card share
  image. Everything else visual is still inline SVG or CSS.
- `robots.txt` and `sitemap.xml` are live at the root for search engines.
  `404.html` handles missing pages. `js/section-nav.js` adds an
  auto-detected floating prev/next control between each page's top-level
  sections (opt out per page with `<body data-no-section-nav>`).
- Two additive upgrade modules live at the root — see `PROJECT-INTAKE.md`
  and `PROJECT-RECOMMENDER.md` for what each does and how they connect to
  each other and to `contact.html`.


V5.1 adds the immersive project rail and click-to-open case-study overlay while preserving the homepage-only preloader, theme transition, and Lenis smooth scroll.

### V5.3
Adds the subtle drawing cursor trail from the supplied reference. The effect is progressive enhancement only: it uses a passive canvas layer, keeps the real system cursor, disables itself on touch/reduced-motion devices, and hides for modal/preloader states so it never competes with core UI.

## Current baseline
V5.5 — Double-stair homepage handoff + outbound motion-blur page transitions.


### V5.5 polish
The homepage preloader now uses rolling letter motion, international greetings, and an automatic double-stair reveal with no tap gate. Outbound page navigation is intentionally lightweight to avoid the lag caused by heavy full-page blur/backdrop-filter work.


### V5.6 pricing integration
The Contact page now contains the standalone pricing UI in a scoped component between intake and the contact form. The homepage includes a dismissible features/pricing teaser linking directly to the pricing section.
