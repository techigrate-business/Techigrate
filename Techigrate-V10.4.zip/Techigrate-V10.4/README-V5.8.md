# Techigrate V5.8

Pricing-stage polish only.

- Contact-page pricing background now follows the supplied dark layered/glass reference.
- Pricing click sparks use the stronger V3-style 8-particle burst with visible white flare core.
- Pricing interaction remains scoped to the pricing UI.
- No new website-wide click-spark changes in this version.
